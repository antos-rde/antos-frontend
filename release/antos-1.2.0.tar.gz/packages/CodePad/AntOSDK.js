var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var OS;
(function (OS) {
    const App = OS.application.CodePad;
    class AntOSDK extends App.BaseExtension {
        constructor(app) {
            super(app);
        }
        create() {
            this.app
                .openDialog("FileDialog", {
                title: "__(New Project at)",
                file: { basename: __("ProjectName") },
                mimes: ["dir"],
            })
                .then((d) => {
                this.logger().clear();
                return this.mktpl(d.file.path, d.name, true);
            });
        }
        init() {
            this.logger().clear();
            const dir = this.app.currdir;
            if (!dir || !dir.basename) {
                return this.create();
            }
            dir.read().then((d) => {
                if (d.error) {
                    return this.logger().error(__("Cannot read folder: {0}", dir.path));
                }
                if (d.result.length !== 0) {
                    return this.logger().error(__("The folder is not empty: {0}", dir.path));
                }
                this.mktpl(dir.parent().path, dir.basename);
            });
        }
        buildnrun() {
            this.logger().clear();
            this.metadata("project.json")
                .then((meta) => __awaiter(this, void 0, void 0, function* () {
                try {
                    yield this.build(meta, true);
                    yield this.run(meta);
                }
                catch (e_1) {
                    return this.logger().error(__("Unable to build and run project: {0}", e_1.stack));
                }
            }))
                .catch((e) => this.logger().error(__("Unable to read meta-data: {0}", e.stack)));
        }
        release() {
            this.logger().clear();
            this.metadata("project.json")
                .then((meta) => __awaiter(this, void 0, void 0, function* () {
                try {
                    yield this.build(meta, false);
                    yield OS.API.VFS.mkar(`${meta.root}/build/debug`, `${meta.root}/build/release/${meta.name}.zip`);
                    this.logger().info(__("Archive generate at: {0}", `${meta.root}/build/release/${meta.name}.zip`));
                }
                catch (e_1) {
                    return this.logger().error(__("Unable to release project: {0}", e_1.stack));
                }
            }))
                .catch((e) => this.logger().error(__("Unable to read meta-data: {0}", e.stack)));
        }
        mktpl(path, name, flag) {
            const rpath = `${path}/${name}`;
            const dirs = [
                `${rpath}/javascripts`,
                `${rpath}/css`,
                `${rpath}/coffees`,
                `${rpath}/ts`,
                `${rpath}/assets`,
            ];
            if (flag) {
                dirs.unshift(rpath);
            }
            const files = [
                ["templates/sdk-main-coffee.tpl", `${rpath}/coffees/main.coffee`],
                ["templates/sdk-main-ts.tpl", `${rpath}/ts/main.ts`],
                ["templates/sdk-package.tpl", `${rpath}/package.json`],
                ["templates/sdk-project.tpl", `${rpath}/project.json`],
                ["templates/sdk-README.tpl", `${rpath}/README.md`],
                ["templates/sdk-scheme.tpl", `${rpath}/assets/scheme.html`],
            ];
            OS.API.VFS.mkdirAll(dirs)
                .then(() => __awaiter(this, void 0, void 0, function* () {
                try {
                    yield OS.API.VFS.mktpl(files, this.basedir(), (data) => {
                        return data.format(name, `${path}/${name}`);
                    });
                    this.app.currdir = rpath.asFileHandle();
                    this.app.toggleSideBar();
                    return this.app.eum.active.openFile(`${rpath}/README.md`.asFileHandle());
                }
                catch (e) {
                    return this.logger().error(__("Unable to create template files: {0}", e.stack));
                }
            }))
                .catch((e) => this.logger().error(__("Unable to create project directory: {0}", e.stack)));
        }
        verify_coffee(list) {
            return new Promise((resolve, reject) => {
                if (list.length === 0) {
                    return resolve();
                }
                const file = list.splice(0, 1)[0].asFileHandle();
                this.logger().info(__("Verifying: {0}", file.path));
                return file
                    .read()
                    .then((data) => {
                    try {
                        CoffeeScript.nodes(data);
                        return this.verify_coffee(list)
                            .then(() => resolve())
                            .catch((e) => reject(__e(e)));
                    }
                    catch (ex) {
                        return reject(__e(ex));
                    }
                })
                    .catch((e) => reject(__e(e)));
            });
        }
        load_corelib(path) {
            return new Promise((resolve, reject) => __awaiter(this, void 0, void 0, function* () {
                if (AntOSDK.corelib["ts"]) {
                    return resolve(AntOSDK.corelib["ts"]);
                }
                try {
                    const code = yield OS.API.VFS.readFileFromZip(`${path}.zip`, "text");
                    AntOSDK.corelib["ts"] = ts.createSourceFile(path, code, ts.ScriptTarget.Latest);
                    return resolve(AntOSDK.corelib["ts"]);
                }
                catch (e) {
                    return reject(__e(e));
                }
            }));
        }
        compile_ts(files) {
            return new Promise((resolve, reject) => __awaiter(this, void 0, void 0, function* () {
                if (files.length == 0) {
                    return resolve(undefined);
                }
                const core_lib = "os://packages/CodePad/libs/corelib.d.ts";
                try {
                    yield this.load_corelib(core_lib);
                    const arr = yield OS.API.VFS.read_files(files);
                    const libs = files.map((e) => e);
                    libs.unshift(core_lib);
                    const src_files = {};
                    src_files[core_lib] = AntOSDK.corelib["ts"];
                    for (const i in arr) {
                        src_files[files[i]] = ts.createSourceFile(files[i], arr[i], ts.ScriptTarget.Latest);
                    }
                    let js_code = "";
                    const host = {
                        fileExists: (path) => {
                            return src_files[path] != undefined;
                        },
                        directoryExists: (path) => {
                            return true;
                        },
                        getCurrentDirectory: () => "/",
                        getDirectories: () => [],
                        getCanonicalFileName: (path) => path,
                        getNewLine: () => "\n",
                        getDefaultLibFileName: () => "",
                        getSourceFile: (path) => src_files[path],
                        readFile: (path) => undefined,
                        useCaseSensitiveFileNames: () => true,
                        writeFile: (path, data) => js_code = `${js_code}\n${data}`,
                    };
                    const program = ts.createProgram(libs, {
                        "target": "es6",
                        "skipLibCheck": true,
                    }, host);
                    const result = program.emit();
                    const diagnostics = result.diagnostics.concat((ts.getPreEmitDiagnostics(program)));
                    if (diagnostics.length > 0) {
                        diagnostics.forEach(diagnostic => {
                            if (diagnostic.file) {
                                let { line, character } = ts.getLineAndCharacterOfPosition(diagnostic.file, diagnostic.start);
                                let message = ts.flattenDiagnosticMessageText(diagnostic.messageText, "\n");
                                this.logger().error(`${diagnostic.file.fileName} (${line + 1},${character + 1}): ${message}`);
                            }
                            else {
                                this.logger().error(ts.flattenDiagnosticMessageText(diagnostic.messageText, "\n"));
                            }
                        });
                        return reject(OS.API.throwe(__("Typescript compile error")));
                    }
                    for (const file of files) {
                        this.logger().info(__("Compiled: {0}", file));
                    }
                    resolve(js_code);
                }
                catch (e) {
                    return reject(__e(e));
                }
            }));
        }
        compile(meta) {
            return new Promise((resolve, reject) => __awaiter(this, void 0, void 0, function* () {
                const libs = [
                    `${this.basedir()}/libs/terser.min.js`,
                ];
                if (!meta.coffees)
                    meta.coffees = [];
                if (meta.coffees.length > 0) {
                    libs.push(`${this.basedir()}/libs/coffeescript.js`);
                }
                if (!meta.ts)
                    meta.ts = [];
                if (meta.ts && meta.ts.length > 0) {
                    libs.push("os://scripts/jszip.min.js");
                    libs.push(`${this.basedir()}/libs/typescript.min.js`);
                }
                try {
                    yield this.import(libs);
                    const coffee_list = meta.coffees.map((v) => `${meta.root.trimBy("/")}/${v}`);
                    const ts_list = meta.ts.map((v) => `${meta.root.trimBy("/")}/${v}`);
                    const results = yield Promise.all([
                        this.compile_ts(ts_list),
                        this.compile_coffee(coffee_list)
                    ]);
                    resolve(results.join("\n"));
                }
                catch (e_2) {
                    return reject(__e(e_2));
                }
            }));
        }
        compile_coffee(list) {
            return new Promise((resolve, reject) => __awaiter(this, void 0, void 0, function* () {
                if (list.length == 0) {
                    return resolve("");
                }
                try {
                    yield this.verify_coffee(list.map((x) => x));
                    const code = yield OS.API.VFS.cat(list, "");
                    const jsrc = CoffeeScript.compile(code);
                    for (const file of list) {
                        this.logger().info(__("Compiled: {0}", file));
                    }
                    return resolve(jsrc);
                }
                catch (e_1) {
                    return reject(__e(e_1));
                }
            }));
        }
        build(meta, debug) {
            return new Promise((resolve, reject) => __awaiter(this, void 0, void 0, function* () {
                try {
                    this.logger().info(__("Building the package", meta.name));
                    yield OS.API.VFS.mkdirAll([`${meta.root}/build`,]);
                    yield OS.API.VFS.mkdirAll([`${meta.root}/build/debug`, `${meta.root}/build/release`]);
                    const src = yield this.compile(meta);
                    let code = yield OS.API.VFS.cat(meta.javascripts.map(v => `${meta.root}/${v}`), src);
                    if (!debug) {
                        const options = {
                            toplevel: true,
                            compress: {
                                passes: 3,
                            },
                            mangle: true,
                            output: {},
                        };
                        const result = Terser.minify(code, options);
                        if (result.error) {
                            this.logger().error(__("Unable to minify code: {0}", result.error));
                        }
                        else {
                            code = result.code;
                        }
                    }
                    if (code != "")
                        yield `${meta.root}/build/debug/main.js`
                            .asFileHandle()
                            .setCache(code)
                            .write("text/plain");
                    const txt = yield OS.API.VFS.cat(meta.css.map(v => `${meta.root}/${v}`), "");
                    if (txt != "")
                        yield `${meta.root}/build/debug/main.css`
                            .asFileHandle()
                            .setCache(txt)
                            .write("text/plain");
                    yield OS.API.VFS.copy(meta.copies.map(v => `${meta.root}/${v}`), `${meta.root}/build/debug`);
                    resolve();
                }
                catch (e) {
                    return reject(__e(e));
                }
            }));
        }
        run(meta) {
            `${meta.root}/build/debug/package.json`
                .asFileHandle()
                .read("json")
                .then((v) => {
                v.text = v.name;
                v.path = `${meta.root}/build/debug`;
                v.filename = meta.name;
                v.type = "app";
                v.mime = "antos/app";
                if (v.icon) {
                    v.icon = `${v.path}/${v.icon}`;
                }
                if (!v.iconclass && !v.icon) {
                    v.iconclass = "fa fa-adn";
                }
                this.logger().info(__("Installing..."));
                OS.setting.system.packages[meta.name] = v;
                this.logger().info(__("Running {0}...", meta.name));
                return OS.GUI.forceLaunch(meta.name, []);
            });
        }
    }
    AntOSDK.corelib = {};
    App.extensions.AntOSDK = AntOSDK;
})(OS || (OS = {}));
