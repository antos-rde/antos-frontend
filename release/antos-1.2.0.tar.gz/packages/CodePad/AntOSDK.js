var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var OS;
(function (OS) {
    const App = OS.application.CodePad;
    class AntOSDK extends App.BaseExtension {
        constructor(app) {
            super(app);
        }
        create() {
            this.app
                .openDialog("FileDialog", {
                title: "__(New Project at)",
                file: { basename: __("ProjectName") },
                mimes: ["dir"],
            })
                .then((d) => {
                this.logger().clear();
                return this.mktpl(d.file.path, d.name, true);
            });
        }
        init() {
            this.logger().clear();
            const dir = this.app.currdir;
            if (!dir || !dir.basename) {
                return this.create();
            }
            dir.read().then((d) => {
                if (d.error) {
                    return this.logger().error(__("Cannot read folder: {0}", dir.path));
                }
                if (d.result.length !== 0) {
                    return this.logger().error(__("The folder is not empty: {0}", dir.path));
                }
                this.mktpl(dir.parent().path, dir.basename);
            });
        }
        buildnrun() {
            this.logger().clear();
            this.metadata("project.json")
                .then((meta) => __awaiter(this, void 0, void 0, function* () {
                try {
                    yield this.build(meta, true);
                    try {
                        return this.run(meta);
                    }
                    catch (e) {
                        return this.logger().error(__("Unable to run project: {0}", e.stack));
                    }
                }
                catch (e_1) {
                    return this.logger().error(__("Unable to build project: {0}", e_1.stack));
                }
            }))
                .catch((e) => this.logger().error(__("Unable to read meta-data: {0}", e.stack)));
        }
        release() {
            this.logger().clear();
            this.metadata("project.json")
                .then((meta) => __awaiter(this, void 0, void 0, function* () {
                try {
                    yield this.build(meta, false);
                    try {
                        return this.mkar(`${meta.root}/build/debug`, `${meta.root}/build/release/${meta.name}.zip`);
                    }
                    catch (e) {
                        return this.logger().error(__("Unable to create package archive: {0}", e.stack));
                    }
                }
                catch (e_1) {
                    return this.logger().error(__("Unable to build project: {0}", e_1.stack));
                }
            }))
                .catch((e) => this.logger().error(__("Unable to read meta-data: {0}", e.stack)));
        }
        mktpl(path, name, flag) {
            const rpath = `${path}/${name}`;
            const dirs = [
                `${rpath}/javascripts`,
                `${rpath}/css`,
                `${rpath}/coffees`,
                `${rpath}/ts`,
                `${rpath}/assets`,
            ];
            if (flag) {
                dirs.unshift(rpath);
            }
            const files = [
                ["templates/sdk-main-coffee.tpl", `${rpath}/coffees/main.coffee`],
                ["templates/sdk-main-ts.tpl", `${rpath}/ts/main.ts`],
                ["templates/sdk-package.tpl", `${rpath}/package.json`],
                ["templates/sdk-project.tpl", `${rpath}/project.json`],
                ["templates/sdk-README.tpl", `${rpath}/README.md`],
                ["templates/sdk-scheme.tpl", `${rpath}/assets/scheme.html`],
            ];
            this.mkdirAll(dirs)
                .then(() => __awaiter(this, void 0, void 0, function* () {
                try {
                    yield this.mkfileAll(files, path, name);
                    this.app.currdir = rpath.asFileHandle();
                    this.app.toggleSideBar();
                    return this.app.eum.active.openFile(`${rpath}/README.md`.asFileHandle());
                }
                catch (e) {
                    return this.logger().error(__("Unable to create template files: {0}", e.stack));
                }
            }))
                .catch((e) => this.logger().error(__("Unable to create project directory: {0}", e.stack)));
        }
        verify_coffee(list) {
            return new Promise((resolve, reject) => {
                if (list.length === 0) {
                    return resolve();
                }
                const file = list.splice(0, 1)[0].asFileHandle();
                this.logger().info(__("Verifying: {0}", file.path));
                return file
                    .read()
                    .then((data) => {
                    try {
                        CoffeeScript.nodes(data);
                        return this.verify_coffee(list)
                            .then(() => resolve())
                            .catch((e) => reject(__e(e)));
                    }
                    catch (ex) {
                        return reject(__e(ex));
                    }
                })
                    .catch((e) => reject(__e(e)));
            });
        }
        load_corelib(path) {
            return new Promise((resolve, reject) => __awaiter(this, void 0, void 0, function* () {
                if (AntOSDK.corelib["ts"]) {
                    return resolve(AntOSDK.corelib["ts"]);
                }
                try {
                    const code = yield this.loadzip(`${path}.zip`, "text");
                    AntOSDK.corelib["ts"] = ts.createSourceFile(path, code, ts.ScriptTarget.Latest);
                    return resolve(AntOSDK.corelib["ts"]);
                }
                catch (e) {
                    return reject(__e(e));
                }
            }));
        }
        compile_ts(files) {
            return new Promise((resolve, reject) => __awaiter(this, void 0, void 0, function* () {
                if (files.length == 0) {
                    return resolve(undefined);
                }
                const core_lib = "os://packages/CodePad/libs/corelib.d.ts";
                try {
                    yield this.load_corelib(core_lib);
                    const arr = [];
                    this.read_files(files, arr).then((_result) => {
                        const libs = arr.map((e) => e.path);
                        libs.unshift(core_lib);
                        const src_files = {};
                        src_files[core_lib] = AntOSDK.corelib["ts"];
                        for (const el of arr) {
                            src_files[el.path] = ts.createSourceFile(el.path, el.content, ts.ScriptTarget.Latest);
                        }
                        let js_code = "";
                        const host = {
                            fileExists: (path) => {
                                return src_files[path] != undefined;
                            },
                            directoryExists: (path) => {
                                return true;
                            },
                            getCurrentDirectory: () => "/",
                            getDirectories: () => [],
                            getCanonicalFileName: (path) => path,
                            getNewLine: () => "\n",
                            getDefaultLibFileName: () => "",
                            getSourceFile: (path) => src_files[path],
                            readFile: (path) => undefined,
                            useCaseSensitiveFileNames: () => true,
                            writeFile: (path, data) => js_code = `${js_code}\n${data}`,
                        };
                        const program = ts.createProgram(libs, {
                            "target": "es6",
                            "skipLibCheck": true,
                        }, host);
                        const result = program.emit();
                        const diagnostics = result.diagnostics.concat((ts.getPreEmitDiagnostics(program)));
                        if (diagnostics.length > 0) {
                            diagnostics.forEach(diagnostic => {
                                if (diagnostic.file) {
                                    let { line, character } = ts.getLineAndCharacterOfPosition(diagnostic.file, diagnostic.start);
                                    let message = ts.flattenDiagnosticMessageText(diagnostic.messageText, "\n");
                                    this.logger().error(`${diagnostic.file.fileName} (${line + 1},${character + 1}): ${message}`);
                                }
                                else {
                                    this.logger().error(ts.flattenDiagnosticMessageText(diagnostic.messageText, "\n"));
                                }
                            });
                            return reject(OS.API.throwe(__("Typescript compile error")));
                        }
                        resolve(js_code);
                    })
                        .catch((e) => { reject(__e(e)); });
                }
                catch (e) {
                    return reject(__e(e));
                }
            }));
        }
        compile(meta) {
            return new Promise((resolve, reject) => __awaiter(this, void 0, void 0, function* () {
                const libs = [
                    `${this.basedir()}/libs/terser.min.js`,
                ];
                if (meta.coffees.length > 0) {
                    libs.push(`${this.basedir()}/libs/coffeescript.js`);
                }
                if (meta.ts.length > 0) {
                    libs.push("os://scripts/jszip.min.js");
                    libs.push(`${this.basedir()}/libs/typescript.min.js`);
                }
                try {
                    yield this.import(libs);
                    const coffee_list = meta.coffees.map((v) => `${meta.root.trimBy("/")}/${v}`);
                    const ts_list = meta.ts.map((v) => `${meta.root.trimBy("/")}/${v}`);
                    Promise.all([
                        this.compile_ts(ts_list),
                        this.compile_coffee(coffee_list)
                    ]).then((js_codes) => {
                        resolve(js_codes.join("\n"));
                    }).catch((e_1) => reject(__e(e_1)));
                }
                catch (e_2) {
                    return reject(__e(e_2));
                }
            }));
        }
        compile_coffee(list) {
            return new Promise((resolve, reject) => __awaiter(this, void 0, void 0, function* () {
                if (list.length == 0) {
                    return resolve("");
                }
                try {
                    yield this.verify_coffee(list.map((x) => x));
                    try {
                        const code = yield this.cat(list, "");
                        const jsrc = CoffeeScript.compile(code);
                        this.logger().info(__("Compiled successful"));
                        return resolve(jsrc);
                    }
                    catch (e) {
                        return reject(__e(e));
                    }
                }
                catch (e_1) {
                    return reject(__e(e_1));
                }
            }));
        }
        build(meta, debug) {
            const dirs = [
                `${meta.root}/build`,
                `${meta.root}/build/debug`,
                `${meta.root}/build/release`,
            ];
            return new Promise((resolve, reject) => __awaiter(this, void 0, void 0, function* () {
                try {
                    yield this.mkdirAll(dirs);
                    try {
                        const src = yield this.compile(meta);
                        let v;
                        try {
                            let jsrc = yield this.cat((() => {
                                const result = [];
                                for (v of meta.javascripts) {
                                    result.push(`${meta.root}/${v}`);
                                }
                                return result;
                            })(), src);
                            yield new Promise(function (r, e) {
                                return __awaiter(this, void 0, void 0, function* () {
                                    let code = jsrc;
                                    if (!debug) {
                                        const options = {
                                            toplevel: true,
                                            compress: {
                                                passes: 3,
                                            },
                                            mangle: true,
                                            output: {},
                                        };
                                        const result_1 = Terser.minify(jsrc, options);
                                        if (result_1.error) {
                                            this.logger().error(__("Unable to minify code: {0}", result_1.error));
                                        }
                                        else {
                                            ({ code } = result_1);
                                        }
                                    }
                                    try {
                                        const d = yield `${meta.root}/build/debug/main.js`
                                            .asFileHandle()
                                            .setCache(code)
                                            .write("text/plain");
                                        return r();
                                    }
                                    catch (ex) {
                                        return e(__e(ex));
                                    }
                                });
                            });
                            yield new Promise((r, e) => __awaiter(this, void 0, void 0, function* () {
                                const txt = yield this.cat((() => {
                                    const result1 = [];
                                    for (v of meta.css) {
                                        result1.push(`${meta.root}/${v}`);
                                    }
                                    return result1;
                                })(), "");
                                if (txt === "") {
                                    return r();
                                }
                                try {
                                    const d_1 = yield `${meta.root}/build/debug/main.css`
                                        .asFileHandle()
                                        .setCache(txt)
                                        .write("text/plain");
                                    return r();
                                }
                                catch (ex_1) {
                                    return e(__e(ex_1));
                                }
                            }));
                            yield this.copy((() => {
                                const result1_1 = [];
                                for (v of meta.copies) {
                                    result1_1.push(`${meta.root}/${v}`);
                                }
                                return result1_1;
                            })(), `${meta.root}/build/debug`);
                            return resolve();
                        }
                        catch (e) {
                            return reject(__e(e));
                        }
                    }
                    catch (e_1) {
                        return reject(__e(e_1));
                    }
                }
                catch (e_2) {
                    return reject(__e(e_2));
                }
            }));
        }
        run(meta) {
            `${meta.root}/build/debug/package.json`
                .asFileHandle()
                .read("json")
                .then((v) => {
                v.text = v.name;
                v.path = `${meta.root}/build/debug`;
                v.filename = meta.name;
                v.type = "app";
                v.mime = "antos/app";
                if (v.icon) {
                    v.icon = `${v.path}/${v.icon}`;
                }
                if (!v.iconclass && !v.icon) {
                    v.iconclass = "fa fa-adn";
                }
                this.logger().info(__("Installing..."));
                OS.setting.system.packages[meta.name] = v;
                this.logger().info(__("Running {0}...", meta.name));
                return OS.GUI.forceLaunch(meta.name, []);
            });
        }
    }
    AntOSDK.corelib = {};
    App.extensions.AntOSDK = AntOSDK;
})(OS || (OS = {}));
