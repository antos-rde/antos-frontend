// Copyright 2017-2020 Xuan Sang LE <xsang.le AT gmail DOT com>
// AnTOS Web desktop is is licensed under the GNU General Public
// License v3.0, see the LICENCE file for more information
// This program is free software: you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation, either version 3 of
// the License, or (at your option) any later version.
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// General Public License for more details.
// You should have received a copy of the GNU General Public License
//along with this program. If not, see https://www.gnu.org/licenses/.
"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
/**
 * Reference to the global this
 */
const Ant = this;
/**
 * This namespace is the main entry point of AntOS
 * API
 */
var OS;
(function (OS) {
    /**
     * Return an range of numbers
     *
     * @param {number} left start of the range
     * @param {number} right end of the range
     * @param {boolean} inclusive specifies whether the
     * `right` of the range is included in the returned array
     * @returns {number[]}
     */
    function __range__(left, right, inclusive) {
        let range = [];
        let ascending = left < right;
        let end = !inclusive ? right : ascending ? right + 1 : right - 1;
        for (let i = left; ascending ? i < end : i > end; ascending ? i++ : i--) {
            range.push(i);
        }
        return range;
    }
    Ant.__ = function (...args) {
        if (!(args.length > 0)) {
            return "Undefined";
        }
        const d = args[0];
        d.l();
        return new FormattedString(d, __range__(1, args.length - 1, true).map((i) => args[i]));
    };
    Ant.__e = function (e) {
        const reason = new Error(e.toString().replace(/^Error: /g, ""));
        reason.stack += "\nCaused By:\n" + e.stack;
        return reason;
    };
    /**
     * Represent a translatable formatted string
     *
     * @export
     * @class FormattedString
     */
    class FormattedString {
        /**
         * Creates an instance of FormattedString.
         * @param {string} fs format string
         * @param {any[]} args input values of the format patterns
         * @memberof FormattedString
         */
        constructor(fs, args) {
            this.fs = fs;
            this.values = [];
            if (!args) {
                return;
            }
            for (let i = 0, end = args.length - 1, asc = 0 <= end; asc ? i <= end : i >= end; asc ? i++ : i--) {
                this.values[i] = args[i];
            }
        }
        /**
         * Convert FormattedString to String
         *
         * @returns {string}
         * @memberof FormattedString
         */
        toString() {
            return this.__();
        }
        /**
         * Translate the format string to the current system
         * locale language, format the string with values and
         * then converted it to normal `string`
         *
         * @returns {string}
         * @memberof FormattedString
         */
        __() {
            return this.fs
                .l()
                .replace(/{(\d+)}/g, (match, n) => {
                if (typeof this.values[n] !== "undefined") {
                    return this.values[n].__();
                }
                else {
                    return match;
                }
            });
        }
        /**
         * Return the hash number of the formatted string
         *
         * @returns {number}
         * @memberof FormattedString
         */
        hash() {
            return this.__().hash();
        }
        /**
         * Match the formatted string against a regular expression
         * a string pattern
         *
         * @param {(string | RegExp)} t string or regular expression
         * @returns {RegExpMatchArray}
         * @memberof FormattedString
         */
        match(t) {
            return this.__().match(t);
        }
        /**
         * Convert the formatted string to Base^$
         *
         * @returns {string}
         * @memberof FormattedString
         */
        asBase64() {
            return this.__().asBase64();
        }
        /**
         * Un escape the formatted string
         *
         * @returns {string}
         * @memberof FormattedString
         */
        unescape() {
            return this.__().unescape();
        }
        /**
         * Escape the formatted string
         *
         * @returns {string}
         * @memberof FormattedString
         */
        escape() {
            return this.__().escape();
        }
        /**
         * Convert the formatted string to uint8 array
         *
         * @returns {Uint8Array}
         * @memberof FormattedString
         */
        asUint8Array() {
            return this.__().asUint8Array();
        }
        /**
         * Input values for the format string
         *
         * @param {...any[]} args
         * @memberof FormattedString
         */
        format(...args) {
            __range__(0, args.length - 1, true).map((i) => (this.values[i] = args[i]));
        }
    }
    OS.FormattedString = FormattedString;
    /**
     * This class represents the Version number format used by AntOS. A typical
     * AntOS version number is in the following format:
     *
     * ```
     * [major_number].[minor_number].[patch]-[branch]-[build ID])
     *
     * e.g.: 1.2.3-r-b means that:
     * - version major number is 1
     * - version minor number is 2
     * - patch version is 3
     * - the current branch is release `r`
     * - build ID (optional)
     * ```
     *
     * @export
     * @class Version
     */
    class Version {
        /**
         *Creates an instance of Version.
         *
         * @param {string} string string represents the version
         * @memberof Version
         */
        constructor(string) {
            this.version_string = string;
        }
        /**
         * Setter/getter to set the version string to the object
         *
         * @memberof Version
         */
        set version_string(v) {
            if (!v) {
                this.string = undefined;
                this.major = undefined;
                this.minor = undefined;
                this.patch = undefined;
                this.build_id = undefined;
                return;
            }
            this.string = v;
            const arr = this.string.split("-");
            const br = {
                r: 3,
                b: 2,
                a: 1,
            };
            this.branch = 3;
            if (arr.length >= 2 && br[arr[1]]) {
                this.branch = br[arr[1]];
                if (arr[2]) {
                    this.build_id = arr[2];
                }
            }
            const mt = arr[0].match(/\d+/g);
            if (!mt) {
                API.throwe(__("Version string is in invalid format: {0}", this.string));
            }
            this.major = 0;
            this.minor = 0;
            this.patch = 0;
            if (mt.length >= 1) {
                this.major = Number(mt[0]);
            }
            if (mt.length >= 2) {
                this.minor = Number(mt[1]);
            }
            if (mt.length >= 3) {
                this.patch = Number(mt[2]);
            }
        }
        get version_string() {
            return this.string;
        }
        /**
         * Compare the current version with another version.
         *
         * The comparison priority is `branch>major>minor>patch`.
         *
         * For the branch, the priority is `r>b>a`
         *
         * @param {(string | Version)} o version string or object
         * @returns {(0 | 1 | -1)}
         * Return 0 if the two versions are the same, 1 if
         * the current version is newer than the input version,
         * otherwise return -1
         * @memberof Version
         */
        compare(o) {
            const other = o.__v();
            if (this.branch > other.branch) {
                return 1;
            }
            if (this.branch < other.branch) {
                return -1;
            }
            if (this.major === other.major &&
                this.minor === other.minor &&
                this.patch === other.patch) {
                return 0;
            }
            if (this.major > other.major) {
                return 1;
            }
            if (this.major < other.major) {
                return -1;
            }
            if (this.minor > other.minor) {
                return 1;
            }
            if (this.minor < other.minor) {
                return -1;
            }
            if (this.patch > other.patch) {
                return 1;
            }
            return -1;
        }
        /**
         * Check if the current version is newer than
         * the input version
         *
         * @param {(string | Version)} o version string or object
         * @returns {boolean}
         * @memberof Version
         */
        nt(o) {
            return this.compare(o) === 1;
        }
        /**
         * Check if the current version is older than
         * the input version
         *
         * @param {(string | Version)} o version string or object
         * @returns {boolean}
         * @memberof Version
         */
        ot(o) {
            return this.compare(o) === -1;
        }
        /**
         * Return itself
         *
         * @returns {Version}
         * @memberof Version
         */
        __v() {
            return this;
        }
        /**
         * Convert Version object to string
         *
         * @returns {string}
         * @memberof Version
         */
        toString() {
            return this.string;
        }
    }
    OS.Version = Version;
    Object.defineProperty(Object.prototype, "__", {
        value() {
            if (this)
                return this.toString();
        },
        enumerable: false,
        writable: true,
    });
    String.prototype.hash = function () {
        let hash = 5381;
        let i = this.length;
        while (i) {
            hash = (hash * 33) ^ this.charCodeAt(--i);
        }
        return hash >>> 0;
    };
    String.prototype.__v = function () {
        return new Version(this);
    };
    String.prototype.asBase64 = function () {
        const tmp = encodeURIComponent(this);
        return btoa(tmp.replace(/%([0-9A-F]{2})/g, (match, p1) => String.fromCharCode(parseInt(p1, 16))));
    };
    String.prototype.escape = function () {
        return this.replace(/[\0\x08\x09\x1a\n\r"'\\\%]/g, function (c) {
            switch (c) {
                case "\0":
                    return "\\0";
                case "\x08":
                    return "\\b";
                case "\x09":
                    return "\\t";
                case "\x1a":
                    return "\\z";
                case "\n":
                    return "\\n";
                case "\r":
                    return "\\r";
                case '"':
                case "'":
                case "\\":
                case "%":
                    return "\\" + c; // prepends a backslash to backslash, percent,
                // and double/single quotes
                default:
                    return c;
            }
        });
    };
    String.prototype.unescape = function () {
        let json = JSON.parse(`{ "text": "${this}"}`);
        return json.text;
    };
    String.prototype.asUint8Array = function () {
        let bytes = [];
        for (let i = 0, end = this.length - 1, asc = 0 <= end; asc ? i <= end : i >= end; asc ? i++ : i--) {
            bytes.push(this.charCodeAt(i));
        }
        return new Uint8Array(bytes);
    };
    if (!String.prototype.format) {
        String.prototype.format = function (...args) {
            return this.replace(/{(\d+)}/g, function (match, number) {
                if (typeof args[number] !== "undefined") {
                    return args[number].__();
                }
                else {
                    return match;
                }
            });
        };
    }
    String.prototype.f = function (...args) {
        return new FormattedString(this, args);
    };
    String.prototype.__ = function () {
        const match = this.match(/^__\((.*)\)$/);
        if (match) {
            return match[1].l();
        }
        return this;
    };
    String.prototype.l = function () {
        if (!API.lang[this]) {
            API.lang[this] = this;
        }
        return API.lang[this];
    };
    String.prototype.trimFromLeft = function (charlist) {
        if (charlist === undefined)
            charlist = "s";
        return this.replace(new RegExp("^[" + charlist + "]+"), "");
    };
    String.prototype.trimFromRight = function (charlist) {
        if (charlist === undefined)
            charlist = "s";
        return this.replace(new RegExp("[" + charlist + "]+$"), "");
    };
    String.prototype.trimBy = function (charlist) {
        return this.trimFromLeft(charlist).trimFromRight(charlist);
    };
    Date.prototype.toString = function () {
        let dd = this.getDate();
        let mm = this.getMonth() + 1;
        const yyyy = this.getFullYear();
        let hh = this.getHours();
        let mi = this.getMinutes();
        let se = this.getSeconds();
        if (dd < 10) {
            dd = `0${dd}`;
        }
        if (mm < 10) {
            mm = `0${mm}`;
        }
        if (hh < 10) {
            hh = `0${hh}`;
        }
        if (mi < 10) {
            mi = `0${mi}`;
        }
        if (se < 10) {
            se = `0${se}`;
        }
        return `${dd}/${mm}/${yyyy} ${hh}:${mi}:${se}`;
    };
    Date.prototype.timestamp = function () {
        return (this.getTime() / 1000) | 0;
    };
    /**
     * Variable represents the current AntOS version, it
     * is an instance of [[Version]]
     */
    OS.VERSION = new Version(undefined);
    /**
     * Variable represents the current AntOS source code repository
     * is an instance of [[string]]
     */
    OS.REPOSITORY = "https://github.com/lxsang/antos";
    /**
    * Indicate whether the current de
    */
    OS.mobile = false;
    /**
     * Register a model prototype to the system namespace.
     * There are two types of model to be registered, if the model
     * is of type [[SubWindow]], its prototype will be registered
     * in the [[dialogs]] namespace, otherwise, if the model type
     * is [[Application]] or [[Service]], its prototype will be
     * registered in the [[application]] namespace.
     *
     * When a model is loaded in the system, its prototype is registered
     * for later uses
     *
     * @export
     * @param {string} name class name
     * @param {*} x the corresponding class
     * @returns {*}
     */
    function register(name, x) {
        if (x.type === OS.ModelType.SubWindow) {
            OS.GUI.dialogs[name] = x;
        }
        else {
            OS.application[name] = x;
        }
    }
    OS.register = register;
    /**
     * This function cleans up the entire system and
     * makes sure the system is in a new and clean session.
     * It performs the following operations:
     *
     * - Kill all running processes
     * - Unregister all global events and reset the  global
     * announcement system
     * - Clear the current theme
     * - Reset process manager and all system settings
     *
     * @export
     */
    function cleanup() {
        console.log("Clean up system");
        for (let a in OS.PM.processes) {
            const v = OS.PM.processes[a];
            OS.PM.killAll(a, true);
        }
        if (OS.announcer.observable) {
            OS.announcer.observable.off("*");
        }
        $(window).off("keydown");
        $("#workspace").off("mouseover");
        delete OS.announcer.observable;
        $("#wrapper").empty();
        OS.GUI.clearTheme();
        OS.announcer.observable = new API.Announcer();
        OS.announcer.quota = 0;
        OS.resetSetting();
        OS.PM.processes = {};
        OS.PM.pidalloc = 0;
    }
    OS.cleanup = cleanup;
    /**
     * Booting up AntOS. This function checks whether the user
     * is successfully logged in, then call [[startAntOS]], otherwise
     * it shows the login screen
     *
     * @export
     */
    function boot() {
        //first login
        console.log("Booting system");
        // check whether we are on mobile device
        API.handle
            .auth()
            .then(function (d) {
            // in case someone call it more than once :)
            if (d.error) {
                // show login screen
                return OS.GUI.login();
            }
            else {
                // startX :)
                return OS.GUI.startAntOS(d.result);
            }
        })
            .catch((e) => console.error(e));
    }
    OS.boot = boot;
    /**
     * Placeholder for all the callbacks that are called when the system
     * exits. These callbacks are useful when an application or service wants
     * to perform a particular task before shuting down the system
     */
    OS.cleanupHandles = {};
    /**
     * Perform the system shutdown operation. This function calls all
     * clean up handles in [[cleanupHandles]], then save the system setting
     * before exiting
     *
     * @export
     */
    function exit() {
        //do clean up first
        const promises = [];
        for (let n in OS.cleanupHandles) {
            promises.push(OS.cleanupHandles[n]());
        }
        promises.push(API.handle.setting());
        Promise.all(promises)
            .then(function (r) {
            return __awaiter(this, void 0, void 0, function* () {
                cleanup();
                const d = yield API.handle.logout();
                return boot();
            });
        })
            .catch((e) => console.error(e));
    }
    OS.exit = exit;
    /**
     * Register a callback to the system [[cleanupHandles]]
     *
     * @export
     * @param {string} n callback string name
     * @param {() => void} f the callback handle
     * @returns
     */
    function onexit(n, f) {
        if (!OS.cleanupHandles[n]) {
            return (OS.cleanupHandles[n] = f);
        }
    }
    OS.onexit = onexit;
    /**
     * The namespace API is dedicated to the definition of the core system APIs
     * used by AntOS and its applications. The following core APIs are defined:
     *
     * - The AntOS announcement system
     * - Virtual File system
     * - Virtual Database
     * - Low-level REST based client-server communication
     * - Dependencies management
     * - System utilities
     *
     * These APIs are considered as middle-ware that abstracts the client-server
     * communication and provide the application layer with a standardized APIs
     * for file/database access, system events handling (announcement), automatic
     * dependencies resolving, etc.
     */
    let API;
    (function (API) {
        /**
         * Placeholder to store all loaded shared libraries. Once
         * a shared library is firstly loaded, its identity will be
         * stored in this variable. Based on this information, in
         * the next use of the library, the system knows that the
         * library is already loaded and ready to use.
         *
         * A shared library can be a javascript or a CSS file.
         */
        API.shared = {};
        /**
         * Placeholder for all global search handles registered to the system.
         * These callbacks will be called when user performs the search operation
         * in the spotlight UI.
         *
         * Applications can define their own search handle to provide the spotlight UI
         * with additional search results
         *
         */
        API.searchHandle = {};
        /**
         * Placeholder of the current system locale dictionary, the system uses
         * this dictionary to translate all translatable texts to the current
         * locale language
         */
        API.lang = {};
        /**
         * Re-export the system announcement [[getMID]] function to the
         * core API
         *
         * @export
         * @returns {number}
         */
        function mid() {
            return OS.announcer.getMID();
        }
        API.mid = mid;
        /**
         * REST-based API.
         *
         * Perform a POST request to the server. Data exchanged
         * is in `application/json`
         *
         * @export
         * @param {string} p the server URI
         * @param {*} d data object that will be converted to JSON
         * @returns {Promise<any>} a promise on the result data
         */
        function post(p, d) {
            return new Promise(function (resolve, reject) {
                const q = OS.announcer.getMID();
                API.loading(q, p);
                return $.ajax({
                    type: "POST",
                    url: p,
                    contentType: "application/json",
                    data: JSON.stringify(d, function (k, v) {
                        if (k === "domel") {
                            return undefined;
                        }
                        return v;
                    }, 4),
                    dataType: "json",
                    success: null,
                })
                    .done(function (data) {
                    API.loaded(q, p, "OK");
                    return resolve(data);
                })
                    .fail(function (j, s, e) {
                    API.loaded(q, p, "FAIL");
                    return reject(API.throwe(s));
                });
            });
        }
        API.post = post;
        /**
         * REST-based API.
         *
         * Perform a GET request and read back the data in
         * `ArrayBuffer` (binary) format. This is useful for
         * binary data reading
         *
         * @export
         * @param {string} p resource URI
         * @returns {Promise<ArrayBuffer>} a promise on the returned binary data
         */
        function blob(p) {
            return new Promise(function (resolve, reject) {
                const q = OS.announcer.getMID();
                const r = new XMLHttpRequest();
                r.open("GET", p, true);
                r.responseType = "arraybuffer";
                r.onload = function (e) {
                    if (this.status === 200 && this.readyState === 4) {
                        API.loaded(q, p, "OK");
                        resolve(this.response);
                    }
                    else {
                        API.loaded(q, p, "FAIL");
                        reject(API.throwe(__("Unable to get blob: {0}", p)));
                    }
                };
                API.loading(q, p);
                r.send();
            });
        }
        API.blob = blob;
        /**
         * REST-based API.
         *
         * Send file to server
         *
         * @export
         * @param {string} p resource URI
         * @param {string} d VFS path of the destination file
         * @returns {Promise<any>}
         */
        function upload(p, d) {
            return new Promise(function (resolve, reject) {
                const q = OS.announcer.getMID();
                //insert a temporal file selector
                const o = $("<input>")
                    .attr("type", "file")
                    .attr("multiple", "true");
                o.on("change", function () {
                    const files = o[0].files;
                    const n_files = files.length;
                    if (n_files > 0)
                        API.loading(q, p);
                    const formd = new FormData();
                    formd.append("path", d);
                    jQuery.each(files, (i, file) => {
                        formd.append(`upload-${i}`, file);
                    });
                    return $.ajax({
                        url: p,
                        data: formd,
                        type: "POST",
                        contentType: false,
                        processData: false,
                    })
                        .done(function (data) {
                        API.loaded(q, p, "OK");
                        resolve(data);
                    })
                        .fail(function (j, s, e) {
                        API.loaded(q, p, "FAIL");
                        o.remove();
                        reject(API.throwe(s));
                    });
                });
                return o.trigger("click");
            });
        }
        API.upload = upload;
        /**
         * REST-based API.
         *
         * Download a file
         *
         * @export
         * @param {string} name file name
         * @param {*} b file content
         */
        function saveblob(name, b) {
            const url = window.URL.createObjectURL(b);
            const o = $("<a>")
                .attr("href", url)
                .attr("download", name)
                .css("display", "none")
                .appendTo("body");
            o[0].click();
            window.URL.revokeObjectURL(url);
            o.remove();
        }
        API.saveblob = saveblob;
        /**
         * Helper function to trigger the global `loading`
         * event. This event should be triggered in the
         * beginning of a heavy task
         *
         * @export
         * @param {number} q message id, see [[mid]]
         * @param {string} p message string
         */
        function loading(q, p) {
            const data = {};
            data.id = q;
            data.message = p;
            data.name = p;
            data.u_data = 0; //PM.pidactive;
            OS.announcer.trigger("loading", data);
        }
        API.loading = loading;
        /**
         * Helper function to trigger the global `loaded`
         * event: This event should be triggered in the
         * end of a heavy task that has previously triggered
         * the `loading` event
         *
         * @export
         * @param {number} q the message id of the corresponding `loading` event
         * @param {string} p the message string
         * @param {string} m message status  (`OK` of `FAIL`)
         */
        function loaded(q, p, m) {
            const data = {};
            data.id = q;
            data.message = p;
            data.name = "OS";
            data.u_data = false;
            OS.announcer.trigger("loaded", data);
        }
        API.loaded = loaded;
        /**
         * Perform an REST GET request
         *
         * @export
         * @param {string} p the URI of the request
         * @param {string} [t=undefined] the response data type:
         * - jsonp: the response is an json object
         * - script: the response is a javascript code
         * - xm, html: the response is a XML/HTML object
         * - text: plain text
         * @returns {Promise<any>} a Promise on the requested data
         */
        function get(p, t = undefined) {
            return new Promise(function (resolve, reject) {
                const conf = {
                    type: "GET",
                    url: p,
                };
                if (t) {
                    conf.dataType = t;
                }
                const q = OS.announcer.getMID();
                API.loading(q, p);
                return $.ajax(conf)
                    .done(function (data) {
                    API.loaded(q, p, "OK");
                    return resolve(data);
                })
                    .fail(function (j, s, e) {
                    API.loaded(q, p, "FAIL");
                    return reject(API.throwe(s));
                });
            });
        }
        API.get = get;
        /**
         * REST-based API
         *
         * Perform a GET operation and executed the returned
         * content as javascript
         *
         * @export
         * @param {string} p URI resource
         * @returns {Promise<any>} promise on the executed content
         */
        function script(p) {
            return API.get(p, "script");
        }
        API.script = script;
        /**
         * REST-based API
         *
         * Get the content of a global asset resource stored
         * in `os://resources/`
         *
         * @export
         * @param {string} r relative path to the resource
         * @returns {Promise<any>} promise on the returned content
         */
        function resource(r) {
            const path = `resources/${r}`;
            return API.get(path);
        }
        API.resource = resource;
        /**
         * Helper function to verify whether a shared library
         * is loaded and ready to use
         *
         * @export
         * @param {string} l path to the library
         * @returns {boolean}
         */
        function libready(l) {
            return API.shared[l] || false;
        }
        API.libready = libready;
        /**
         * Load a shared library if not ready
         *
         * @export
         * @param {string} l VFS path to the library
         * @param {string} force force reload library
         * @returns {Promise<void>} a promise on the result data
         */
        function requires(l, force = false) {
            return new Promise((resolve, reject) => __awaiter(this, void 0, void 0, function* () {
                try {
                    if (!API.shared[l] || force) {
                        const libfp = l.asFileHandle();
                        switch (libfp.ext) {
                            case "css":
                                yield libfp.onready();
                                $("<link>", {
                                    rel: "stylesheet",
                                    type: "text/css",
                                    href: `${libfp.getlink()}`,
                                }).appendTo("head");
                                API.shared[l] = true;
                                console.log("Loaded :", l);
                                return resolve(undefined);
                            case "js":
                                yield API.script(libfp.getlink());
                                API.shared[l] = true;
                                console.log("Loaded :", l);
                                return resolve(undefined);
                            default:
                                return reject(API.throwe(__("Invalid library: {0}", l)));
                        }
                    }
                    else {
                        console.log(l, "Library exist, no need to load");
                        return resolve();
                    }
                }
                catch (error) {
                    reject(__e(error));
                }
            }));
        }
        API.requires = requires;
        /**
         * Synchronously load a list of shared libraries
         *
         * @export
         * @param {string[]} libs list of shared libraries
         * @returns {Promise<void>}
         */
        function require(libs) {
            return new Promise(function (resolve, reject) {
                if (!(libs.length > 0)) {
                    return resolve();
                }
                const l = libs.splice(0, 1)[0];
                return API.requires(l, false)
                    .catch((e) => reject(__e(e)))
                    .then((_l) => {
                    API.require(libs)
                        .then(() => resolve())
                        .catch((e) => reject(__e(e)));
                });
            });
        }
        API.require = require;
        /**
         * The namespace packages is dedicated to all package management
         * related APIs.
         */
        let packages;
        (function (packages) {
            /**
             * Fetch the package meta-data from the server
             *
             * @export
             * @returns {Promise<RequestResult>} Promise on a [[RequestResult]].
             * A success request result should contain a list of [[PackageMetaType]]
             */
            function fetch() {
                return API.handle.packages({
                    command: "list",
                    args: {
                        paths: (() => {
                            const result = [];
                            for (let k in OS.setting.system.pkgpaths) {
                                const v = OS.setting.system.pkgpaths[k];
                                result.push(v);
                            }
                            return result;
                        })(),
                    },
                });
            }
            packages.fetch = fetch;
            /**
             * Request the server to regenerate the package
             * caches
             *
             * @export
             * @returns {Promise<RequestResult>}
             */
            function cache() {
                return API.handle.packages({
                    command: "cache",
                    args: {
                        paths: (() => {
                            const result = [];
                            for (let k in OS.setting.system.pkgpaths) {
                                const v = OS.setting.system.pkgpaths[k];
                                result.push(v);
                            }
                            return result;
                        })(),
                    },
                });
            }
            packages.cache = cache;
        })(packages = API.packages || (API.packages = {}));
        /**
         * Save the current user setting
         *
         * @export
         * @returns {Promise<RequestResult>} promise on a [[RequestResult]]
         */
        function setting() {
            return API.handle.setting();
        }
        API.setting = setting;
        /**
         * An apigateway allows client side to execute a custom server-side
         * script and get back the result. This gateway is particularly
         * useful in case of performing a task that is not provided by the core
         * API
         *
         * @export
         * @param {GenericObject<any>} d execution indication, provided only when ws is `false`
         * otherwise, `d` should be written directly to the websocket stream as JSON object.
         * Two possible formats of `d`:
         * ```text
         * execute an server-side script file:
         *
         * {
         *  path: [VFS path],
         *  parameters: [parameters of the server-side script]
         * }
         *
         * or, execute directly a snippet of server-side script:
         *
         * { code: [server-side script code snippet as string] }
         *
         * ```
         *
         * @param {boolean} ws flag indicate whether to use websocket for the connection
         * to the gateway API. In case of streaming data, the websocket is preferred
         * @returns {Promise<any>} a promise on the result object (any)
         */
        function apigateway(d, ws) {
            return API.handle.apigateway(d, ws);
        }
        API.apigateway = apigateway;
        /**
         * Perform the global search operation when user enter
         * text in spotlight.
         *
         * This function will call all the search handles stored
         * in [[searchHandle]] and build the search result based
         * on output of these handle
         *
         * @export
         * @param {string} text text to search
         * @returns {any[]}
         */
        function search(text) {
            let r = [];
            for (let k in API.searchHandle) {
                const ret = API.searchHandle[k](text);
                if (ret.length > 0) {
                    /*ret.unshift({
                        text: k,
                        class: "search-header",
                        dataid: "header",
                    });*/
                    r = r.concat(ret);
                }
            }
            return r;
        }
        API.search = search;
        /**
         * Register a search handle to the global [[searchHandle]]
         *
         * @export
         * @param {string} name handle name string
         * @param {(text: string) => any[]} fn search handle
         */
        function onsearch(name, fn) {
            if (!API.searchHandle[name]) {
                API.searchHandle[name] = fn;
            }
        }
        API.onsearch = onsearch;
        /**
         * Set the current system locale: This function will
         * find and load the locale dictionary definition file in the
         * system asset resource, then trigger the global event
         * `systemlocalechange` to translated all translatable text
         * to the target language
         *
         * @export
         * @param {string} name locale name, e.g. `en_GB`
         * @returns {Promise<any>}
         */
        function setLocale(name) {
            return new Promise(function (resolve, reject) {
                return __awaiter(this, void 0, void 0, function* () {
                    const path = `resources/languages/${name}.json`;
                    try {
                        const d = yield API.get(path, "json");
                        OS.setting.system.locale = name;
                        API.lang = d;
                        OS.announcer.ostrigger("systemlocalechange", name);
                        return resolve(d);
                    }
                    catch (e) {
                        return reject(__e(e));
                    }
                });
            });
        }
        API.setLocale = setLocale;
        /**
         * Return an error Object: AntOS use this function to
         * collect information (stack trace) from user reported
         * error.
         *
         * @export
         * @param {(string | FormattedString)} n error string
         * @returns {Error}
         */
        function throwe(n) {
            let err = undefined;
            try {
                throw new Error(n.__());
            }
            catch (e) {
                err = e;
            }
            return err;
        }
        API.throwe = throwe;
        /**
         * Set value to the system clipboard
         *
         * @export
         * @param {string} v clipboard value
         * @returns {boolean}
         */
        function setClipboard(v) {
            const $el = $("#clipboard");
            $el.val(v);
            $el[0].select();
            $el[0].setSelectionRange(0, 99999);
            return document.execCommand("copy");
        }
        API.setClipboard = setClipboard;
        /**
         * Get the clipboard data
         *
         * @export
         * @returns {Promise<any>} Promise on the clipboard data
         */
        function getClipboard() {
            return new Promise(function (resolve, reject) {
                const $el = $("#clipboard");
                if (!navigator.clipboard) {
                    return resolve($el.val());
                }
                return navigator.clipboard
                    .readText()
                    .then((d) => resolve(d))
                    .catch((e) => reject(__e(e)));
            });
        }
        API.getClipboard = getClipboard;
        /**
         * A switcher object is a special object in which
         * each object's property is a boolean option. All object's
         * properties are mutual exclusive. It means that when a property
         * is set to true, all other properties will be reset to false.
         *
         * Example:
         *
         * ```typescript
         * let view = API.switcher("tree", "list", "icon")
         * view.tree = true // view.list = false and view.icon = false
         * view.list = true // view.tree = false and view.icon = false
         * ```
         *
         * @export
         * @returns {*}
         */
        function switcher(...args) {
            let k, v;
            const o = {};
            const p = {};
            for (let i = 0, end = arguments.length - 1, asc = 0 <= end; asc ? i <= end : i >= end; asc ? i++ : i--) {
                p[arguments[i]] = false;
            }
            Object.defineProperty(o, "__p", {
                enumerable: false,
                value: p,
            });
            const fn = function (o, v) {
                return Object.defineProperty(o, v, {
                    enumerable: true,
                    set(value) {
                        for (let k in this.__p) {
                            const l = this.__p[k];
                            this.__p[k] = false;
                        }
                        return (o.__p[v] = value);
                    },
                    get() {
                        return o.__p[v];
                    },
                });
            };
            for (k in o.__p) {
                v = o.__p[k];
                fn(o, k);
            }
            Object.defineProperty(o, "selected", {
                configurable: true,
                enumerable: false,
                get() {
                    for (k in o.__p) {
                        v = o.__p[k];
                        if (v) {
                            return k;
                        }
                    }
                },
            });
            return o;
        }
        API.switcher = switcher;
    })(API = OS.API || (OS.API = {}));
})(OS || (OS = {}));

// Copyright 2017-2018 Xuan Sang LE <xsang.le AT gmail DOT com>
// AnTOS Web desktop is is licensed under the GNU General Public
// License v3.0, see the LICENCE file for more information
// This program is free software: you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation, either version 3 of
// the License, or (at your option) any later version.
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// General Public License for more details.
// You should have received a copy of the GNU General Public License
//along with this program. If not, see https://www.gnu.org/licenses/.
var OS;
(function (OS) {
    /**
     * This namespace is dedicated to everything related to the
     * global system settings
     */
    let setting;
    (function (setting) {
        /**
         * Application settings
         */
        setting.applications = {};
    })(setting = OS.setting || (OS.setting = {}));
    /**
     * Reset the system settings to default values
     *
     * @export
     */
    function resetSetting() {
        setting.desktop = {
            path: "home://.desktop",
            menu: [],
            showhidden: false,
        };
        setting.user = {
            name: undefined,
            username: undefined,
            id: 0,
        };
        setting.appearance = {
            theme: "antos_dark",
            themes: [
                {
                    text: "AntOS light",
                    name: "antos_light",
                },
                {
                    text: "AntOS dark",
                    name: "antos_dark",
                },
            ],
            wp: {
                url: "os://resources/themes/system/wp/wp3.jpg",
                size: "cover",
                repeat: "repeat",
            },
            wps: [],
        };
        setting.VFS = {
            mountpoints: [
                //TODO: multi app try to write to this object, it need to be cloned
                {
                    text: "__(Applications)",
                    path: "app://",
                    iconclass: "fa  fa-adn",
                    type: "app",
                },
                {
                    text: "__(Home)",
                    path: "home://",
                    iconclass: "fa fa-home",
                    type: "fs",
                },
                {
                    text: "__(Desktop)",
                    path: setting.desktop.path,
                    iconclass: "fa fa-desktop",
                    type: "fs",
                },
                {
                    text: "__(OS)",
                    path: "os://",
                    iconclass: "fa fa-inbox",
                    type: "fs",
                },
                {
                    text: "__(Google Drive)",
                    path: "gdv://",
                    iconclass: "fa fa-inbox",
                    type: "fs",
                },
                {
                    text: "__(Shared)",
                    path: "shared://",
                    iconclass: "fa fa-share-square",
                    type: "fs",
                },
            ],
        };
        OS.setting.system = {
            error_report: "https://os.iohub.dev/report",
            locale: "en_GB",
            menu: [],
            packages: {},
            pkgpaths: {
                user: "home://.packages",
                system: "os://packages",
            },
            repositories: [],
            startup: {
                apps: [],
                services: ["Syslog/PushNotification", "Syslog/Calendar"],
                pinned: [],
            },
        };
    }
    OS.resetSetting = resetSetting;
    /**
     * Apply the input parameter object to system settings.
     * This object could be an object loaded from
     * setting JSON file saved on the server.
     *
     * @export
     * @param {*} conf
     */
    function systemSetting(conf) {
        resetSetting();
        if (conf.desktop) {
            setting.desktop = conf.desktop;
        }
        if (conf.applications) {
            setting.applications = conf.applications;
        }
        if (conf.appearance) {
            setting.appearance = conf.appearance;
        }
        if (conf.user) {
            setting.user = conf.user;
        }
        if (conf.VFS) {
            setting.VFS = conf.VFS;
        }
        if (conf.system) {
            setting.system = conf.system;
        }
        if (!setting.VFS.gdrive) {
            setting.VFS.gdrive = {
                CLIENT_ID: "",
                API_KEY: "",
                apilink: "https://apis.google.com/js/api.js",
                DISCOVERY_DOCS: [
                    "https://www.googleapis.com/discovery/v1/apis/drive/v3/rest",
                ],
                SCOPES: "https://www.googleapis.com/auth/drive",
            };
        }
        // default repo
        if (!setting.system.repositories || setting.system.repositories.length === 0) {
            setting.system.repositories = [
                {
                    text: "Github",
                    url: "https://raw.githubusercontent.com/lxsang/antosdk-apps/2.0.x/packages.json"
                }
            ];
        }
        setting.applications.categories = [
            {
                text: "__(Media)",
                iconclass: "bi bi-disc"
            },
            {
                text: "__(Development)",
                iconclass: "bi bi-hammer"
            },
            {
                text: "__(Education)",
                iconclass: "fa fa-graduation-cap"
            },
            {
                text: "__(Game)",
                iconclass: "fa fa-gamepad"
            },
            {
                text: "__(Graphics)",
                iconclass: "bi bi-palette-fill"
            },
            {
                text: "__(Internet)",
                iconclass: "fa fa-globe"
            },
            {
                text: "__(Office)",
                iconclass: "bi bi-building"
            },
            {
                text: "__(System)",
                iconclass: "fa bi-gear-wide-connected"
            },
            {
                text: "__(Utility)",
                iconclass: "bi bi-tools"
            },
        ];
    }
    OS.systemSetting = systemSetting;
    // Register handle for application search
    OS.API.onsearch("__(Applications)", function (t) {
        const ar = [];
        const term = new RegExp(t, "i");
        for (let k in setting.system.packages) {
            const v = setting.system.packages[k];
            if (v.app) {
                var e, k1, v1;
                if (v.name.match(term) ||
                    (v.description && v.description.match(term))) {
                    v1 = {};
                    for (k1 in v) {
                        e = v[k1];
                        if (k1 !== "selected") {
                            v1[k1] = e;
                        }
                    }
                    v1.detail = [{ text: v1.path }];
                    v1.complex = true;
                    ar.push(v1);
                }
                else if (v.mimes) {
                    for (let m of v.mimes) {
                        if (t.match(new RegExp(m, "g"))) {
                            v1 = {};
                            for (k1 in v) {
                                e = v[k1];
                                if (k1 !== "selected") {
                                    v1[k1] = v[k1];
                                }
                            }
                            v1.detail = [{ text: v1.path }];
                            v1.complex = true;
                            ar.push(v1);
                            break;
                        }
                    }
                }
            }
        }
        return ar;
    });
})(OS || (OS = {}));

// Copyright 2017-2020 Xuan Sang LE <xsang.le AT gmail DOT com>
// AnTOS Web desktop is is licensed under the GNU General Public
// License v3.0, see the LICENCE file for more information
// This program is free software: you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation, either version 3 of
// the License, or (at your option) any later version.
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// General Public License for more details.
// You should have received a copy of the GNU General Public License
//along with this program. If not, see https://www.gnu.org/licenses/.
var OS;
(function (OS) {
    let API;
    (function (API) {
        let loc = { hostname: "localhost", port: "80", protocol: "http" };
        if (Ant.location)
            loc = Ant.location;
        /**
         * The host name of the server-side
         */
        API.HOST = loc.hostname + (loc.port ? `:${loc.port}` : "");
        /**
         * The base URI of the server-side API
         */
        API.BASE_URI = `${API.HOST}${loc.pathname}`;
        /**
         * The base REST URI of the server-side API
         */
        API.REST = `${loc.protocol}//${API.BASE_URI}`;
        /**
         * The namespace `handle` contains some low level API to
         * communicate with the server side API. It is the only
         * API layer that communicate directly with the server.
         * To make AntOS compatible with any server side API,
         * all exported variable unctions defined in the `handle`
         * namespace should be re-implemented
         */
        let handle;
        (function (handle) {
            /**
             * Base URI for reading content of VFS file
             */
            handle.get = `${API.REST}/VFS/get`;
            /**
             * Base URI for VFS file sharing
             */
            handle.shared = `${API.REST}/VFS/shared`;
            /**
             * Send a request to the server-side API for a directory scanning
             * operation
             *
             * @export
             * @param {string} p a VFS file path e.g. home://test/
             * @returns {Promise<RequestResult>} A promise on a [[RequestResult]]
             * which contains an error or a list of FileInfoType
             */
            function scandir(p) {
                const path = `${API.REST}/VFS/scandir`;
                return API.post(path, { path: p });
            }
            handle.scandir = scandir;
            /**
             *
             * Send a request to the server-side API for directory creation
             *
             * @export
             * @param {string} p VFS path of the directory to be created
             * @returns {Promise<RequestResult>} A promise on a RequestResult
             * which contains an error or true on success
             */
            function mkdir(p) {
                const path = `${API.REST}/VFS/mkdir`;
                return API.post(path, { path: p });
            }
            handle.mkdir = mkdir;
            /**
             * Send a request to the server-side API for sharing/unsharing a VFS file,
             * once shared a VFS file will be publicly visible by everyone
             *
             * @export
             * @param {string} p VFS file path to be shared
             * @param {boolean} pub flag: share (true) or unshare (false)
             * @returns {Promise<RequestResult>} A promise on a RequestResult
             * which contains an error or true on success
             */
            function sharefile(p, pub) {
                const path = `${API.REST}/VFS/publish`;
                return API.post(path, { path: p, publish: pub });
            }
            handle.sharefile = sharefile;
            /**
             * Get VFS file meta-data
             *
             * @export
             * @param {string} p VFS file path
             * @returns {Promise<RequestResult>} A promise on a [[RequestResult]]
             * which contains an error or an object of FileInfoType
             */
            function fileinfo(p) {
                const path = `${API.REST}/VFS/fileinfo`;
                return API.post(path, { path: p });
            }
            handle.fileinfo = fileinfo;
            /**
             * Read a VFS file content. There are many ways a VFS file can be read:
             * - Read as a raw text content
             * - Read as a javascript file, in this case the content of the
             * file will be executed
             * - Read as JSON object
             *
             * @export
             * @param {string} p path of the VFS file
             * @param {string} t return data type:
             * - jsonp: the response is an json object
             * - script: the response is a javascript code
             * - xml, html: the response is a XML/HTML object
             * - text: plain text
             *
             * @returns {Promise<any>}  A promise on a [[RequestResult]]
             * which contains an error or an object of [[FileInfoType]]
             */
            function readfile(p, t) {
                const path = `${API.REST}/VFS/get/`;
                return API.get(path + p, t);
            }
            handle.readfile = readfile;
            /**
             * Move a file to another location on server-side
             *
             * @export
             * @param {string} s VFS source file path
             * @param {string} d VFS destination file path
             * @returns {Promise<RequestResult>}  A promise on a [[RequestResult]]
             * which contains an error or a success response
             */
            function move(s, d) {
                const path = `${API.REST}/VFS/move`;
                return API.post(path, { src: s, dest: d });
            }
            handle.move = move;
            /**
             * Delete a VFS file on the server-side
             *
             * @export
             * @param {string} p VFS file path
             * @returns {Promise<RequestResult>}  A promise on a [[RequestResult]]
             * which contains an error or a success response
             */
            function remove(p) {
                const path = `${API.REST}/VFS/delete`;
                return API.post(path, { path: p });
            }
            handle.remove = remove;
            /**
             * Read the file as binary data
             *
             * @export
             * @param {string} p VFS file to be read
             * @returns {Promise<ArrayBuffer>} a Promise on an array buffer
             */
            function fileblob(p) {
                const path = `${API.REST}/VFS/get/`;
                return API.blob(path + p);
            }
            handle.fileblob = fileblob;
            /**
             * Send a command to the serverside package manager
             *
             * @export
             * @param {PackageCommandType} d a package command of type PackageCommandType
             * @returns {Promise<RequestResult>} a promise on a [[RequestResult]]
             */
            function packages(d) {
                const path = `${API.REST}/system/packages`;
                return API.post(path, d);
            }
            handle.packages = packages;
            /**
             * Upload file to the server via VFS interface
             *
             * @export
             * @param {string} d VFS destination directory path
             * @returns {Promise<RequestResult>} a promise on a [[RequestResult]]
             */
            function upload(d) {
                const path = `${API.REST}/VFS/upload`;
                return API.upload(path, d);
            }
            handle.upload = upload;
            /**
             * Write Base 64 encoded data to a VFS file
             *
             * @export
             * @param {string} p path to the VFS file
             * @param {string} d file data encoded in Base 64
             * @returns {Promise<RequestResult>} a promise on a [[RequestResult]]
             */
            function write(p, d) {
                const path = `${API.REST}/VFS/write`;
                return API.post(path, { path: p, data: d });
            }
            handle.write = write;
            /**
             * An apigateway allows client side to execute a custom server-side
             * script and get back the result. This gateway is particularly
             * useful in case of performing a task that is not provided by the core
             * API
             *
             * @export
             * @param {GenericObject<any>} d execution indication, provided only when ws is `false`
             * otherwise, `d` should be written directly to the websocket stream as JSON object.
             * Two possible formats of `d`:
             * ```text
             * execute an server-side script file:
             *
             * {
             *  path: [VFS path],
             *  parameters: [parameters of the server-side script]
             * }
             *
             * or, execute directly a snippet of server-side script:
             *
             * { code: [server-side script code snippet as string] }
             *
             * ```
             *
             * @param {boolean} ws flag indicate whether to use websocket for the connection
             * to the gateway API. In case of streaming data, the websocket is preferred
             * @returns {Promise<any>} a promise on the result object (any)
             */
            function apigateway(d, ws) {
                if (ws) {
                    return new Promise(function (resolve, reject) {
                        try {
                            const path = `${API.BASE_URI}/system/apigateway?ws=1`;
                            const proto = window.location.protocol === "https:"
                                ? "wss://"
                                : "ws://";
                            const socket = new WebSocket(proto + path);
                            return resolve(socket);
                        }
                        catch (e) {
                            return reject(__e(e));
                        }
                    });
                }
                else {
                    const path = `${API.REST}/system/apigateway?ws=0`;
                    return API.post(path, d);
                }
            }
            handle.apigateway = apigateway;
            /**
             *  Check if a user is logged in
             *
             * @export
             * @returns {Promise<RequestResult>} a promise on a [[RequestResult]] that
             * contains an error or a [[UserSettingType]] object
             */
            function auth() {
                const p = `${API.REST}/user/auth`;
                return API.post(p, {});
            }
            handle.auth = auth;
            /**
             * Perform a login operation
             *
             * @export
             * @param {UserLoginType} d user data [[UserLoginType]]
             * @returns {Promise<RequestResult>} a promise on a [[RequestResult]] that
             * contains an error or a [[UserSettingType]] object
             */
            function login(d) {
                const p = `${API.REST}/user/login`;
                return API.post(p, d);
            }
            handle.login = login;
            /**
             * Perform a logout operation
             *
             * @export
             * @returns {Promise<RequestResult>} a promise on a [[RequestResult]]
             */
            function logout() {
                const p = `${API.REST}/user/logout`;
                return API.post(p, {});
            }
            handle.logout = logout;
            /**
             * Save the current user settings
             *
             * @export
             * @returns {Promise<RequestResult>} a promise on a [[RequestResult]]
             */
            function setting() {
                const p = `${API.REST}/system/settings`;
                return API.post(p, OS.setting);
            }
            handle.setting = setting;
            /**
             * This is the low level function of AntOS VDB API.
             * It requests the server API to perform some simple
             * SQL query.
             *
             * @export
             * @param {string} cmd action to perform: save, delete, get, select
             * @param {GenericObject<any>} d data object of the request based on each action:
             * - save:
             * ```
             *  { table: "table name", data: [record data object]}
             * ```
             * - get:
             * ```
             *  { table: "table name", id: [record id]}
             * ```
             * - delete:
             * ```
             *  { table: "table name", id: [record id]}
             * or
             *  { table: "table name", cond: [conditional object]}
             * ```
             * - select:
             * ```
             * { table: "table name", cond: [conditional object]}
             * ```
             * @returns {Promise<RequestResult>} a promise of [[RequestResult]] on the
             * query data
             *
             * A conditional object represents a SQL condition statement as an object,
             * example: `pid = 10 AND cid = 2 ORDER BY date DESC`
             * ```
             *  {
             *      exp: {
             *          "and": {
             *              pid: 10,
             *              cid: 2
             *          }
             *      },
             *      order: {
             *          date: "DESC"
             *      }
             *  }
             * ```
             */
            function dbquery(cmd, d) {
                const path = `${API.REST}/VDB/${cmd}`;
                return API.post(path, d);
            }
            handle.dbquery = dbquery;
        })(handle = API.handle || (API.handle = {}));
    })(API = OS.API || (OS.API = {}));
})(OS || (OS = {}));

// Copyright 2017-2018 Xuan Sang LE <xsang.le AT gmail DOT com>
// AnTOS Web desktop is is licensed under the GNU General Public
// License v3.0, see the LICENCE file for more information
// This program is free software: you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation, either version 3 of
// the License, or (at your option) any later version.
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// General Public License for more details.
// You should have received a copy of the GNU General Public License
//along with this program. If not, see https://www.gnu.org/licenses/.
var OS;
(function (OS) {
    let API;
    (function (API) {
        ;
        /**
         * This class is the based class used in AntOS event
         * announcement system.
         * It implements the observer pattern using simple
         * subscribe/publish mechanism
         * @export
         * @class Announcer
         */
        class Announcer {
            /**
             *Creates an instance of Announcer.
             * @memberof Announcer
             */
            constructor() {
                this.observable = {};
                this.enable = true;
            }
            /**
             * Disable the announcer, when this function is called
             * all events and their callbacks will be removed
             *
             * @returns
             * @memberof Announcer
             */
            disable() {
                this.off("*");
                return (this.enable = false);
            }
            /**
             * Subscribe to an event, the callback will be called
             * every time the corresponding event is trigged
             *
             * @param {string} evtName event name
             * @param {(d: any) => void} callback The corresponding callback
             * @returns {void}
             * @memberof Announcer
             */
            on(evtName, callback) {
                if (!this.enable) {
                    return;
                }
                if (!this.observable[evtName]) {
                    this.observable[evtName] = {
                        one: new Set(),
                        many: new Set(),
                    };
                }
                this.observable[evtName].many.add(callback);
            }
            /**
             * Subscribe to an event, the callback will
             * be called only once and then removed from the announcer
             *
             * @param {string} evtName event name
             * @param {(d: any) => void} callback the corresponding callback
             * @returns {void}
             * @memberof Announcer
             */
            one(evtName, callback) {
                if (!this.enable) {
                    return;
                }
                if (!this.observable[evtName]) {
                    this.observable[evtName] = {
                        one: new Set(),
                        many: new Set(),
                    };
                }
                this.observable[evtName].one.add(callback);
            }
            /**
             * Unsubscribe the callback from an event
             *
             * @param {string} evtName event name
             * @param {(d: any) => void} [callback] the callback to be unsubscribed.
             * When the `callback` is `*`, all callbacks related to `evtName` will be
             * removed
             * @memberof Announcer
             */
            off(evtName, callback) {
                const fn = (evt, cb) => {
                    if (!this.observable[evt]) {
                        return;
                    }
                    if (cb) {
                        this.observable[evt].one.delete(cb);
                        return this.observable[evt].many.delete(cb);
                    }
                    else {
                        if (this.observable[evt]) {
                            return delete this.observable[evt];
                        }
                    }
                };
                if (evtName === "*") {
                    for (let k in this.observable) {
                        fn(k, callback);
                    }
                }
                else {
                    fn(evtName, callback);
                }
            }
            /**
             * Trigger an event
             *
             * @param {string} evtName event name
             * @param {*} data data object that will be send to all related callback
             * @returns {void}
             * @memberof Announcer
             */
            trigger(evtName, data) {
                const trig = (name, d) => {
                    const names = [name, "*"];
                    for (let evt of names) {
                        if (!this.observable[evt]) {
                            continue;
                        }
                        this.observable[evt].one.forEach((f) => f(d));
                        this.observable[evt].one = new Set();
                        this.observable[evt].many.forEach((f) => f(d));
                    }
                };
                if (evtName === "*") {
                    for (let k in this.observable) {
                        const v = this.observable[k];
                        if (k !== "*") {
                            trig(k, data);
                        }
                    }
                }
                else {
                    return trig(evtName, data);
                }
            }
        }
        API.Announcer = Announcer;
    })(API = OS.API || (OS.API = {}));
    /**
     * This namespace defines every thing related to the system announcement.
     *
     * The system announcement provides a global way to communicate between
     * processes (applications/services) using the subscribe/publish
     * mechanism
     */
    let announcer;
    (function (announcer) {
        /**
         * The global announcer object that manages global events
         * and callbacks
         */
        announcer.observable = new API.Announcer();
        /**
         * Placeholder of all global events listeners
         */
        announcer.listeners = new Map();
        /**
         * Subscribe to a global event
         *
         * @export
         * @param {string} e event name
         * @param {(d: API.AnnouncementDataType<any>) => void} f event callback
         * @param {GUI.BaseModel} a the process  (Application/service) related to the callback
         */
        function on(e, f, a) {
            let key = 0;
            if (a)
                key = a;
            if (!announcer.listeners.has(key)) {
                announcer.listeners.set(key, []);
            }
            const collection = announcer.listeners.get(key);
            collection.push({ e, f });
            announcer.observable.on(e, f);
        }
        announcer.on = on;
        /**
         * Subscribe to a global event once
         *
         * @export
         * @param {string} e event name
         * @param {(d: API.AnnouncementDataType<any>) => void} f event callback
         */
        function one(e, f) {
            announcer.observable.one(e, f);
        }
        announcer.one = one;
        /**
         * Trigger a global event
         *
         * @export
         * @param {string} e event name
         * @param {*} d data passing to all related callback
         */
        function trigger(e, d) {
            announcer.observable.trigger(e, d);
        }
        announcer.trigger = trigger;
        /**
         * Report system fail. This will trigger the global `fail`
         * event
         *
         * @export
         * @param {(string | FormattedString)} m message string
         * @param {Error} e error to be reported
         */
        function osfail(m, e) {
            announcer.ostrigger("fail", m, e);
        }
        announcer.osfail = osfail;
        /**
         * Report system error. This will trigger the global `error`
         * event
         *
         * @export
         * @param {(string | FormattedString)} m message string
         * @param {Error} e error to be reported
         */
        function oserror(m, e) {
            announcer.ostrigger("error", m, e);
        }
        announcer.oserror = oserror;
        /**
         * Trigger system notification (`info` event)
         *
         * @export
         * @param {(string | FormattedString)} m notification message
         */
        function osinfo(m) {
            announcer.ostrigger("info", m);
        }
        announcer.osinfo = osinfo;
        /**
         *
         *
         * @export
         * @param {string} e event name
         * @param {(string| FormattedString)} m event message
         * @param {*} [d] user data
         */
        function ostrigger(e, m, d) {
            const aob = {};
            aob.id = 0;
            aob.message = m;
            aob.u_data = d;
            aob.name = "OS";
            announcer.trigger(e, aob);
        }
        announcer.ostrigger = ostrigger;
        /**
         * Unregister a process (application/service) from
         * the global announcement system
         *
         * @export
         * @param {GUI.BaseModel} app reference to the process
         * @returns {void}
         */
        function unregister(app) {
            if (!announcer.listeners.has(app)) {
                return;
            }
            const collection = announcer.listeners.get(app);
            for (let i of collection) {
                announcer.observable.off(i.e, i.f);
            }
            announcer.listeners.delete(app);
        }
        announcer.unregister = unregister;
        /**
         * Allocate message id
         *
         * @export
         * @returns {number}
         */
        function getMID() {
            announcer.quota += 1;
            return announcer.quota;
        }
        announcer.getMID = getMID;
    })(announcer = OS.announcer || (OS.announcer = {}));
})(OS || (OS = {}));

// Copyright 2017-2018 Xuan Sang LE <xsang.le AT gmail DOT com>
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var OS;
(function (OS) {
    let API;
    (function (API) {
        /**
         * This namespace is dedicated to all APIs related to
         * AntOS Virtual File System (VFS)
         */
        let VFS;
        (function (VFS) {
            /** path for custom VFS protocol handles */
            const VFSX_PATH = "pkg://vfsx/vfsx.js";
            String.prototype.asFileHandle = function () {
                const list = this.split("://");
                const handles = API.VFS.findHandles(list[0]);
                if (!handles || handles.length === 0) {
                    OS.announcer.osfail(__("VFS unknown handle: {0}", this), API.throwe("OS.VFS"));
                    return null;
                }
                return new handles[0](this);
            };
            /**
             * Placeholder stores VFS file protocol patterns and its attached file handle class.
             *
             */
            VFS.handles = {};
            /**
             * Register a protocol to a handle class
             *
             * @export
             * @param {string} protos VFS protocol pattern
             * @param {VFSFileHandleClass} cls handle class
             */
            function register(protos, cls) {
                VFS.handles[protos] = cls;
            }
            VFS.register = register;
            /**
             * Load custom VFS handles if the package vfsx available
             *
             * @export
             * @param {boolean} [force] force load the file
             * @return {*}  {Promise<any>}
             */
            function loadVFSX(force) {
                return new Promise((resolve, reject) => __awaiter(this, void 0, void 0, function* () {
                    try {
                        yield API.requires(VFSX_PATH, force);
                        resolve(true);
                    }
                    catch (e) {
                        console.warn("No custom VFS protocol loaded");
                        resolve(true);
                    }
                }));
            }
            VFS.loadVFSX = loadVFSX;
            /**
             * Looking for a attached file handle class of a string protocol
             *
             * When converting a string to file handle, the system will look
             * for a protocol pattern in the string, if the protocol found,
             * its attached handle class (found in [[VFS.handles]]) will be
             * used to initialize a file handle object from the string
             *
             * ```typescript
             *  "home://data/test.txt".asFileHandle() // -> an instance of RemoteFileHandle
             * ```
             * @export
             * @param {string} proto protocol string
             * @returns {VFSFileHandleClass[]}
             */
            function findHandles(proto) {
                const l = (() => {
                    const result = [];
                    for (let k in VFS.handles) {
                        const v = VFS.handles[k];
                        if (proto.trim().match(new RegExp(k, "g"))) {
                            result.push(v);
                        }
                    }
                    return result;
                })();
                return l;
            }
            VFS.findHandles = findHandles;
            /**
             * Abstract prototype of all all VFS file handle definition.
             *
             * This prototype provides a standardized interface to access
             * to different underlay file systems such as remote file,
             * cloud file (Dropbox, Google drive, etc.), URL or memory-based file
             *
             * @export
             * @abstract
             * @class BaseFileHandle
             */
            class BaseFileHandle {
                /**
                 *Creates an instance of BaseFileHandle.
                 * @param {string} path file path
                 * @memberof BaseFileHandle
                 */
                constructor(path) {
                    this.dirty = false;
                    this.cache = undefined;
                    this.setPath(path);
                }
                /**
                 * Set a file path to the current file handle
                 *
                 * @param {string} p
                 * @returns {void}
                 * @memberof BaseFileHandle
                 */
                setPath(p) {
                    this.ready = false;
                    if (!p) {
                        return;
                    }
                    this.path = p.toString();
                    const list = this.path.split("://");
                    this.protocol = list[0];
                    if (!(list.length > 1)) {
                        return;
                    }
                    const re = list[1].replace(/^\/+|\/+$/g, "");
                    if (re === "") {
                        return;
                    }
                    this.genealogy = re.split("/").filter(s => s != "");
                    this.path = `${this.protocol}://${this.genealogy.join("/")}`;
                    if (!this.isRoot()) {
                        this.basename = this.genealogy[this.genealogy.length - 1];
                    }
                    if (this.basename.lastIndexOf(".") !== 0 &&
                        this.basename.indexOf(".") !== -1) {
                        this.ext = this.basename.split(".").pop();
                    }
                }
                /**
                 * Getter: Get the file basename
                 * Setter: set the file name
                 *
                 * @returns {string}
                 * @memberof BaseFileHandle
                 */
                get filename() {
                    if (!this.basename) {
                        return "Untitled";
                    }
                    return this.basename;
                }
                set filename(v) {
                    this.basename = v;
                }
                /**
                 * Getter: Get the file cache
                 * Setter: set the file cache
                 *
                 * @returns {any}
                 * @memberof BaseFileHandle
                 */
                get cache() {
                    return this._cache;
                }
                set cache(v) {
                    this._cache = v;
                    this._cache_changed();
                }
                /**
                 * Set data to the file cache
                 *
                 * @param {*} v data object
                 * @returns {BaseFileHandle}
                 * @memberof BaseFileHandle
                 */
                setCache(v) {
                    this.cache = v;
                    return this;
                }
                /**
                 * Return the object itself
                 *
                 * @returns {BaseFileHandle}
                 * @memberof BaseFileHandle
                 */
                asFileHandle() {
                    return this;
                }
                /**
                 * Check whether the current file is the root of the file tree
                 *
                 * @returns {boolean}
                 * @memberof BaseFileHandle
                 */
                isRoot() {
                    return !this.genealogy || this.genealogy.length === 0;
                }
                /**
                 * Check whether the current file is a hidden file
                 *
                 * @returns {boolean}
                 * @memberof BaseFileHandle
                 */
                isHidden() {
                    if (!this.basename) {
                        return false;
                    }
                    return this.basename[0] === ".";
                }
                /**
                 * Get hash number of the current file path
                 *
                 * @returns {number}
                 * @memberof BaseFileHandle
                 */
                hash() {
                    if (!this.path) {
                        return -1;
                    }
                    return this.path.hash();
                }
                /**
                 * Convert the current file cache to Base64
                 *
                 * @protected
                 * @param {string} t type of the file cache:
                 * - `object`
                 * - `mime type`
                 * @returns {(Promise<string | ArrayBuffer>)} promise on the converted data
                 * @memberof BaseFileHandle
                 */
                b64(t) {
                    // t is object or mime type
                    return new Promise((resolve, reject) => {
                        const m = t === "object" ? "text/plain" : t;
                        if (!this.cache) {
                            return resolve("");
                        }
                        if (t === "object" || typeof this.cache === "string") {
                            let b64;
                            if (t === "object") {
                                b64 = JSON.stringify(this.cache, undefined, 4).asBase64();
                            }
                            else {
                                b64 = this.cache.asBase64();
                            }
                            b64 = `data:${m};base64,${b64}`;
                            return resolve(b64);
                        }
                        else {
                            const reader = new FileReader();
                            reader.readAsDataURL(this.cache);
                            reader.onload = () => resolve(reader.result);
                            return (reader.onerror = (e) => reject(e));
                        }
                    });
                }
                /**
                 * Get the parent file handle of the current file
                 *
                 * @returns {BaseFileHandle}
                 * @memberof BaseFileHandle
                 */
                parent() {
                    if (this.isRoot()) {
                        return this;
                    }
                    return (this.protocol +
                        "://" +
                        this.genealogy
                            .slice(0, this.genealogy.length - 1)
                            .join("/")).asFileHandle();
                }
                /**
                 * Load the file meta-data before performing
                 * any task
                 *
                 * @returns {Promise<FileInfoType>} a promise on file meta-data
                 * @memberof BaseFileHandle
                 */
                onready() {
                    // read meta data
                    return new Promise((resolve, reject) => {
                        if (this.ready) {
                            return resolve(this.info);
                        }
                        return this.meta()
                            .then((d) => {
                            this.info = d.result;
                            this.ready = true;
                            return resolve(d.result);
                        })
                            .catch((e) => reject(__e(e)));
                    });
                }
                /**
                 * Public read operation
                 *
                 * This function calls the [[_rd]] function to perform the operation.
                 *
                 * If the current file is a directory, then the operation
                 * will return the meta-data of all files inside of the directory.
                 * Otherwise, file content will be returned
                 *
                 * @param {string} t data type
                 * - jsonp: the response is an json object
                 * - script: the response is a javascript code
                 * - xml, html: the response is a XML/HTML object
                 * - text: plain text
                 * - binary
                 *
                 * @returns {Promise<any>} a promise on the file content
                 * @memberof BaseFileHandle
                 */
                read(t) {
                    return new Promise((resolve, reject) => __awaiter(this, void 0, void 0, function* () {
                        try {
                            const r = yield this.onready();
                            const d = yield this._rd(t);
                            resolve(d);
                        }
                        catch (e_1) {
                            return reject(__e(e_1));
                        }
                    }));
                }
                /**
                 * Write the file cache to the actual file
                 *
                 * This function calls the [[_wr]] function to perform the operation
                 *
                 * @param {string} t data type
                 * - `base64`
                 * - `object`
                 * - `mime type`
                 *
                 * @returns {Promise<RequestResult>} promise on the operation result
                 * @memberof BaseFileHandle
                 */
                write(t) {
                    return new Promise((resolve, reject) => __awaiter(this, void 0, void 0, function* () {
                        try {
                            const r = yield this._wr(t);
                            OS.announcer.ostrigger("VFS", "write", this);
                            return resolve(r);
                        }
                        catch (e) {
                            return reject(__e(e));
                        }
                    }));
                }
                /**
                 * Sub-directory creation
                 *
                 * This function calls the [[_mk]] function to perform the operation
                 *
                 * @param {string} d sub directory name
                 * @returns {Promise<RequestResult>} promise on the operation result
                 * @memberof BaseFileHandle
                 */
                mk(d) {
                    return new Promise((resolve, reject) => __awaiter(this, void 0, void 0, function* () {
                        try {
                            const r = yield this.onready();
                            const d_1 = yield this._mk(d);
                            OS.announcer.ostrigger("VFS", "mk", this);
                            return resolve(d_1);
                        }
                        catch (e_1) {
                            return reject(__e(e_1));
                        }
                    }));
                }
                /**
                 * Delete the file
                 *
                 * This function calls the [[_rm]] function to perform the operation
                 *
                 * @returns {Promise<RequestResult>} promise on the operation result
                 * @memberof BaseFileHandle
                 */
                remove() {
                    return new Promise((resolve, reject) => __awaiter(this, void 0, void 0, function* () {
                        try {
                            const r = yield this.onready();
                            const d = yield this._rm();
                            OS.announcer.ostrigger("VFS", "remove", this);
                            return resolve(d);
                        }
                        catch (e_1) {
                            return reject(__e(e_1));
                        }
                    }));
                }
                /**
                 * Upload a file to the current directory
                 *
                 * Only work when the current file is a directory
                 *
                 * This function calls the [[_up]] function to perform the operation
                 *
                 * @returns {Promise<RequestResult>} promise on the operation result
                 * @memberof BaseFileHandle
                 */
                upload() {
                    return new Promise((resolve, reject) => __awaiter(this, void 0, void 0, function* () {
                        try {
                            const r = yield this.onready();
                            const d = yield this._up();
                            OS.announcer.ostrigger("VFS", "upload", this);
                            return resolve(d);
                        }
                        catch (e_1) {
                            return reject(__e(e_1));
                        }
                    }));
                }
                /**
                 * Share the file by publish it.
                 *
                 * Only work with file
                 *
                 * This function calls the [[_pub]] function to perform the operation
                 *
                 * @returns {Promise<RequestResult>} promise on operation result
                 * @memberof BaseFileHandle
                 */
                publish() {
                    return new Promise((resolve, reject) => __awaiter(this, void 0, void 0, function* () {
                        try {
                            const r = yield this.onready();
                            const d = yield this._pub();
                            OS.announcer.ostrigger("VFS", "publish", this);
                            return resolve(d);
                        }
                        catch (e_1) {
                            return reject(__e(e_1));
                        }
                    }));
                }
                /**
                 * Download the file.
                 *
                 * Only work with file
                 *
                 * This function calls the [[_down]] function to perform the operation
                 *
                 * @returns {Promise<any>} Promise on the operation result
                 * @memberof BaseFileHandle
                 */
                download() {
                    return new Promise((resolve, reject) => __awaiter(this, void 0, void 0, function* () {
                        try {
                            const r = yield this.onready();
                            const d = yield this._down();
                            OS.announcer.ostrigger("VFS", "download", this);
                            return resolve(d);
                        }
                        catch (e_1) {
                            return reject(__e(e_1));
                        }
                    }));
                }
                /**
                 * Move the current file to another location
                 *
                 * This function calls the [[_mv]] function to perform the operation
                 *
                 * @param {string} d destination location
                 * @returns {Promise<RequestResult>} promise on the operation result
                 * @memberof BaseFileHandle
                 */
                move(d) {
                    return new Promise((resolve, reject) => __awaiter(this, void 0, void 0, function* () {
                        try {
                            const r = yield this.onready();
                            const data = yield this._mv(d);
                            OS.announcer.ostrigger("VFS", "move", d.asFileHandle());
                            return resolve(data);
                        }
                        catch (e_1) {
                            return reject(__e(e_1));
                        }
                    }));
                }
                /**
                 * Execute the current file.
                 *
                 * This action depends on each file protocol
                 *
                 * This function calls the [[_exec]] function to perform the operation
                 *
                 * @returns {Promise<any>}
                 * @memberof BaseFileHandle
                 */
                execute() {
                    return new Promise((resolve, reject) => __awaiter(this, void 0, void 0, function* () {
                        try {
                            const r = yield this.onready();
                            const d = yield this._exec();
                            OS.announcer.ostrigger("VFS", "execute", this);
                            return resolve(d);
                        }
                        catch (e_1) {
                            return reject(__e(e_1));
                        }
                    }));
                }
                /**
                 * Get an accessible link to the file
                 * that can be accessed from the browser
                 *
                 * @returns {string}
                 * @memberof BaseFileHandle
                 */
                getlink() {
                    return this.path;
                }
                /**
                 * Helper function returns a promise on unsupported action
                 *
                 * @param {string} t action name
                 * @returns {Promise<RequestResult>}
                 * @memberof BaseFileHandle
                 */
                unsupported(t) {
                    return new Promise((resolve, reject) => {
                        return reject(API.throwe(__("Action {0} is unsupported on: {1}", t, this.path)));
                    });
                }
                /**
                 * trigger cache changed event
                 *
                 * This function triggered when the file cached changed
                 *
                 * @protected
                 * @memberof BaseFileHandle
                 */
                _cache_changed() {
                }
                /**
                 * Low level protocol-specific read operation
                 *
                 * This function should be overridden on the file handle class
                 * that supports the operation
                 *
                 * @protected
                 * @param {string} t data type, see [[read]]
                 * @returns {Promise<RequestResult>}
                 * @memberof BaseFileHandle
                 */
                _rd(t) {
                    return this.unsupported("read");
                }
                /**
                 * Low level protocol-specific write operation
                 *
                 * This function should be overridden by the file handle class
                 * that supports the operation
                 *
                 * @protected
                 * @param {string} t data type, see [[write]]
                 * @param {*} [d]
                 * @returns {Promise<RequestResult>}
                 * @memberof BaseFileHandle
                 */
                _wr(t, d) {
                    return this.unsupported("write");
                }
                /**
                 * Low level protocol-specific sub-directory creation
                 *
                 * This function should be overridden by the file handle class
                 * that supports the operation
                 *
                 * @protected
                 * @param {string} d sub directory name
                 * @returns {Promise<RequestResult>}
                 * @memberof BaseFileHandle
                 */
                _mk(d) {
                    return this.unsupported("mk");
                }
                /**
                 * Low level protocol-specific delete operation
                 *
                 * This function should be overridden by the file handle class
                 * that supports the operation
                 *
                 * @returns {Promise<RequestResult>}
                 * @memberof BaseFileHandle
                 */
                _rm() {
                    return this.unsupported("remove");
                }
                /**
                 * Low level protocol-specific move operation
                 *
                 * This function should be overridden by the file handle class
                 * that supports the operation
                 *
                 * @protected
                 * @param {string} d
                 * @returns {Promise<RequestResult>}
                 * @memberof BaseFileHandle
                 */
                _mv(d) {
                    return this.unsupported("move");
                }
                /**
                 * Low level protocol-specific upload operation
                 *
                 * This function should be overridden by the file handle class
                 * that supports the operation
                 *
                 * @returns {Promise<RequestResult>}
                 * @memberof BaseFileHandle
                 */
                _up() {
                    return this.unsupported("upload");
                }
                /**
                 * Low level protocol-specific download operation
                 *
                 * This function should be overridden by the file handle class
                 * that supports the operation
                 *
                 * @returns {Promise<any>}
                 * @memberof BaseFileHandle
                 */
                _down() {
                    return this.unsupported("download");
                }
                /**
                 * Low level protocol-specific execute operation
                 *
                 * This function should be overridden by the file handle class
                 * that supports the operation
                 *
                 * @returns {Promise<RequestResult>}
                 * @memberof BaseFileHandle
                 */
                _exec() {
                    return this.unsupported("execute");
                }
                /**
                 * Low level protocol-specific share operation
                 *
                 * This function should be overridden by the file handle class
                 * that supports the operation
                 *
                 * @returns {Promise<RequestResult>}
                 * @memberof BaseFileHandle
                 */
                _pub() {
                    return this.unsupported("publish");
                }
            }
            VFS.BaseFileHandle = BaseFileHandle;
            /**
             * Remote file handle allows to perform file operation
             * on AntOS remote server files. Its protocol is defined
             * by the following pattern:
             *
             * ```
             * ^(home|desktop|os|Untitled)$
             * ```
             *
             * @class RemoteFileHandle
             * @extends {BaseFileHandle}
             */
            class RemoteFileHandle extends BaseFileHandle {
                /**
                 *Creates an instance of RemoteFileHandle.
                 * @param {string} path file path
                 * @memberof RemoteFileHandle
                 */
                constructor(path) {
                    super(path);
                }
                /**
                 * Read remote file meta-data
                 *
                 * @returns {Promise<RequestResult>}
                 * @memberof RemoteFileHandle
                 */
                meta() {
                    return new Promise((resolve, reject) => __awaiter(this, void 0, void 0, function* () {
                        try {
                            const d = yield API.handle.fileinfo(this.path);
                            if (d.error) {
                                return reject(API.throwe(__("{0}: {1}", d.error, this.path)));
                            }
                            return resolve(d);
                        }
                        catch (e) {
                            return reject(__e(e));
                        }
                    }));
                }
                /**
                 * Remote file access link
                 *
                 * @returns {string}
                 * @memberof RemoteFileHandle
                 */
                getlink() {
                    return API.handle.get + "/" + this.path;
                }
                /**
                 * Read remote file content.
                 *
                 * If the current file is a directory, then the operation
                 * will return the meta-data of all files inside of the directory.
                 * Otherwise, file content will be returned
                 *
                 * @protected
                 * @param {string} t data type see [[read]]
                 * @returns {Promise<any>}
                 * @memberof RemoteFileHandle
                 */
                _rd(t) {
                    // t: binary, text, any type
                    if (!this.info) {
                        return new Promise((resolve, reject) => {
                            return reject(API.throwe(__("file meta-data not found: {0}", this.path)));
                        });
                    }
                    if (this.info.type === "dir") {
                        return API.handle.scandir(this.path);
                    }
                    //read the file
                    if (t === "binary") {
                        return API.handle.fileblob(this.path);
                    }
                    return API.handle.readfile(this.path, t ? t : "text");
                }
                /**
                 * Write file cache to the remote file
                 *
                 * @protected
                 * @param {string} t data type see [[write]]
                 * @returns {Promise<RequestResult>}
                 * @memberof RemoteFileHandle
                 */
                _wr(t) {
                    // t is base64 or undefined
                    return new Promise((resolve, reject) => __awaiter(this, void 0, void 0, function* () {
                        try {
                            if (t === "base64") {
                                const d = yield API.handle.write(this.path, this.cache);
                                if (d.error) {
                                    return reject(API.throwe(__("{0}: {1}", d.error, this.path)));
                                }
                                return resolve(d);
                            }
                            else {
                                const r = yield this.b64(t);
                                const result = yield API.handle.write(this.path, r);
                                if (result.error) {
                                    return reject(API.throwe(__("{0}: {1}", result.error, this.path)));
                                }
                                return resolve(result);
                            }
                        }
                        catch (e) {
                            return reject(__e(e));
                        }
                    }));
                }
                /**
                 * Create sub directory
                 *
                 * Only work on directory file handle
                 *
                 * @protected
                 * @param {string} d sub directory name
                 * @returns {Promise<RequestResult>}
                 * @memberof RemoteFileHandle
                 */
                _mk(d) {
                    return new Promise((resolve, reject) => {
                        if (!this.info) {
                            return reject(API.throwe(__("file meta-data not found: {0}", this.path)));
                        }
                        if (this.info.type === "file") {
                            return reject(API.throwe(__("{0} is not a directory", this.path)));
                        }
                        return API.handle
                            .mkdir(`${this.path}/${d}`)
                            .then((d) => {
                            if (d.error) {
                                return reject(API.throwe(__("{0}: {1}", d.error, this.path)));
                            }
                            return resolve(d);
                        })
                            .catch((e) => reject(__e(e)));
                    });
                }
                /**
                 * Delete file/folder
                 *
                 * @protected
                 * @returns {Promise<RequestResult>}
                 * @memberof RemoteFileHandle
                 */
                _rm() {
                    return new Promise((resolve, reject) => __awaiter(this, void 0, void 0, function* () {
                        try {
                            const d = yield API.handle.remove(this.path);
                            if (d.error) {
                                return reject(API.throwe(__("{0}: {1}", d.error, this.path)));
                            }
                            return resolve(d);
                        }
                        catch (e) {
                            return reject(__e(e));
                        }
                    }));
                }
                /**
                 * Move file/folder
                 *
                 * @protected
                 * @param {string} d
                 * @returns {Promise<RequestResult>}
                 * @memberof RemoteFileHandle
                 */
                _mv(d) {
                    return new Promise((resolve, reject) => __awaiter(this, void 0, void 0, function* () {
                        try {
                            const r = yield API.handle.move(this.path, d);
                            if (r.error) {
                                return reject(API.throwe(__("{0}: {1}", r.error, this.path)));
                            }
                            return resolve(r);
                        }
                        catch (e) {
                            return reject(__e(e));
                        }
                    }));
                }
                /**
                 * Upload a file
                 *
                 * Only work with directory file handle
                 *
                 * @protected
                 * @returns {Promise<RequestResult>}
                 * @memberof RemoteFileHandle
                 */
                _up() {
                    return new Promise((resolve, reject) => {
                        if (this.info.type !== "dir") {
                            return reject(API.throwe(__("{0} is not a file", this.path)));
                        }
                        return API.handle
                            .upload(this.path)
                            .then((d) => {
                            if (d.error) {
                                return reject(API.throwe(__("{0}: {1}", d.error, this.path)));
                            }
                            return resolve(d);
                        })
                            .catch((e) => reject(__e(e)));
                    });
                }
                /**
                 * Download a file
                 *
                 * only work with file
                 *
                 * @protected
                 * @returns {Promise<void>}
                 * @memberof RemoteFileHandle
                 */
                _down() {
                    return new Promise((resolve, reject) => {
                        if (this.info.type === "dir") {
                            return API.throwe(__("{0} is not a file", this.path));
                        }
                        return API.handle
                            .fileblob(this.path)
                            .then((d) => {
                            const blob = new Blob([d], {
                                type: "octet/stream",
                            });
                            API.saveblob(this.basename, blob);
                            return resolve();
                        })
                            .catch((e) => reject(__e(e)));
                    });
                }
                /**
                 * Publish a file
                 *
                 * @protected
                 * @returns {Promise<RequestResult>}
                 * @memberof RemoteFileHandle
                 */
                _pub() {
                    return new Promise((resolve, reject) => __awaiter(this, void 0, void 0, function* () {
                        try {
                            const d = yield API.handle.sharefile(this.path, true);
                            if (d.error) {
                                return reject(API.throwe(__("{0}: {1}", d.error, this.path)));
                            }
                            return resolve(d);
                        }
                        catch (e) {
                            return reject(__e(e));
                        }
                    }));
                }
            }
            VFS.RemoteFileHandle = RemoteFileHandle;
            register("^(home|desktop|os|Untitled)$", RemoteFileHandle);
            /**
             * Package file is remote file ([[RemoteFileHandle]]) located either in
             * the local user packages location or system packages
             * location, it should be in the following format:
             *
             * ```
             * pkg://PKG_NAME/path/to/file
             *
             * ```
             *
             * The system will locale the package name PKG_NAME either in the system domain
             * or in user domain and return the correct path to the package
             *
             * @export
             * @class PackageFileHandle
             * @extends {RemoteFileHandle}
             */
            class PackageFileHandle extends RemoteFileHandle {
                /**
                 *Creates an instance of PackageFileHandle.
                 * @param {string} pkg_path package path in string
                 * @memberof PackageFileHandle
                 */
                constructor(pkg_path) {
                    var error;
                    var pkg_name;
                    super(pkg_path);
                    // now find the correct path
                    if (!this.genealogy || this.genealogy.length == 0) {
                        error = __("Invalid package path");
                        OS.announcer.oserror(error, API.throwe(error));
                        throw new Error(error.__());
                    }
                    else {
                        // get the correct path of the package
                        pkg_name = this.genealogy.shift();
                        if (OS.setting.system.packages[pkg_name]) {
                            this.setPath(OS.setting.system.packages[pkg_name].path + "/" + this.genealogy.join("/"));
                        }
                        else {
                            error = __("Package not found {0}", pkg_name);
                            OS.announcer.oserror(error, API.throwe(error));
                            throw new Error(error.__());
                        }
                    }
                }
            }
            VFS.PackageFileHandle = PackageFileHandle;
            register("^pkg$", PackageFileHandle);
            /**
             * Application file is an AntOS special file allowing to
             * refer to an application as a regular file. Its protocol
             * pattern is defined as:
             *
             * ```typescript
             * "^app$" // e.g. app://Setting
             * ```
             *
             * @class ApplicationHandle
             * @extends {BaseFileHandle}
             */
            class ApplicationHandle extends BaseFileHandle {
                /**
                 *Creates an instance of ApplicationHandle.
                 * @param {string} path file path
                 * @memberof ApplicationHandle
                 */
                constructor(path) {
                    super(path);
                    if (this.basename) {
                        let v = OS.setting.system.packages[this.basename];
                        this.info = {};
                        for (const p in v) {
                            this.info[p] = v[p];
                        }
                        this.info.type = "app";
                        this.info.mime = "antos/app";
                        this.info.size = 0;
                        this.info.text = v.name;
                    }
                    this.ready = true;
                }
                /**
                 * Read application meta-data
                 *
                 * @returns {Promise<RequestResult>}
                 * @memberof ApplicationHandle
                 */
                meta() {
                    return new Promise((resolve, reject) => resolve({
                        result: this.info,
                        error: false,
                    }));
                }
                /**
                 * If the current file is root (e.g. `app://`), the operation
                 * will return all system packages meta-data.
                 *
                 * Otherwise, an error will be thrown
                 *
                 * @protected
                 * @param {string} t
                 * @returns {Promise<any>}
                 * @memberof ApplicationHandle
                 */
                _rd(t) {
                    return new Promise((resolve, reject) => {
                        if (this.info) {
                            return resolve({
                                result: this.info,
                                error: false,
                            });
                        }
                        if (!this.isRoot()) {
                            return reject(API.throwe(__("Application meta data isnt found")));
                        }
                        const result = [];
                        for (let k in OS.setting.system.packages) {
                            const v = OS.setting.system.packages[k];
                            if (v.app) {
                                result.push(v);
                            }
                        }
                        return resolve({
                            result: result,
                            error: false,
                        });
                    });
                }
            }
            VFS.ApplicationHandle = ApplicationHandle;
            register("^app$", ApplicationHandle);
            var MEM_PARTITION = undefined;
            /**
             * A buffer file handle represents a virtual file that is stored
             * on the system memory. Its protocol pattern is defined as:
             *
             * ```typescript
             * "^mem$" // e.g. mem://test.txt
             * ```
             *
             * @class BufferFileHandle
             * @extends {BaseFileHandle}
             */
            class BufferFileHandle extends BaseFileHandle {
                /**
                 *Creates an instance of BufferFileHandle.
                 * @param {string} path file path
                 * @param {string} mime file mime-type
                 * @param {*} data file data
                 * @memberof BufferFileHandle
                 */
                constructor(path, mime, data) {
                    super(path);
                    this.info = {
                        mime: mime ? mime : 'application/octet-stream',
                        path: path,
                        size: data ? data.length : 0,
                        name: this.basename,
                        filename: this.basename,
                        ctime: (new Date()).toGMTString(),
                        mtime: (new Date()).toGMTString(),
                        type: 'file',
                    };
                    if (data) {
                        this.cache = data;
                    }
                    return this.init_file_tree();
                }
                /**
                 * init the mem file tree if necessary
                 */
                init_file_tree() {
                    if (this.isRoot()) {
                        if (!MEM_PARTITION) {
                            this.cache = {};
                            MEM_PARTITION = this;
                        }
                        return MEM_PARTITION;
                    }
                    let curr_level = "mem://".asFileHandle();
                    for (let i = 0; i < this.genealogy.length - 1; i++) {
                        const segment = this.genealogy[i];
                        let handle = undefined;
                        if (segment == "..") {
                            curr_level = curr_level.parent();
                            continue;
                        }
                        handle = curr_level.cache[segment];
                        if (!handle) {
                            handle = new BufferFileHandle(`${curr_level.path}/${segment}`, 'dir', {});
                            curr_level.cache[segment] = handle;
                        }
                        curr_level = handle;
                        if (!curr_level.cache) {
                            curr_level.cache = {};
                        }
                    }
                    if (this.basename == "..") {
                        return curr_level.parent();
                    }
                    if (!curr_level.cache[this.basename])
                        curr_level.cache[this.basename] = this;
                    return curr_level.cache[this.basename];
                }
                /**
                 * cache changed handle
                 */
                _cache_changed() {
                    if (!this.cache) {
                        return;
                    }
                    this.info.mime = (new Date()).toGMTString();
                    if (typeof this.cache === "string" || this.cache instanceof Blob || this.cache instanceof Uint8Array) {
                        this.info.type = "file";
                        if (typeof this.cache === "string") {
                            this.info.mime = "text/plain";
                        }
                        else {
                            this.info.mime = "application/octet-stream";
                        }
                    }
                    else {
                        this.info.type = "dir";
                        this.info.mime = "dir";
                    }
                    this.info.size = this.cache.length;
                }
                /**
                 * Read the file meta-data
                 *
                 * @returns {Promise<RequestResult>}
                 * @memberof BufferFileHandle
                 */
                meta() {
                    return new Promise((resolve, reject) => {
                        const data = {};
                        for (const k in this.info) {
                            data[k] = this.info[k];
                        }
                        resolve({
                            result: data,
                            error: false,
                        });
                    });
                }
                /**
                 * Load the file meta-data before performing
                 * any task
                 *
                 * @returns {Promise<FileInfoType>} a promise on file meta-data
                 * @memberof BufferFileHandle
                 */
                onready() {
                    // read meta data
                    return new Promise((resolve, reject) => __awaiter(this, void 0, void 0, function* () {
                        try {
                            const d = yield this.meta();
                            resolve(d.result);
                        }
                        catch (e) {
                            reject(__e(e));
                        }
                    }));
                }
                /**
                 * Read file content stored in the file cached
                 *
                 * @protected
                 * @param {string} t data type see [[read]]
                 * @returns {Promise<any>}
                 * @memberof BufferFileHandle
                 */
                _rd(t) {
                    return new Promise((resolve, reject) => {
                        // read dir
                        if (this.info.type === "dir") {
                            return resolve({
                                result: Object.values(this.cache).map(o => o.info),
                                error: false,
                            });
                        }
                        return resolve(this.cache);
                    });
                }
                /**
                 * Write data to the file cache
                 *
                 * @protected
                 * @param {string} t data type, see [[write]]
                 * @returns {Promise<RequestResult>}
                 * @memberof BufferFileHandle
                 */
                _wr(t) {
                    return new Promise((resolve, reject) => resolve({
                        result: true,
                        error: false,
                    }));
                }
                /**
                 * Create sub directory
                 *
                 * Only work on directory file handle
                 *
                 * @protected
                 * @param {string} d sub directory name
                 * @returns {Promise<RequestResult>}
                 * @memberof BufferFileHandle
                 */
                _mk(d) {
                    return new Promise((resolve, reject) => {
                        if (this.info.type === "file") {
                            return reject(API.throwe(__("{0} is not a directory", this.path)));
                        }
                        const handle = `${this.path}/${d}`.asFileHandle();
                        if (handle.info.type === "file") {
                            handle.cache = {};
                        }
                        resolve({ result: true, error: false });
                    });
                }
                /**
                 * Delete file/folder
                 *
                 * @protected
                 * @returns {Promise<RequestResult>}
                 * @memberof BufferFileHandle
                 */
                _rm() {
                    return new Promise((resolve, reject) => __awaiter(this, void 0, void 0, function* () {
                        try {
                            const parent = this.parent();
                            parent.cache[this.basename] = undefined;
                            delete parent.cache[this.basename];
                            return resolve({ result: true, error: false });
                        }
                        catch (e) {
                            return reject(__e(e));
                        }
                    }));
                }
                setPath(p) {
                    super.setPath(p);
                    if (this.info)
                        this.info.path = this.path;
                }
                updatePath(path) {
                    this.setPath(path);
                    if (this.info.type == "file") {
                        return;
                    }
                    for (const k in this.cache) {
                        const child = this.cache[k];
                        child.updatePath(`${this.path}/${child.basename}`);
                    }
                }
                /**
                 * Move file/folder
                 *
                 * @protected
                 * @param {string} d
                 * @returns {Promise<RequestResult>}
                 * @memberof BufferFileHandle
                 */
                _mv(d) {
                    return new Promise((resolve, reject) => __awaiter(this, void 0, void 0, function* () {
                        try {
                            if (d.includes(this.path)) {
                                return reject(API.throwe(__("Unable to move file/folder from {0} to {1}", this.path, d)));
                            }
                            const parent = this.parent();
                            parent.cache[this.basename] = undefined;
                            delete parent.cache[this.basename];
                            const dest = d.asFileHandle();
                            this.updatePath(dest.path);
                            dest.parent().cache[dest.basename] = this;
                            return resolve({ result: true, error: false });
                        }
                        catch (e) {
                            console.log(this);
                            return reject(__e(e));
                        }
                    }));
                }
                /**
                 * Download the buffer file
                 *
                 * @protected
                 * @returns {Promise<void>}
                 * @memberof BufferFileHandle
                 */
                _down() {
                    return new Promise((resolve, reject) => {
                        if (this.info.type == "dir") {
                            return reject(API.throwe(__("{0} is a directory", this.path)));
                        }
                        const blob = new Blob([this.cache], {
                            type: "octet/stream",
                        });
                        API.saveblob(this.basename, blob);
                        return resolve();
                    });
                }
            }
            VFS.BufferFileHandle = BufferFileHandle;
            API.VFS.register("^mem$", BufferFileHandle);
            /**
             * URL file handle represents a HTTP/HTTPs link url
             * as an AntOS VFS file handle. Its protocol is defined as
             *
             * ```
             * ^(http|https|ftp)$
             * ```
             *
             * @class URLFileHandle
             * @extends {BaseFileHandle}
             */
            class URLFileHandle extends BaseFileHandle {
                /**
                 *Creates an instance of URLFileHandle.
                 * @param {string} path
                 * @memberof URLFileHandle
                 */
                constructor(path) {
                    super(path);
                    this.ready = true;
                    this.info = {
                        path: path,
                        name: path,
                        mime: "url",
                        type: "url",
                        size: 0,
                    };
                }
                /**
                 * Read file meta-data
                 *
                 * @returns {Promise<RequestResult>}
                 * @memberof URLFileHandle
                 */
                meta() {
                    return new Promise((resolve, reject) => resolve({
                        result: this.info,
                        error: false,
                    }));
                }
                /**
                 * Read URL content
                 *
                 * @protected
                 * @param {string} t data type see [[read]]
                 * @returns {Promise<any>}
                 * @memberof URLFileHandle
                 */
                _rd(t) {
                    //read the file
                    if (t === "binary") {
                        //return API.handle.fileblob(this.path);
                        return API.blob(this.path + "?_=" + new Date().getTime());
                    }
                    return API.get(this.path, t ? t : "text");
                }
            }
            VFS.URLFileHandle = URLFileHandle;
            API.VFS.register("^(http|https|ftp)$", URLFileHandle);
            /**
             * Shared file handle represents all AntOS shared file.
             * Its protocol is defined as:
             *
             * ```
             * ^shared$
             * ```
             *
             * @class SharedFileHandle
             * @extends {API.VFS.BaseFileHandle}
             */
            class SharedFileHandle extends API.VFS.BaseFileHandle {
                /**
                 *Creates an instance of SharedFileHandle.
                 * @param {string} path file path
                 * @memberof SharedFileHandle
                 */
                constructor(path) {
                    super(path);
                    if (this.isRoot()) {
                        this.ready = true;
                    }
                }
                /**
                 * Read file meta-data
                 *
                 * @returns {Promise<RequestResult>}
                 * @memberof SharedFileHandle
                 */
                meta() {
                    return API.handle.fileinfo(this.path);
                }
                /**
                 * Read file content
                 *
                 * @protected
                 * @param {string} t data type, see [[read]]
                 * @returns {Promise<any>}
                 * @memberof SharedFileHandle
                 */
                _rd(t) {
                    if (this.isRoot()) {
                        return API.get(`${API.handle.shared}/all`, t);
                    }
                    //read the file
                    if (t === "binary") {
                        return API.handle.fileblob(this.path);
                    }
                    return API.handle.readfile(this.path, t ? t : "text");
                }
                /**
                 * write data to shared file
                 *
                 * @protected
                 * @param {string} t data type, see [[write]]
                 * @param {string} d file data
                 * @returns {Promise<RequestResult>}
                 * @memberof SharedFileHandle
                 */
                _wr(t, d) {
                    return new Promise((resolve, reject) => __awaiter(this, void 0, void 0, function* () {
                        try {
                            const r = yield API.handle.write(this.path, d);
                            if (r.error) {
                                return reject(API.throwe(__("{0}: {1}", r.error, this.path)));
                            }
                            return resolve(r);
                        }
                        catch (e) {
                            return reject(__e(e));
                        }
                    }));
                }
                /**
                 * Un-publish the file
                 *
                 * @protected
                 * @returns {Promise<RequestResult>}
                 * @memberof SharedFileHandle
                 */
                _rm() {
                    return new Promise((resolve, reject) => __awaiter(this, void 0, void 0, function* () {
                        try {
                            const d = yield API.handle.sharefile(this.basename, false);
                            if (d.error) {
                                return reject(API.throwe(__("{0}: {1}", d.error, this.path)));
                            }
                            return resolve(d);
                        }
                        catch (e) {
                            return reject(__e(e));
                        }
                    }));
                }
                /**
                 * Download shared file
                 *
                 * @protected
                 * @returns {Promise<void>}
                 * @memberof SharedFileHandle
                 */
                _down() {
                    return new Promise((resolve, reject) => {
                        if (this.info.type === "dir") {
                            return reject(API.throwe(__("{0} is not a file", this.path)));
                        }
                        return API.handle
                            .fileblob(this.path)
                            .then((data) => {
                            const blob = new Blob([data], {
                                type: "octet/stream",
                            });
                            API.saveblob(this.basename, blob);
                            return resolve();
                        })
                            .catch((e) => reject(__e(e)));
                    });
                }
                /**
                 * Un publish the file
                 *
                 * @protected
                 * @returns {Promise<RequestResult>}
                 * @memberof SharedFileHandle
                 */
                _pub() {
                    return new Promise((resolve, reject) => resolve({
                        result: this.basename,
                        error: false,
                    }));
                }
            }
            VFS.SharedFileHandle = SharedFileHandle;
            API.VFS.register("^shared$", SharedFileHandle);
            /**Utilities global functions */
            /**
             * Read a file content from a zip archive
             *
             * The content type should be:
             * - base64 : the result will be a string, the binary in a base64 form.
             * - text (or string): the result will be an unicode string.
             * - binarystring: the result will be a string in “binary” form, using 1 byte per char (2 bytes).
             * - array: the result will be an Array of bytes (numbers between 0 and 255).
             * - uint8array : the result will be a Uint8Array. This requires a compatible browser.
             * - arraybuffer : the result will be a ArrayBuffer. This requires a compatible browser.
             * - blob : the result will be a Blob. This requires a compatible browser.             *
             * If file_name is not specified, the first file_name in the zip archive will be read
             * @export
             * @param {string} file zip file
             * @param {string} type content type to read
             * @param {string} [file_name] the file should be read from the zip archive
             * @return {*}  {Promise<any>}
             */
            function readFileFromZip(file, type, file_name) {
                return new Promise((resolve, reject) => __awaiter(this, void 0, void 0, function* () {
                    try {
                        yield API.requires("os://scripts/jszip.min.js");
                        const data = yield file.asFileHandle().read("binary");
                        const zip = yield JSZip.loadAsync(data);
                        if (!file_name) {
                            for (let name in zip.files) {
                                file_name = name;
                                break;
                            }
                        }
                        const udata = yield zip.file(file_name).async(type);
                        resolve(udata);
                    }
                    catch (e) {
                        return reject(__e(e));
                    }
                }));
            }
            VFS.readFileFromZip = readFileFromZip;
            /**
             * Cat all files to a single out-put
             *
             * @export
             * @param {string[]} list list of VFS files
             * @param {string} data input data string that will be cat to the files content
             * @param {string} join_by join on files content by this string
             * @return {*}  {Promise<string>}
             */
            function cat(list, data, join_by = "\n") {
                return new Promise((resolve, reject) => __awaiter(this, void 0, void 0, function* () {
                    if (list.length === 0) {
                        return resolve(data);
                    }
                    const promises = [];
                    for (const file of list) {
                        promises.push(file.asFileHandle().read("text"));
                    }
                    try {
                        const results = yield Promise.all(promises);
                        resolve(`${data}${join_by}${results.join(join_by)}`);
                    }
                    catch (error) {
                        reject(__e(error));
                    }
                }));
            }
            VFS.cat = cat;
            /**
             * Read all files content on the list
             *
             * @export
             * @param {string[]} list list of VFS files
             * @param {GenericObject<string>[]} contents content array
             * @return {void}
             */
            function read_files(list) {
                const promises = [];
                for (const file of list) {
                    promises.push(file.asFileHandle().read("text"));
                }
                return Promise.all(promises);
            }
            VFS.read_files = read_files;
            /**
             * Copy files to a folder
             *
             * @export
             * @param {string[]} files list of files
             * @param {string} to destination folder
             * @return {*}  {Promise<any[]>}
             */
            function copy(files, to) {
                const promises = [];
                for (const path of files) {
                    promises.push(new Promise((resolve, reject) => __awaiter(this, void 0, void 0, function* () {
                        try {
                            const file = path.asFileHandle();
                            const meta = yield file.onready();
                            if (meta.type === "dir") {
                                const desdir = to.asFileHandle();
                                yield desdir.mk(file.basename);
                                console.log(desdir, to);
                                const ret = yield file.read();
                                const files = ret.result.map((v) => v.path);
                                if (files.length > 0) {
                                    yield copy(files, `${desdir.path}/${file.basename}`);
                                    resolve(undefined);
                                }
                                else {
                                    resolve(undefined);
                                }
                            }
                            else {
                                const tof = `${to}/${file.basename}`.asFileHandle();
                                const content = yield file.read("binary");
                                yield tof
                                    .setCache(new Blob([content], {
                                    type: file.info.mime,
                                }))
                                    .write(file.info.mime);
                                resolve(undefined);
                            }
                        }
                        catch (error) {
                            reject(__e(error));
                        }
                    })));
                }
                return Promise.all(promises);
            }
            VFS.copy = copy;
            /**
             * Add a list of files to the zip archive
             *
             * @param {string[]} list list of VFS files
             * @param {*} zip JSZip handle
             * @param {string} base root path of all added files in the zip
             * @return {*}  {Promise<any>}
             */
            function aradd(list, zip, base) {
                const promises = [];
                for (const path of list) {
                    promises.push(new Promise((resolve, reject) => __awaiter(this, void 0, void 0, function* () {
                        const file = path.asFileHandle();
                        try {
                            const meta = yield file.asFileHandle().onready();
                            if (meta.type == "dir") {
                                const ret = yield file.read();
                                const dirs = ret.result.map((v) => v.path);
                                if (dirs.length > 0) {
                                    yield aradd(dirs, zip, `${base}${file.basename}/`);
                                    resolve(undefined);
                                }
                                else {
                                    resolve(undefined);
                                }
                            }
                            else {
                                const u_data = yield file.read("binary");
                                const z_path = `${base}${file.basename}`.replace(/^\/+|\/+$/g, "");
                                zip.file(z_path, u_data, { binary: true });
                                resolve(undefined);
                            }
                        }
                        catch (error) {
                            reject(__e(error));
                        }
                    })));
                }
                return Promise.all(promises);
            }
            /**
             * Create a zip archive from a folder
             *
             * @export
             * @param {string} src source file/folder
             * @param {string} dest destination archive
             * @return {*}  {Promise<void>}
             */
            function mkar(src, dest) {
                return new Promise((resolve, reject) => __awaiter(this, void 0, void 0, function* () {
                    try {
                        yield API.requires("os://scripts/jszip.min.js");
                        const zip = new JSZip();
                        const fhd = src.asFileHandle();
                        const meta = yield fhd.onready();
                        if (meta.type === "file") {
                            yield aradd([src], zip, "/");
                        }
                        else {
                            const ret = yield fhd.read();
                            yield aradd(ret.result.map((v) => v.path), zip, "/");
                        }
                        const z_data = yield zip.generateAsync({ type: "base64" });
                        yield dest.asFileHandle()
                            .setCache("data:application/zip;base64," + z_data)
                            .write("base64");
                        resolve();
                    }
                    catch (error) {
                        reject(__e(error));
                    }
                }));
            }
            VFS.mkar = mkar;
            /**
             * Create a list of directories
             *
             * @export
             * @param {string[]} list of directories to be created
             * @param {boolen} sync sync/async of directory creation
             * @return {*}  {Promise<any>}
             */
            function mkdirAll(list, sync) {
                if (!sync) {
                    const promises = [];
                    for (const dir of list) {
                        const path = dir.asFileHandle();
                        promises.push(path.parent().mk(path.basename));
                    }
                    return Promise.all(promises);
                }
                else {
                    return new Promise((resolve, reject) => __awaiter(this, void 0, void 0, function* () {
                        try {
                            if (list.length === 0) {
                                return resolve(true);
                            }
                            const dir = list.splice(0, 1)[0].asFileHandle();
                            const path = dir.parent();
                            const dname = dir.basename;
                            const r = yield path.asFileHandle().mk(dname);
                            if (r.error) {
                                return reject(this._api.throwe(__("Cannot create {0}", `${path}/${dir}`)));
                            }
                            yield mkdirAll(list, sync);
                            resolve(true);
                        }
                        catch (e) {
                            reject(__e(e));
                        }
                    }));
                }
            }
            VFS.mkdirAll = mkdirAll;
            /**
             *
             *
             * @export Extract a zip fle
             * @param {string} zfile zip file to extract
             * @param {(zip:any) => Promise<string>} [dest_callback] a callback to get extraction destination
             * @return {*}  {Promise<void>}
             */
            function extractZip(zfile, dest_callback) {
                return new Promise((resolve, reject) => __awaiter(this, void 0, void 0, function* () {
                    try {
                        yield API.requires("os://scripts/jszip.min.js");
                        const data = yield zfile.asFileHandle().read("binary");
                        const zip = yield JSZip.loadAsync(data);
                        const to = yield dest_callback(zip);
                        const dirs = [];
                        const files = [];
                        for (const name in zip.files) {
                            const file = zip.files[name];
                            if (file.dir) {
                                dirs.push(to + "/" + name);
                            }
                            else {
                                files.push(name);
                            }
                        }
                        yield mkdirAll(dirs, true);
                        const promises = [];
                        for (const file of files) {
                            promises.push(new Promise((res, rej) => __awaiter(this, void 0, void 0, function* () {
                                try {
                                    const data = yield zip.file(file).async("uint8array");
                                    const path = `${to}/${file}`;
                                    const fp = path.asFileHandle();
                                    fp.cache = new Blob([data], { type: "octet/stream" });
                                    const r = yield fp.write("text/plain");
                                    if (r.error) {
                                        return rej(API.throwe(__("Cannot extract file to {0}", path)));
                                    }
                                    return res(path);
                                }
                                catch (error) {
                                    rej(__e(error));
                                }
                            })));
                        }
                        yield Promise.all(promises);
                        resolve();
                    }
                    catch (e) {
                        return reject(__e(e));
                    }
                }));
            }
            VFS.extractZip = extractZip;
            /**
             * Make files from a set of template files
             *
             * @export
             * @param {Array<string[]>} list mapping paths between templates files and created files
             * @param {string} path files destination
             * @param {(data: string) => string} callback: pre-processing files content before writing to destination files
             * @return {*}  {Promise<any[]>}
             */
            function mktpl(list, path, callback) {
                const promises = [];
                for (const tpl of list) {
                    promises.push(new Promise((resolve, reject) => __awaiter(this, void 0, void 0, function* () {
                        try {
                            const data = yield `${path}/${tpl[0]}`.asFileHandle().read();
                            const file = tpl[1].asFileHandle();
                            file.setCache(callback(data));
                            yield file.write("text/plain");
                            resolve(undefined);
                        }
                        catch (error) {
                            reject(__e(error));
                        }
                    })));
                }
                return Promise.all(promises);
            }
            VFS.mktpl = mktpl;
        })(VFS = API.VFS || (API.VFS = {}));
    })(API = OS.API || (OS.API = {}));
})(OS || (OS = {}));

// Copyright 2017-2018 Xuan Sang LE <xsang.le AT gmail DOT com>
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
// AnTOS Web desktop is is licensed under the GNU General Public
// License v3.0, see the LICENCE file for more information
// This program is free software: you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation, either version 3 of
// the License, or (at your option) any later version.
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// General Public License for more details.
// You should have received a copy of the GNU General Public License
// along with this program. If not, see https://www.gnu.org/licenses/.
var OS;
(function (OS) {
    let API;
    (function (API) {
        /**
         * Simple Virtual Database (VDB) application API.
         *
         * This API abstracts and provides a standard way to
         * connect to a server-side relational database (e.g. sqlite).
         *
         * Each user when connected has their own database previously
         * created. All VDB operations related to that user will be
         * performed on this database.
         *
         * The creation of user database need to be managed by the server-side API.
         * The VDB API assumes that the database already exist. All operations
         * is performed in tables level
         *
         * @export
         * @class DB
         */
        class DB {
            /**
             *Creates an instance of DB.
             * @param {string} table table name
             * @memberof DB
             */
            constructor(table) {
                this.table = table;
            }
            /**
             * Save data to the current table. The input
             * data must conform to the table record format.
             *
             * On the server side, if the table doest not
             * exist yet, it should be created automatically
             * by inferring the data structure of the input
             * object
             *
             * @param {GenericObject<any>} d data object represents a current table record
             * @returns {Promise<API.RequestResult>}
             * @memberof DB
             */
            save(d) {
                return new Promise((resolve, reject) => __awaiter(this, void 0, void 0, function* () {
                    try {
                        const r = yield API.handle.dbquery("save", {
                            table: this.table,
                            data: d,
                        });
                        if (r.error) {
                            return reject(API.throwe(r.error.toString()));
                        }
                        return resolve(r);
                    }
                    catch (e) {
                        return reject(__e(e));
                    }
                }));
            }
            /**
             * delete record(s) from the current table by
             * a conditional object
             *
             * @param {*} c conditional object, c can be:
             *
             * * a `number`: the operation will delete the record with `id = c`
             * * a `string`: The SQL string condition that selects record to delete
             * * a conditional object represents a SQL condition statement as an object,
             * example: `pid = 10 AND cid = 2` is represented by:
             *
             * ```typescript
             *  {
             *      exp: {
             *          "and": {
             *              pid: 10,
             *              cid: 2
             *          }
             *  }
             * ```
             *
             * @returns {Promise<API.RequestResult>}
             * @memberof DB
             */
            delete(c) {
                return new Promise((resolve, reject) => __awaiter(this, void 0, void 0, function* () {
                    const rq = { table: this.table };
                    if (!c || c === "") {
                        reject(API.throwe("OS.DB: unknown condition"));
                    }
                    if (isNaN(c)) {
                        rq.cond = c;
                    }
                    else {
                        rq.id = c;
                    }
                    try {
                        const r = yield API.handle.dbquery("delete", rq);
                        if (r.error) {
                            return reject(API.throwe(r.error.toString()));
                        }
                        return resolve(r);
                    }
                    catch (e) {
                        return reject(__e(e));
                    }
                }));
            }
            /**
             * Get a record in the table by its primary key
             *
             * @param {number} id the primary key value
             * @returns {Promise<GenericObject<any>>} Promise on returned record data
             * @memberof DB
             */
            get(id) {
                return new Promise((resolve, reject) => __awaiter(this, void 0, void 0, function* () {
                    try {
                        const r = yield API.handle.dbquery("get", {
                            table: this.table,
                            id: id,
                        });
                        if (r.error) {
                            return reject(API.throwe(r.error.toString()));
                        }
                        return resolve(r.result);
                    }
                    catch (e) {
                        return reject(__e(e));
                    }
                }));
            }
            /**
             * Find records by a condition
             *
             * @param {GenericObject<any>} cond conditional object
             *
             * a conditional object represents a SQL condition statement as an object,
             * example: `pid = 10 AND cid = 2 ORDER BY date DESC` is represented by:
             *
             * ```typescript
             *  {
             *      exp: {
             *          "and": {
             *              pid: 10,
             *              cid: 2
             *          }
             *      },
             *      order: {
             *          date: "DESC"
             *      }
             *  }
             * ```
             * @returns {Promise<GenericObject<any>[]>}
             * @memberof DB
             */
            find(cond) {
                return new Promise((resolve, reject) => __awaiter(this, void 0, void 0, function* () {
                    try {
                        const r = yield API.handle.dbquery("select", {
                            table: this.table,
                            cond,
                        });
                        if (r.error) {
                            return reject(API.throwe(r.error.toString()));
                        }
                        return resolve(r.result);
                    }
                    catch (e) {
                        return reject(__e(e));
                    }
                }));
            }
        }
        API.DB = DB;
    })(API = OS.API || (OS.API = {}));
})(OS || (OS = {}));

// Copyright 2017-2018 Xuan Sang LE <xsang.le AT gmail DOT com>
// AnTOS Web desktop is is licensed under the GNU General Public
// License v3.0, see the LICENCE file for more information
// This program is free software: you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation, either version 3 of
// the License, or (at your option) any later version.
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// General Public License for more details.
// You should have received a copy of the GNU General Public License
//along with this program. If not, see https://www.gnu.org/licenses/.
var OS;
(function (OS) {
    /**
     * Enum definition of different model types
     *
     * @export
     * @enum {number}
     */
    let ModelType;
    (function (ModelType) {
        /**
         * Applications
         */
        ModelType[ModelType["Application"] = 0] = "Application";
        /**
         * Services
         */
        ModelType[ModelType["Service"] = 1] = "Service";
        /**
         * Sub-window such as dialogs
         */
        ModelType[ModelType["SubWindow"] = 2] = "SubWindow";
    })(ModelType = OS.ModelType || (OS.ModelType = {}));
    /**
     * Base AntOS event definition
     *
     * @export
     * @class BaseEvent
     */
    class BaseEvent {
        /**
         *Creates an instance of BaseEvent.
         * @param {string} name event name
         * @param {boolean} force indicates whether the event is forced
         * @memberof BaseEvent
         */
        constructor(name, force) {
            this.name = name;
            this.force = force;
            this.prevent = false;
        }
        /**
         * Prevent the current event. This function
         * has no effect if `force` is set to true
         *
         * @memberof BaseEvent
         */
        preventDefault() {
            if (!this.force) {
                this.prevent = true;
            }
        }
    }
    OS.BaseEvent = BaseEvent;
    /**
     * The root model of all applications, dialogs or services
     * in the system
     *
     * @export
     * @abstract
     * @class BaseModel
     */
    class BaseModel {
        /**
         *Creates an instance of BaseModel.
         * @param {string} name class name
         * @param {AppArgumentsType[]} args arguments
         * @memberof BaseModel
         */
        constructor(name, args) {
            this.name = name;
            this.args = args;
            this._observable = new OS.API.Announcer();
            this._api = OS.API;
            this._gui = OS.GUI;
            this.systemsetting = OS.setting;
            this.on("exit", () => this.quit(false));
            this.host = this._gui.desktop();
            this.dialog = undefined;
            // relay global events to local events
            this.subscribe("desktopresize", (e) => this.observable.trigger("desktopresize", e));
        }
        /**
         * Getter: get the local announcer object
         *
         * @readonly
         * @type {API.Announcer}
         * @memberof BaseModel
         */
        get observable() {
            return this._observable;
        }
        /**
         * Update the model locale
         *
         * @param {string} name
         * @memberof BaseModel
         */
        updateLocale(name) { }
        /**
         * Render the model's UI
         *
         * @protected
         * @param {string} p VFS path to the UI scheme definition
         * @returns {void}
         * @memberof BaseModel
         */
        render(p) {
            return OS.GUI.loadScheme(p, this, this.host);
        }
        /**
         * Exit the model
         *
         * @param {boolean} force set this value to `true` will bypass the prevented exit event by user
         * @returns {void}
         * @memberof BaseModel
         */
        quit(force = false) {
            const evt = new BaseEvent("exit", force);
            this.onexit(evt);
            if (!evt.prevent) {
                if (this.observable) {
                    this.observable.off("*");
                    delete this._observable;
                }
                if (this.dialog) {
                    this.dialog.quit();
                }
                OS.announcer.unregister(this);
                this.destroy();
            }
        }
        /**
         * Purge the model from the system
         *
         * @protected
         * @memberof BaseModel
         */
        destroy() {
            return OS.PM.kill(this);
        }
        /**
         * VFS path to the model asset
         *
         * @returns {string}
         * @memberof BaseModel
         */
        path() {
            const mt = this.meta();
            if (mt && mt.path) {
                return mt.path;
            }
            return null;
        }
        /**
         * Execute a server side script and get back the result
         *
         * @protected
         * @param {GenericObject<any>} cmd execution indication, should be:
         *
         * ```
         * {
         *      path?: string, // VFS path to the server side script
         *      code: string, // or server side code to be executed
         *      parameters: any // the parameters of the server side execution
         * }
         * ```
         *
         * @returns {Promise<any>}
         * @memberof BaseModel
         */
        call(cmd) {
            return this._api.apigateway(cmd, false);
        }
        /**
         * Connect to the server side api using a websocket connection
         *
         * Server side script can be execute inside the stream by writing
         * data in JSON format with the following interface
         *
         * ```
         * {
         *      path?: string, // VFS path to the server side script
         *      code: string, // or server side code to be executed
         *      parameters: any // the parameters of the server side execution
         * }
         * ```
         *
         * @protected
         * @returns {Promise<WebSocket>}
         * @memberof BaseModel
         */
        stream() {
            return this._api.apigateway(null, true);
        }
        /**
         * subscribe once to a local event
         *
         * @protected
         * @param {string} e name of the event
         * @param {(d: any) => void} f event callback
         * @returns {void}
         * @memberof BaseModel
         */
        one(e, f) {
            return this.observable.one(e, f);
        }
        /**
         * Subscribe to a local event
         *
         * @protected
         * @param {string} e event name
         * @param {(d: any) => void} f event callback
         * @returns {void}
         * @memberof BaseModel
         */
        on(e, f) {
            return this.observable.on(e, f);
        }
        /**
         * Unsubscribe an event
         *
         * @protected
         * @param {string} e event name or `*` (all events)
         * @param {(d: any) => void} [f] callback to be unsubscribed, can be `undefined`
         * @returns {void}
         * @memberof BaseModel
         */
        off(e, f) {
            if (!f) {
                return this.observable.off(e);
            }
            return this.observable.off(e, f);
        }
        /**
         * trigger a local event
         *
         * @param {string} e event name
         * @param {*} [d] event data
         * @returns {void}
         * @memberof BaseModel
         */
        trigger(e, d) {
            if (!this.observable)
                return;
            this.observable.trigger(e, d);
        }
        /**
         * subscribe to an event on the global announcement system
         *
         * @protected
         * @param {string} e event name
         * @param {(d: API.AnnouncementDataType<any>) => void} f event callback
         * @returns {void}
         * @memberof BaseModel
         */
        subscribe(e, f) {
            return OS.announcer.on(e, f, this);
        }
        /**
         * Open a dialog
         *
         * @param {(GUI.BaseDialog | string)} d a dialog object or a dialog class name
         * @param {GenericObject<any>} [data] input data of the dialog, refer to each
         * dialog definition for the format of the input data
         * @returns {Promise<any>} A promise on the callback data of the dialog, refer
         * to each dialog definition for the format of the callback data
         * @memberof BaseModel
         */
        openDialog(d, data) {
            return new Promise((resolve, reject) => {
                if (this.dialog) {
                    this.dialog.show();
                    return;
                }
                if (typeof d === "string") {
                    if (!OS.GUI.dialogs[d]) {
                        this.error(__("Dialog {0} not found", d));
                        return;
                    }
                    this.dialog = new OS.GUI.dialogs[d]();
                }
                else {
                    this.dialog = d;
                }
                //@dialog.observable = riot.observable() unless @dialog
                this.dialog.parent = this;
                this.dialog.handle = resolve;
                this.dialog.pid = this.pid;
                this.dialog.data = data;
                return this.dialog.init();
            });
        }
        /**
         * Open a [[YesNoDialog]] to confirm a task
         *
         * @protected
         * @param {GenericObject<any>} data [[YesNoDialog]] input data
         * @returns {Promise<boolean>}
         * @memberof BaseModel
         */
        ask(data) {
            return this._gui.openDialog("YesNoDialog", data);
        }
        /**
         * Trigger a global event
         *
         * @protected
         * @param {string} t event name
         * @param {(string | FormattedString)} m event message
         * @param {any} u_data user data object if any
         * @returns {void}
         * @memberof BaseModel
         */
        publish(t, m, u_data) {
            const mt = this.meta();
            const data = {};
            data.icon = undefined;
            if (mt && mt.icon) {
                data.icon = `${mt.path}/${mt.icon}`;
            }
            data.id = this.pid;
            data.name = this.name;
            data.message = m;
            data.iconclass = mt ? mt.iconclass : undefined;
            data.u_data = u_data;
            return OS.announcer.trigger(t, data);
        }
        /**
         * Publish a global notification
         *
         * @param {(string | FormattedString)} m notification string
         * @param {any} u_data user data object if any
         * @returns {void}
         * @memberof BaseModel
         */
        notify(m, data) {
            return this.publish("notification", m, data);
        }
        /**
         * Publish a global warning
         *
         * @param {(string | FormattedString)} m warning string
         * @returns {void}
         * @memberof BaseModel
         */
        warn(m) {
            return this.publish("warning", m);
        }
        /**
         * Report a global error
         *
         * @param {(string | FormattedString)} m error message
         * @param {Error} [e] error object if any
         * @returns
         * @memberof BaseModel
         */
        error(m, e) {
            return this.publish("error", m, e ? e : this._api.throwe(m));
        }
        /**
         * Report a global fail event
         *
         * @param {string} m fail message
         * @param {Error} [e] error object if any
         * @returns
         * @memberof BaseModel
         */
        fail(m, e) {
            return this.publish("fail", m, e ? e : this._api.throwe(m));
        }
        /**
         * Throw an error inside the model
         *
         * @returns {Error}
         * @memberof BaseModel
         */
        throwe() {
            return this._api.throwe(this.name);
        }
        /**
         * Update the model, this will update all its UI elements
         *
         * @returns {void}
         * @memberof BaseModel
         */
        update() {
            if (this.scheme) {
                this.scheme.update();
            }
            if (this.dialog) {
                this.dialog.update();
            }
        }
        /**
         * Find a HTMLElement in the UI of the model
         * using the `data-id` attribute of the element
         *
         * @protected
         * @param {string} id
         * @returns {HTMLElement}
         * @memberof BaseModel
         */
        find(id) {
            if (this.scheme) {
                return $(`[data-id='${id}']`, this.scheme)[0];
            }
        }
        /**
         * Select all DOM Element inside the UI of the model
         * using JQuery selector
         *
         * @protected
         * @param {string} sel
         * @returns {HTMLElement}
         * @memberof BaseModel
         */
        select(sel) {
            if (this.scheme) {
                return $(sel, this.scheme);
            }
        }
    }
    OS.BaseModel = BaseModel;
})(OS || (OS = {}));

// Copyright 2017-2018 Xuan Sang LE <xsang.le AT gmail DOT com>
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
// AnTOS Web desktop is is licensed under the GNU General Public
// License v3.0, see the LICENCE file for more information
// This program is free software: you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation, either version 3 of
// the License, or (at your option) any later version.
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// General Public License for more details.
// You should have received a copy of the GNU General Public License
//along with this program. If not, see https://www.gnu.org/licenses/.
var OS;
(function (OS) {
    /**
     * This namespace is dedicated to application and service definition.
     * When an application is loaded, its prototype definition will be
     * inserted to this namespace for reuse lately
     */
    let application;
    (function (application) {
        /**
         * Abstract prototype of all AntOS applications.
         * Any new application definition should extend
         * this prototype
         *
         * @export
         * @abstract
         * @class BaseApplication
         * @extends {BaseModel}
         */
        class BaseApplication extends OS.BaseModel {
            /**
             *Creates an instance of BaseApplication.
             * @param {string} name application name
             * @param {AppArgumentsType[]} args application arguments
             * @memberof BaseApplication
             */
            constructor(name, args) {
                super(name, args);
                if (!OS.setting.applications[this.name]) {
                    OS.setting.applications[this.name] = {};
                }
                this.setting = OS.setting.applications[this.name];
                this.keycomb = {};
                this._loading_toh = undefined;
                this._pending_task = [];
            }
            /**
             * Init the application, this function is called when the
             * application process is created and docked in the application
             * dock.
             *
             * The application UI will be rendered after the execution
             * of this function.
             *
             * @returns {void}
             * @memberof BaseApplication
             */
            init() {
                this.off("*");
                this.on("exit", () => this.quit(false));
                // first register some base event to the app
                this.on("focus", () => {
                    this.sysdock.selectedApp = this;
                    this.scheme.onmenuopen = (el) => el.nodes = this.baseMenu() || [];
                    OS.PM.pidactive = this.pid;
                    this.trigger("focused", undefined);
                    if (this.dialog) {
                        return this.dialog.show();
                    }
                });
                this.on("hide", () => {
                    this.sysdock.selectedApp = null;
                    if (this.dialog) {
                        return this.dialog.hide();
                    }
                });
                this.on("menuselect", (d) => {
                    switch (d.data.item.data.dataid) {
                        case `${this.name}-about`:
                            return this.openDialog("AboutDialog");
                        case `${this.name}-exit`:
                            return this.trigger("exit", undefined);
                    }
                });
                this.on("apptitlechange", () => this.sysdock.update(this));
                this.subscribe("appregistry", (m) => {
                    if (m.name === this.name) {
                        this.applySetting(m.message);
                    }
                });
                this.subscribe("loading", (o) => {
                    if (o.u_data != this.pid) {
                        return;
                    }
                    this._pending_task.push(o.id);
                    this.trigger("loading", undefined);
                });
                this.subscribe("loaded", (o) => {
                    const i = this._pending_task.indexOf(o.id);
                    if (i >= 0) {
                        this._pending_task.splice(i, 1);
                    }
                    if (this._pending_task.length === 0) {
                        // set time out
                        if (!this._loading_toh)
                            this._loading_toh = setTimeout(() => this.animation_check(), 1000);
                    }
                });
                this.updateLocale(this.systemsetting.system.locale);
                return this.loadScheme();
            }
            /**
             * Render the application UI by first loading its scheme
             * and then mount this scheme to the DOM tree
             *
             * @protected
             * @returns {void}
             * @memberof BaseApplication
             */
            loadScheme() {
                //now load the scheme
                const path = `${this.meta().path}/scheme.html`;
                return this.render(path);
            }
            /**
             * API function to perform an heavy task.
             * This function will trigger the global `loading`
             * event at the beginning of the task, and the `loaded`
             * event after finishing the task
             *
             * @protected
             * @param {Promise<any>} promise the promise on a task to be performed
             * @returns {Promise<void>}
             * @memberof BaseApplication
             */
            load(promise) {
                const q = this._api.mid();
                return new Promise((resolve, reject) => __awaiter(this, void 0, void 0, function* () {
                    this._api.loading(q, this.name);
                    try {
                        yield promise;
                        this._api.loaded(q, this.name, "OK");
                        return resolve();
                    }
                    catch (e) {
                        this._api.loaded(q, this.name, "FAIL");
                        return reject(__e(e));
                    }
                }));
            }
            /**
             * Bind a hotkey to the application, this function
             * is used to define application keyboard shortcut
             *
             * @protected
             * @param {string} k the hotkey to bind, should be in the following
             * format: `[ALT|SHIFT|CTRL|META]-KEY`, e.g. `CTRL-S`
             * @param {(e: JQuery.KeyboardEventBase) => void} f the callback function
             * @returns {void}
             * @memberof BaseApplication
             */
            bindKey(k, f) {
                const arr = k.toUpperCase().split("-");
                const c = arr.pop();
                let fnk = "";
                if (arr.includes("META")) {
                    fnk += "META";
                }
                if (arr.includes("CTRL")) {
                    fnk += "CTRL";
                }
                if (arr.includes("ALT")) {
                    fnk += "ALT";
                }
                if (arr.includes("SHIFT")) {
                    fnk += "SHIFT";
                }
                if (fnk == "") {
                    return;
                }
                fnk = `fn_${fnk.hash()}`;
                if (!this.keycomb[fnk]) {
                    this.keycomb[fnk] = {};
                }
                this.keycomb[fnk][c] = f;
            }
            /**
             * Update the application local from the system
             * locale or application specific locale configuration
             *
             * @param {string} name locale name e.g. `en_GB`
             * @returns {void}
             * @memberof BaseApplication
             */
            updateLocale(name) {
                const meta = this.meta();
                if (!meta || !meta.locales) {
                    return;
                }
                if (!meta.locales[name]) {
                    return;
                }
                const result = [];
                for (let k in meta.locales[name]) {
                    const v = meta.locales[name][k];
                    result.push((this._api.lang[k] = v));
                }
            }
            /**
             * Execute the callback subscribed to a
             * keyboard shortcut
             *
             * @param {string} fnk meta or modifier key e.g. `CTRL`, `ALT`, `SHIFT` or `META`
             * @param {string} c a regular key
             * @param {JQuery.KeyDownEvent} e JQuery keyboard event
             * @returns {boolean} return whether the shortcut is executed
             * @memberof BaseApplication
             */
            shortcut(fnk, c, e) {
                if (!this.keycomb[fnk]) {
                    return true;
                }
                if (!this.keycomb[fnk][c]) {
                    return true;
                }
                this.keycomb[fnk][c](e);
                return false;
            }
            /**
             * Apply a setting to the application
             *
             * @protected
             * @param {string} k the setting name
             * @memberof BaseApplication
             */
            applySetting(k) { }
            /**
             * Apply all settings to the application
             *
             * @protected
             * @memberof BaseApplication
             */
            applyAllSetting() {
                for (let k in this.setting) {
                    const v = this.setting[k];
                    this.applySetting(k);
                }
            }
            /**
             * Set a setting value to the application setting
             * registry
             *
             * @protected
             * @param {string} k setting name
             * @param {*} v setting value
             * @returns {void}
             * @memberof BaseApplication
             */
            registry(k, v) {
                this.setting[k] = v;
                return this.publish("appregistry", k);
            }
            /**
             * Show the appliation
             *
             * @returns {void}
             * @memberof BaseApplication
             */
            show() {
                this.trigger("focus", undefined);
            }
            /**
             * Blur the application
             *
             * @returns {void}
             * @memberof BaseApplication
             */
            blur() {
                this.trigger("blur", undefined);
                if (this.dialog) {
                    this.dialog.blur();
                }
            }
            /**
             * Hide the application
             *
             * @returns {void}
             * @memberof BaseApplication
             */
            hide() {
                return this.trigger("hide", undefined);
            }
            /**
             * Maximize or restore the application window size
             * and its position
             *
             * @returns {void}
             * @memberof BaseApplication
             */
            toggle() {
                return this.trigger("toggle", undefined);
            }
            /**
             * Get the application title
             *
             * @returns {(string| FormattedString)}
             * @memberof BaseApplication
             */
            title() {
                return this.scheme.apptitle;
            }
            /**
             * Function called when the application exit.
             * If the input exit event is prevented, the application
             * process will not be killed
             *
             *
             * @protected
             * @param {BaseEvent} evt exit event
             * @memberof BaseApplication
             */
            onexit(evt) {
                this.cleanup(evt);
                if (!evt.prevent) {
                    $(this.scheme).remove();
                }
            }
            /**
             * Get the application meta-data
             *
             * @returns {API.PackageMetaType}
             * @memberof BaseApplication
             */
            meta() {
                return application[this.name].meta;
            }
            /**
             * Base menu definition. This function
             * returns the based menu definition of all applications.
             * Other application specific menu entries
             * should be defined in [[menu]] function
             *
             * @protected
             * @returns {GUI.BasicItemType[]}
             * @memberof BaseApplication
             */
            baseMenu() {
                let mn = [
                    {
                        text: application[this.name].meta.name,
                        nodes: [
                            { text: "__(About)", dataid: `${this.name}-about` },
                            { text: "__(Exit)", dataid: `${this.name}-exit` },
                        ],
                    },
                ];
                mn = mn.concat(this.menu() || []);
                return mn;
            }
            /**
             * Application specific menu definition
             *
             * @protected
             * @returns {GUI.BasicItemType[]}
             * @memberof BaseApplication
             */
            menu() {
                // implement by subclasses
                // to add menu to application
                return [];
            }
            /**
             * The cleanup function that is called by [[onexit]] function.
             * Application need to override this function to perform some
             * specific task before exiting or to prevent the application
             * to be exited
             *
             * @protected
             * @param {BaseEvent} e
             * @memberof BaseApplication
             */
            cleanup(e) { }
            /**
             * Check if the loading tasks ended,
             * if it the case, stop the animation
             *
             * @private
             * @memberof BaseApplication
             */
            animation_check() {
                if (this._pending_task.length === 0) {
                    this.trigger("loaded", undefined);
                }
                if (this._loading_toh)
                    clearTimeout(this._loading_toh);
                this._loading_toh = undefined;
            }
        }
        application.BaseApplication = BaseApplication;
        BaseApplication.type = OS.ModelType.Application;
    })(application = OS.application || (OS.application = {}));
})(OS || (OS = {}));

// Copyright 2017-2018 Xuan Sang LE <xsang.le AT gmail DOT com>
// AnTOS Web desktop is is licensed under the GNU General Public
// License v3.0, see the LICENCE file for more information
// This program is free software: you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation, either version 3 of
// the License, or (at your option) any later version.
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// General Public License for more details.
// You should have received a copy of the GNU General Public License
//along with this program. If not, see https://www.gnu.org/licenses/.
var OS;
(function (OS) {
    let application;
    (function (application) {
        /**
         * Services are processes that run in the background and
         * are waken up in certain circumstances such as by global
         * events or user interactions.
         *
         * Each service takes an entry in the system tray menu
         * located on the system panel. This menu entry is used
         * to access to service visual contents such as: options,
         * task performing based on user interaction, etc.
         *
         * Services are singleton processes, there is only
         * one process of a service at a time
         *
         * @export
         * @abstract
         * @class BaseService
         * @extends {BaseModel}
         */
        class BaseService extends OS.BaseModel {
            /**
             *Creates an instance of BaseService.
             * @param {string} name service class name
             * @param {AppArgumentsType[]} args service arguments
             * @memberof BaseService
             */
            constructor(name, args) {
                super(name, args);
                this.icon = undefined;
                this.iconclass = "fa fa-paper-plane-o";
                this.text = "";
                this.timer = undefined;
                this.onmenuselect = (d) => {
                    return this.awake(d);
                };
            }
            /**
             * Do nothing
             *
             * @memberof BaseService
             */
            hide() { }
            /**
             * Refresh the service menu entry in the
             * system tray
             *
             * @memberof BaseService
             */
            update() {
                if (!this.domel)
                    return;
                this.domel.data = this;
            }
            /**
             * Get the service meta-data
             *
             * @returns {API.PackageMetaType}
             * @memberof BaseService
             */
            meta() {
                return application[this.name].meta;
            }
            /**
             * Set the callback that will be called periodically
             * after a period of time.
             *
             * Each service should only have at most one watcher
             *
             * @protected
             * @param {number} t period time in seconds
             * @param {() => void} f callback function
             * @returns {number}
             * @memberof BaseService
             */
            watch(t, f) {
                var func = () => {
                    f();
                    if (this.timer) {
                        clearTimeout(this.timer);
                    }
                    return (this.timer = window.setTimeout(() => func(), t));
                };
                return func();
            }
            /**
             * This function is called when the service
             * is exited
             *
             * @protected
             * @param {BaseEvent} evt exit event
             * @returns
             * @memberof BaseService
             */
            onexit(evt) {
                if (this.timer) {
                    console.log("clean timer");
                }
                if (this.timer) {
                    clearTimeout(this.timer);
                }
                this.cleanup(evt);
                if (this.scheme) {
                    return $(this.scheme).remove();
                }
            }
            /**
             * Do nothing
             *
             * @memberof BaseService
             */
            main() { }
            /**
             * Do nothing
             *
             * @memberof BaseService
             */
            show() { }
            /**
             * Do nothing
             *
             * @protected
             * @param {BaseEvent} evt
             * @memberof BaseService
             */
            cleanup(evt) { }
        }
        application.BaseService = BaseService;
        BaseService.type = OS.ModelType.Service;
        BaseService.singleton = true;
    })(application = OS.application || (OS.application = {}));
})(OS || (OS = {}));

// Copyright 2017-2018 Xuan Sang LE <xsang.le AT gmail DOT com>
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
// AnTOS Web desktop is is licensed under the GNU General Public
// License v3.0, see the LICENCE file for more information
// This program is free software: you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation, either version 3 of
// the License, or (at your option) any later version.
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// General Public License for more details.
// You should have received a copy of the GNU General Public License
//along with this program. If not, see https://www.gnu.org/licenses/.
var OS;
(function (OS) {
    let GUI;
    (function (GUI) {
        /**
         * the SubWindow class is the abstract prototype of all
         * modal windows or dialogs definition in AntOS
         *
         * @export
         * @abstract
         * @class SubWindow
         * @extends {BaseModel}
         */
        class SubWindow extends OS.BaseModel {
            /**
             *Creates an instance of SubWindow.
             * @param {string} name SubWindow (class) name
             * @memberof SubWindow
             */
            constructor(name) {
                super(name, null);
                this.parent = undefined;
                this.modal = false;
            }
            /**
             * Purge the model from the system
             *
             * @protected
             * @memberof BaseModel
             */
            destroy() {
                if (this.scheme) {
                    $(this.scheme).remove();
                }
            }
            /**
             * Init the sub-window, this function is called
             * on creation of the sub-window object. It is used
             * to render the sub-window UI.
             *
             * Need to be implemented by subclasses
             *
             *
             * @returns {void}
             * @memberof BaseDialog
             */
            init() {
                // show the app if it is not active
                this.on("focus", () => {
                    if ((this.pid == -1) || (OS.PM.pidactive == this.pid)) {
                        return;
                    }
                    const app = OS.PM.appByPid(this.pid);
                    if (app) {
                        app.show();
                    }
                });
            }
            /**
             * Return the parent meta-data of the current
             * sub-window
             *
             * @returns {API.PackageMetaType}
             * @memberof SubWindow
             */
            meta() {
                const p = this.parent;
                if (p && p.meta) {
                    return p.meta();
                }
            }
            /**
             * Show the sub-window
             *
             * @memberof SubWindow
             */
            show() {
                this.trigger("focus", undefined);
                this.trigger("focused", undefined);
                if (this.dialog) {
                    this.dialog.show();
                }
            }
            /**
             * Hide the sub-window
             *
             * @returns {void}
             * @memberof SubWindow
             */
            hide() {
                this.trigger("hide", undefined);
                if (this.dialog) {
                    this.dialog.hide();
                }
            }
            /**
             * blur the sub-window
             *
             * @returns {void}
             * @memberof SubWindow
             */
            blur() {
                this.trigger("blur", undefined);
                if (this.dialog) {
                    this.dialog.blur();
                }
            }
        }
        GUI.SubWindow = SubWindow;
        SubWindow.type = OS.ModelType.SubWindow;
        /**
         * Abstract prototype of all AntOS dialogs widget
         *
         * @export
         * @abstract
         * @class BaseDialog
         * @extends {SubWindow}
         */
        class BaseDialog extends SubWindow {
            /**
             *Creates an instance of BaseDialog.
             * @param {string} name Dialog (class) name
             * @memberof BaseDialog
             */
            constructor(name) {
                super(name);
                this.handle = undefined;
            }
            /**
             * Function called when dialog exits
             *
             * @protected
             * @param {BaseEvent} _e
             * @returns {void}
             * @memberof BaseDialog
             */
            onexit(_e) {
                if (this.parent) {
                    return (this.parent.dialog = undefined);
                }
            }
            /**
            * Show the dialog
            *
            * @memberof BaseDialog
            */
            show() {
                this.trigger("focus", undefined);
                this.trigger("focused", undefined);
                if (this.dialog) {
                    this.dialog.show();
                }
            }
        }
        GUI.BaseDialog = BaseDialog;
        /**
         * A basic dialog renders a dialog widget using the UI
         * scheme provided in it constructor or defined in its
         * class variable `scheme`
         *
         * @export
         * @class BasicDialog
         * @extends {BaseDialog}
         */
        class BasicDialog extends BaseDialog {
            /**
             *Creates an instance of BasicDialog.
             * @param {string} name dialog name
             * @param {(string | OS.API.VFS.BaseFileHandle)} [markup] UI scheme definition
             * @memberof BasicDialog
             */
            constructor(name, markup) {
                super(name);
                this.markup = markup;
            }
            /**
             * Render the dialog using the UI scheme provided by either
             * the `markup` instance variable or the `scheme` class variable
             *
             * @returns {void}
             * @memberof BasicDialog
             */
            init() {
                super.init();
                //this._onenter = undefined;
                if (this.markup) {
                    if (typeof this.markup === "string") {
                        return GUI.htmlToScheme(this.markup, this, this.host);
                    }
                    else {
                        // a file handle
                        return this.render(this.markup.path);
                    }
                }
                else if (GUI.dialogs[this.name] &&
                    GUI.dialogs[this.name].scheme) {
                    const html = GUI.dialogs[this.name].scheme;
                    return GUI.htmlToScheme(html.trim(), this, this.host);
                }
                else {
                    this.error(__("Unable to find dialog scheme"));
                }
            }
            /**
             * Main entry point for the dialog
             *
             * @memberof BasicDialog
             */
            main() {
                const win = this.scheme;
                $(win).on('keydown', (e) => {
                    switch (e.which) {
                        case 27:
                            return this.quit();
                        case 13:
                            const btn = $("afx-button", win).filter(function () {
                                const did = $(this).attr('data-id').toLowerCase();
                                return did === "btnok" || did === "btnyes";
                            });
                            return $("button", btn).trigger("click");
                        default:
                            return;
                    }
                });
                if (this.data && this.data.title) {
                    win.apptitle = this.data.title;
                }
                win.resizable = false;
                win.minimizable = false;
                win.menu = undefined;
                $(win).trigger("focus");
            }
        }
        GUI.BasicDialog = BasicDialog;
        /**
         * The namespace `dialogs` is dedicated to all Dialog definition
         * in AntOS
         */
        let dialogs;
        (function (dialogs) {
            /**
             * Simple prompt dialog to get user input text.
             * The input data of the dialog:
             *
             * ```typescript
             * {
             *      title: string, // window title
             *      label: string, // label text
             *      value: string,   // user input text
             *      type: string // input type: text or password
             * }
             * ```
             *
             * The data passing from the dialog to the callback function is
             * in the string text of the user input value
             *
             * @export
             * @class PromptDialog
             * @extends {BasicDialog}
             */
            class PromptDialog extends BasicDialog {
                /**
                 *Creates an instance of PromptDialog.
                 * @memberof PromptDialog
                 */
                constructor() {
                    super("PromptDialog");
                }
                /**
                 * Main entry point
                 *
                 * @memberof PromptDialog
                 */
                main() {
                    super.main();
                    const input = this.find("txtInput");
                    if (this.data) {
                        input.set(this.data);
                    }
                    this.find("btnOk").onbtclick = (_e) => {
                        if (this.handle) {
                            this.handle(input.value);
                        }
                        return this.quit();
                    };
                    this.find("btnCancel").onbtclick = (_e) => {
                        return this.quit();
                    };
                    input.on("keyup", (e) => {
                        if (e.which !== 13) {
                            return;
                        }
                        if (this.handle) {
                            this.handle(input.value);
                        }
                        return this.quit();
                    });
                    input.trigger("focus");
                }
            }
            dialogs.PromptDialog = PromptDialog;
            /**
             * Scheme definition of the Prompt dialog
             */
            PromptDialog.scheme = `\
<afx-app-window  width='250' height='200' apptitle = "Prompt">
    <afx-vbox padding = "10">
        <afx-input data-id= "txtInput"></afx-input>
        <div data-height="35" style="text-align: right;">
            <afx-button data-id = "btnOk" text = "__(Ok)"></afx-button>
            <afx-button data-id = "btnCancel" text = "__(Cancel)"></afx-button>
        </div>
    </afx-vbox>
</afx-app-window>\
            `;
            /**
             * A text dialog is similar to a [[PromptDialog]] nut allows
             * user to input multi-line text.
             *
             * Refer to [[PromptDialog]] for the definition of input and callback data
             * of the dialog
             *
             * @export
             * @class TextDialog
             * @extends {BasicDialog}
             */
            class TextDialog extends BasicDialog {
                /**
                 *Creates an instance of TextDialog.
                 * @memberof TextDialog
                 */
                constructor() {
                    super("TextDialog");
                }
                /**
                 * Main entry point
                 *
                 * @memberof TextDialog
                 */
                main() {
                    super.main();
                    const input = this.find("txtInput");
                    if (this.data)
                        input.set(this.data);
                    this.find("btn-Ok").onbtclick = (_e) => {
                        const value = input.value;
                        if (!value || value === "") {
                            return;
                        }
                        if (this.handle) {
                            this.handle(value);
                        }
                        return this.quit();
                    };
                    this.find("btnCancel").onbtclick = (_e) => {
                        return this.quit();
                    };
                    input.trigger("focus");
                }
            }
            dialogs.TextDialog = TextDialog;
            /**
             * Scheme definition
             */
            TextDialog.scheme = `\
<afx-app-window data-id = "TextDialog" width='400' height='300'>
    <afx-vbox padding="10">
        <afx-input data-id= "txtInput" verbose="true"></afx-input>
        <div data-height="40" style="text-align:right;padding-top:5px;">
            <afx-button data-id = "btn-Ok" text = "__(Ok)" ></afx-button>
            <afx-button data-id = "btnCancel" text = "__(Cancel)" ></afx-button>
        </div>
    </afx-vbox>
</afx-app-window>\
            `;
            /**
             * A Calendar dialog allows user to select a date
             *
             * Input data:
             *
             * ```typescript
             * {
             *      title: string // window title
             * }
             * ```
             *
             * @export
             * @class CalendarDialog
             * @extends {BasicDialog}
             */
            class CalendarDialog extends BasicDialog {
                /**
                 * Creates an instance of CalendarDialog.
                 *
                 * Callback data: a Date object represent the selected date
                 *
                 *
                 * @memberof CalendarDialog
                 */
                constructor() {
                    super("CalendarDialog");
                }
                /**
                 *
                 *
                 * @memberof CalendarDialog
                 */
                main() {
                    super.main();
                    this.find("btnOk").onbtclick = (_e) => {
                        const date = this.find("cal")
                            .selectedDate;
                        if (!date) {
                            return this.notify(__("Please select a day"));
                        }
                        if (this.handle) {
                            this.handle(date);
                        }
                        return this.quit();
                    };
                    this.find("btnCancel").onbtclick = (_e) => {
                        return this.quit();
                    };
                }
            }
            dialogs.CalendarDialog = CalendarDialog;
            /**
             * Scheme definition
             */
            CalendarDialog.scheme = `\
<afx-app-window  width='350' height='380' apptitle = "Calendar" >
    <afx-vbox padding="10">
        <afx-calendar-view data-id = "cal" ></afx-calendar-view>
        <div data-height="35" style = 'text-align: right;'>
            <afx-button data-id = "btnOk" text = "__(Ok)" data-width = "40" ></afx-button>
            <afx-button data-id = "btnCancel" text = "__(Cancel)" data-width = "50" ></afx-button>
        </div>
    </afx-vbox>
</afx-app-window>\
            `;
            /**
             * Color picker dialog
             *
             * Input data:
             *
             * ```typescript
             * {
             *      title: string // window title
             * }
             * ```
             * Callback data: [[ColorType]] object
             *
             * @export
             * @class ColorPickerDialog
             * @extends {BasicDialog}
             */
            class ColorPickerDialog extends BasicDialog {
                /**
                 *Creates an instance of ColorPickerDialog.
                 * @memberof ColorPickerDialog
                 */
                constructor() {
                    super("ColorPickerDialog");
                }
                /**
                 *
                 *
                 * @memberof ColorPickerDialog
                 */
                main() {
                    super.main();
                    this.find("btnOk").onbtclick = (_e) => {
                        const color = this.find("cpicker").selectedColor;
                        if (!color) {
                            return this.notify(__("Please select color"));
                        }
                        if (this.handle) {
                            this.handle(color);
                        }
                        return this.quit();
                    };
                    this.find("btnCancel").onbtclick = (_e) => {
                        return this.quit();
                    };
                }
            }
            dialogs.ColorPickerDialog = ColorPickerDialog;
            /**
             * Scheme definition
             */
            ColorPickerDialog.scheme = `\
<afx-app-window  width='320' height='300' apptitle = "Color picker" >
    <afx-vbox padding = "10">
        <afx-color-picker data-id = "cpicker" ></afx-color-picker>
        <div data-height="35" style = "text-align: right;">
            <afx-button data-id = "btnOk" text = "__(Ok)"  ></afx-button>
            <afx-button data-id = "btnCancel" text = "__(Cancel)" ></afx-button>
        </div>
    </afx-vbox>
</afx-app-window>\
            `;
            /**
             * Show key-value pair of the input object
             *
             * Input data:
             *
             * ```typescript
             * {
             *      title: string, // window title
             *      [propName:string]: any
             * }
             * ```
             *
             * No data for callback
             *
             * @export
             * @class InfoDialog
             * @extends {BasicDialog}
             */
            class InfoDialog extends BasicDialog {
                /**
                 *Creates an instance of InfoDialog.
                 * @memberof InfoDialog
                 */
                constructor() {
                    super("InfoDialog");
                }
                /**
                 *
                 *
                 * @memberof InfoDialog
                 */
                main() {
                    super.main();
                    const rows = [];
                    if (this.data && this.data.title) {
                        delete this.data.title;
                    }
                    for (let k in this.data) {
                        const v = this.data[k];
                        rows.push([{ text: k }, { text: v, selectable: true }]);
                    }
                    const grid = this.find("grid");
                    grid.header = [
                        { text: __("Name"), width: 70 },
                        { text: __("Value") },
                    ];
                    grid.rows = rows;
                    this.find("btnCancel").onbtclick = (_e) => {
                        return this.quit();
                    };
                }
            }
            dialogs.InfoDialog = InfoDialog;
            /**
             * Scheme definition
             */
            InfoDialog.scheme = `\
<afx-app-window  width='300' height='350' apptitle = "Info" >
    <afx-vbox padding = "10">
        <afx-grid-view data-id = "grid" ></afx-grid-view>
        <div data-height="35" style="text-align: right;">
            <afx-button data-id = "btnCancel" text = "__(Cancel)"></afx-button>
        </div>
    </afx-vbox>
</afx-app-window>\
            `;
            /**
             * A simple confirm dialog
             *
             * Input data:
             *
             * ```typescript
             * {
             *      title: string, // window title
             *      icon?: string, // label icon
             *      iconclass?: string, // label iconclass
             *      text: string // label text
             * }
             * ```
             *
             * Callback data: `boolean`
             *
             * @export
             * @class YesNoDialog
             * @extends {BasicDialog}
             */
            class YesNoDialog extends BasicDialog {
                /**
                 *Creates an instance of YesNoDialog.
                 * @memberof YesNoDialog
                 */
                constructor() {
                    super("YesNoDialog");
                }
                /**
                 * Main entry point
                 *
                 * @memberof YesNoDialog
                 */
                main() {
                    super.main();
                    if (this.data) {
                        this.find("lbl").set(this.data);
                    }
                    this.find("btnYes").onbtclick = (_e) => {
                        if (this.handle) {
                            this.handle(true);
                        }
                        return this.quit();
                    };
                    this.find("btnNo").onbtclick = (_e) => {
                        if (this.handle) {
                            this.handle(false);
                        }
                        return this.quit();
                    };
                }
            }
            dialogs.YesNoDialog = YesNoDialog;
            /**
             * Scheme definition
             */
            YesNoDialog.scheme = `\
<afx-app-window  width='250' height='200' apptitle = "Warning">
    <afx-vbox padding = "10">
        <afx-label data-id = "lbl" valign="top" ></afx-label>
        <div data-height="35" style = "text-align: right;">
            <afx-button data-id = "btnYes" text = "__(Yes)" ></afx-button>
            <afx-button data-id = "btnNo" text = "__(No)"></afx-button>
        </div>
    </afx-vbox>
</afx-app-window>\
            `;
            /**
             * A selection dialog provide user with a list of options to
             * select.
             *
             * Input data:
             *
             * ```typescript
             * {
             *      title: string, // window title
             *      data:
             *      {
             *          text: string,
             *          [propName:string]: any
             *      } [] // list data
             * ```
             *
             * Callback data: the selected data in the input list
             *
             * @export
             * @class SelectionDialog
             * @extends {BasicDialog}
             */
            class SelectionDialog extends BasicDialog {
                /**
                 *Creates an instance of SelectionDialog.
                 * @memberof SelectionDialog
                 */
                constructor() {
                    super("SelectionDialog");
                }
                /**
                 * Main entry
                 *
                 * @memberof SelectionDialog
                 */
                main() {
                    super.main();
                    const listview = this.find("list");
                    if (this.data && this.data.data) {
                        listview.data = this.data.data;
                    }
                    const fn = (_e) => {
                        const data = listview.selectedItem;
                        if (!data) {
                            return this.notify(__("Please select an item"));
                        }
                        if (this.handle) {
                            this.handle(data.data);
                        }
                        return this.quit();
                    };
                    listview.onlistdbclick = fn;
                    this.find("btnOk").onbtclick = fn;
                    this.find("btnCancel").onbtclick = (_e) => {
                        return this.quit();
                    };
                }
            }
            dialogs.SelectionDialog = SelectionDialog;
            /**
             * Scheme definition
             */
            SelectionDialog.scheme = `\
<afx-app-window  width='350' height='300' apptitle = "Selection">
    <afx-vbox padding = "10">
        <afx-list-view data-id = "list" ></afx-list-view>
        <div data-height="35" style = "text-align: right;">
            <afx-button data-id = "btnOk" text = "__(Ok)" ></afx-button>
            <afx-button data-id = "btnCancel" text = "__(Cancel)"></afx-button>
        </div>
    </afx-vbox>
</afx-app-window>\
            `;
            /**
             * An About dialog is dedicated to show the parent
             * application meta-data
             *
             * Input data: no
             *
             * Callback data: no
             *
             * @export
             * @class AboutDialog
             * @extends {BasicDialog}
             */
            class AboutDialog extends BasicDialog {
                /**
                 *Creates an instance of AboutDialog.
                 * @memberof AboutDialog
                 */
                constructor() {
                    super("AboutDialog");
                }
                /**
                 * Main entry point
                 *
                 * @returns {void}
                 * @memberof AboutDialog
                 */
                main() {
                    super.main();
                    const mt = this.meta();
                    this.scheme.apptitle = __("About: {0}", mt.name);
                    this.find("mylabel").set({
                        icon: mt.icon,
                        iconclass: mt.iconclass,
                        text: `${mt.name}(v${mt.version})`,
                    });
                    $(this.find("mydesc")).html(`${mt.description} <br/> ${mt.info.author} (${mt.info.email})`);
                    // grid data for author info
                    if (!mt.info) {
                        return;
                    }
                    `pkg://${mt.pkgname ? mt.pkgname : mt.app}/README.md`
                        .asFileHandle()
                        .read()
                        .then((data) => __awaiter(this, void 0, void 0, function* () {
                        let _ = yield OS.API.requires("os://scripts/showdown.min.js");
                        const converter = new showdown.Converter();
                        const html = converter.makeHtml(data);
                        const el = this.find("read-me");
                        $(el).html(html);
                        $("img", el).css("width", "100%");
                    }))
                        .catch(e => { });
                    this.find("btnCancel").onbtclick = (_e) => {
                        return this.quit();
                    };
                }
            }
            dialogs.AboutDialog = AboutDialog;
            /**
             * Scheme definition
             */
            AboutDialog.scheme = `\
<afx-app-window data-id = 'about-window'  width='550' height='450'>
    <afx-vbox padding = "5">
        <div style="text-align:center; margin-top:10px;" data-height="50">
            <h3 style = "margin:0;padding:0;">
                <afx-label data-id = 'mylabel' style="display: inline-block;"></afx-label>
            </h3>
            <i><p style = "margin:0; padding:0" data-id = 'mydesc'></p></i>
        </div>
        <div data-id="read-me" style="overflow-x: hidden; overflow-y: auto;"></div>
        <div data-height="10"></div>
        <div data-height="35" style = "text-align: right;">
            <afx-button data-id = "btnCancel" text = "__(Cancel)" ></afx-button>
        </div>
    </afx-vbox>
</afx-app-window>\
            `;
            /**
             * File dialog allows user to select a file/folder
             *
             * Input data:
             *
             * ```typescript
             * {
             *      title: string, // window title
             *      root?: string, // the root path folder of the file view
             *      type?: "file"|"dir"|"app", // file type to be selected
             *      mimes?: string[], // mime types of file to be selected
             *      hidden?: boolean, // show/hide hidden file
             *      file?: string // file name
             *
             * }
             * ```
             *
             * Callback data:
             *
             * ```typescript
             * {
             *      file: string, // selected file path
             *      name: string // user input file name
             * }
             * ```
             *
             * @export
             * @class FileDialog
             * @extends {BasicDialog}
             */
            class FileDialog extends BasicDialog {
                /**
                 *Creates an instance of FileDialog.
                 * @memberof FileDialog
                 */
                constructor() {
                    super("FileDialog");
                }
                /**
                 *
                 *
                 * @returns {void}
                 * @memberof FileDialog
                 */
                main() {
                    super.main();
                    const fileview = this.find("fileview");
                    const location = this.find("location");
                    const filename = this.find("filename");
                    fileview.fetch = (path) => new Promise(function (resolve, reject) {
                        if (!path) {
                            return resolve(undefined);
                        }
                        let dir = path.asFileHandle();
                        return dir
                            .read()
                            .then(function (d) {
                            if (d.error) {
                                return reject(d);
                            }
                            FileDialog.last_opened = path;
                            return resolve(d.result);
                        })
                            .catch((e) => reject(__e(e)));
                    });
                    const setroot = (path) => __awaiter(this, void 0, void 0, function* () {
                        const d = yield path.asFileHandle().read();
                        if (d.error) {
                            return this.error(__("Resource not found: {0}", path));
                        }
                        fileview.path = path;
                    });
                    if (!this.data || !this.data.root) {
                        location.onlistselect = function (e) {
                            if (!e || !e.data.item) {
                                return;
                            }
                            setroot(e.data.item.data.path);
                        };
                        location.data = this.systemsetting.VFS.mountpoints.filter((i) => i.type !== "app").map((i) => {
                            if (FileDialog.last_opened)
                                i.selected = false;
                            return i;
                        });
                        if (location.selectedItem === undefined && !FileDialog.last_opened) {
                            location.selected = 0;
                        }
                        else if (FileDialog.last_opened) {
                            setroot(FileDialog.last_opened);
                        }
                    }
                    else {
                        $(location).hide();
                        this.trigger("resize");
                        setroot(this.data.root);
                    }
                    fileview.onfileselect = function (e) {
                        if (e.data.type === "file") {
                            return filename.value = e.data.filename;
                        }
                    };
                    this.find("btnOk").onbtclick = (_e) => {
                        let f = fileview.selectedFile;
                        if (!f) {
                            const sel = location.selectedItem;
                            if (!sel)
                                return this.notify(__("Please select a file/fofler"));
                            f = sel.data;
                        }
                        if (this.data &&
                            this.data.type &&
                            this.data.type !== f.type) {
                            return this.notify(__("Please select {0} only", this.data.type));
                        }
                        if (this.data && this.data.mimes) {
                            //verify the mime
                            let m = false;
                            if (f.mime) {
                                for (let v of this.data.mimes) {
                                    if (f.mime.match(new RegExp(v, "g"))) {
                                        m = true;
                                        break;
                                    }
                                }
                            }
                            if (!m) {
                                return this.notify(__("Only {0} could be selected", this.data.mimes.join(",")));
                            }
                        }
                        const name = filename.value;
                        if (this.handle) {
                            this.handle({ file: f, name });
                        }
                        return this.quit();
                    };
                    this.find("bt-cancel").onbtclick = (_e) => {
                        return this.quit();
                    };
                    if (this.data && this.data.file) {
                        $(filename).show();
                        filename.value = (this.data.file.basename || "Untitled");
                        this.trigger("resize");
                    }
                    else {
                        $(filename).hide();
                        this.trigger("resize");
                    }
                    if (this.data && this.data.hidden) {
                        return (fileview.showhidden = this.data.hidden);
                    }
                    $(this.scheme).on("keyup", (evt) => {
                        if (evt.which === 38) {
                            const currdir = fileview.path.asFileHandle();
                            if (currdir.isRoot()) {
                                return;
                            }
                            const p = currdir.parent();
                            return fileview.path = p.path;
                        }
                    });
                }
            }
            dialogs.FileDialog = FileDialog;
            FileDialog.last_opened = undefined;
            /**
             * Scheme definition
             */
            FileDialog.scheme = `\
<afx-app-window width='400' height='450'>
    <afx-vbox>
        <afx-list-view data-id = "location" dropdown = "true" data-height = "35"></afx-list-view>
        <afx-file-view data-id = "fileview" view="tree" status = "false"></afx-file-view>
        <afx-input data-height = '52' label = "__(Target file/folder)" type = "text" data-id = "filename" ></afx-input> 
        <div style=' text-align:right;' data-height="35">
            <afx-button data-id = "btnOk" text = "__(Ok)"></afx-button>
            <afx-button data-id = "bt-cancel" text = "__(Cancel)"></afx-button>
        </div>
    </afx-vbox>
</afx-app-window>\
            `;
            /**
             * Generic & dynamic key-value dialog. The content
             * of the dialog consist of an array of label and input elements
             * which are generated based on the input model
             *
             * The input data of the dialog should be:
             *
             * ```typescript
             * {
             *      title: string, // window title
             *      model: {
             *          [propName:string]: string
             *      },
             *      data: {
             *          [propName:string]: string
             *      },
             *      allow_empty: boolean
             * }
             * ```
             * Where:
             * - keys of `model` are data fields, each key correspond to an input element
             * - values of `model` are description texts of fields, each value correspond to a label text
             * - data is the input data object in the format of model (optional)
             *
             * ```
             * Example:
             * {
             *      title: "Greeting",
             *      model: {
             *          name: "Your name",
             *          email: "Your email"
             *      },
             *      allow_empty: false
             * }
             *```

             * The data passing from the dialog to the callback function is
             * the user input data corresponding to the input model
             *
             * Example of callback data for the above model:
             *
             * ```
             * {
             *      name: "John Doe",
             *      email: "jd@mail.com"
             * }
             * ```
             *
             * @export
             * @class MultiInputDialog
             * @extends {BasicDialog}
             */
            class MultiInputDialog extends BasicDialog {
                /**
                 *Creates an instance of MultiInputDialog.
                 * @memberof MultiInputDialog
                 */
                constructor() {
                    super("MultiInputDialog");
                }
                /**
                 * Generate the scheme before rendering
                 *
                 * @memberof MultiInputDialog
                 */
                init() {
                    let height = 85;
                    let html = "";
                    if (this.data && this.data.model) {
                        const model = this.data.model;
                        for (const key in model) {
                            html += `\
                            <afx-input data-height="52" text="{0}" type="text" name = {1} ></afx-input>
                            `.format(model[key], key);
                            height += 52;
                        }
                    }
                    this.markup = MultiInputDialog.scheme.format(height, html);
                    super.init();
                }
                /**
                 * Main entry point
                 *
                 * @memberof MultiInputDialog
                 */
                main() {
                    super.main();
                    this.inputs = $("input", this.scheme);
                    if (this.data && this.data.data) {
                        const that = this;
                        this.inputs.each(function (_i) {
                            const input = this;
                            input.value = that.data.data[input.name];
                        });
                    }
                    this.find("btnCancel").onbtclick = (_e) => this.quit();
                    this.find("btnOk").onbtclick = (_e) => {
                        let cdata = {};
                        for (const el of this.inputs) {
                            let input = el;
                            if (!this.data.allow_empty && input.value.trim() == "") {
                                return this.notify(__("All fields should be filled"));
                            }
                            cdata[input.name] = input.value.trim();
                        }
                        if (this.handle)
                            this.handle(cdata);
                        this.quit();
                    };
                }
            }
            dialogs.MultiInputDialog = MultiInputDialog;
            /**
             * Scheme definition
             */
            MultiInputDialog.scheme = `\
<afx-app-window width='350' height='{0}'>
    <afx-vbox padding = "5">
        {1}
        <div data-height="35" style = "text-align: right;">
            <afx-button data-id = "btnOk" text = "__(Ok)"></afx-button>
            <afx-button data-id = "btnCancel" text = "__(Cancel)"></afx-button>
        </div>
    </afx-vbox>
</afx-app-window>`;
            /**
             * Generic dynamic key-value dialog
             *
             * Allow user to input any data key-value based object:
             *
             * {
             *      [prop:string]: string;
             * }
             *
             * @export
             * @class KeyValueDialog
             * @extends {BasicDialog}
             */
            class KeyValueDialog extends BasicDialog {
                /**
                 * Creates an instance of KeyValueDialog.
                 * @memberof KeyValueDialog
                 */
                constructor() {
                    super("KeyValueDialog");
                }
                /**
                 * Main entry point
                 *
                 * @memberof KeyValueDialog
                 */
                main() {
                    super.main();
                    this.container = this.find("container");
                    this.find("btnCancel").onbtclick = (e) => this.quit();
                    this.find("btnAdd").onbtclick = (e) => this.addField("", "", true);
                    $(this.find("wrapper"));
                    $(this.container)
                        .css("overflow-y", "auto");
                    if (this.data && this.data.data) {
                        for (const key in this.data.data) {
                            const value = this.data.data[key];
                            this.addField(key, value, false);
                        }
                    }
                    else {
                        this.addField("key", "value", false);
                    }
                    this.find("btnOk").onbtclick = (e) => {
                        const inputs = $("input", this.scheme);
                        let cdata = {};
                        for (let i = 0; i < inputs.length; i += 2) {
                            const key = inputs[i].value.trim();
                            if (key === "") {
                                return this.notify(__("Key cannot be empty"));
                            }
                            if (cdata[key]) {
                                return this.notify(__("Duplicate key: {0}", key));
                            }
                            cdata[key] = inputs[i + 1].value.trim();
                        }
                        if (this.handle)
                            this.handle(cdata);
                        this.quit();
                    };
                }
                /**
                 * Add new input key-value field to the dialog
                 *
                 * @private
                 * @memberof KeyValueDialog
                 */
                addField(key, value, removable) {
                    const div = $("<div>")
                        .css("display", "flex")
                        .css("flex-direction", "row")
                        .appendTo(this.container);
                    $("<input>")
                        .attr("type", "text")
                        .css("flex", "1")
                        .val(key)
                        .appendTo(div);
                    $("<input>")
                        .attr("type", "text")
                        .css("flex", "1")
                        .val(value)
                        .appendTo(div);
                    if (removable) {
                        const btn = $("<afx-button>");
                        btn[0].uify(undefined);
                        btn[0].iconclass = "fa fa-minus";
                        btn
                            .on("click", () => {
                            div.remove();
                        })
                            .appendTo(div);
                    }
                    else {
                        $("<div>")
                            .css("width", "40px")
                            .css("height", "35px")
                            .appendTo(div);
                    }
                }
            }
            dialogs.KeyValueDialog = KeyValueDialog;
            /**
             * Scheme definition
             */
            KeyValueDialog.scheme = `\
             <afx-app-window width='400' height='350'>
                    <afx-vbox padding = "10">
                        <afx-label text="__(Enter key-value data)" data-height="30"></afx-label>
                        <div data-id="container"></div>
                        <afx-hbox data-height="35">
                            <afx-button data-id = "btnAdd" iconclass="fa fa-plus" data-width = "35" ></afx-button>
                            <div style = "text-align: right;">
                                <afx-button data-id = "btnOk" text = "__(Ok)"></afx-button>
                                <afx-button data-id = "btnCancel" text = "__(Cancel)"></afx-button>
                            </div>
                        </afx-hbox>
                    </afx-vbox>
             </afx-app-window>`;
        })(dialogs = GUI.dialogs || (GUI.dialogs = {}));
    })(GUI = OS.GUI || (OS.GUI = {}));
})(OS || (OS = {}));

var OS;
(function (OS) {
    let GUI;
    (function (GUI) {
        /**
         * Base abstract class for tag implementation, any AFX tag should be
         * subclass of this class
         *
         * @export
         * @abstract
         * @class AFXTag
         * @extends {HTMLElement}
         */
        class AFXTag extends HTMLElement {
            /**
             *Creates an instance of AFXTag.
             * @memberof AFXTag
             */
            constructor() {
                super();
                if (!this.observable) {
                    this.observable = new Ant.OS.API.Announcer();
                }
                this._mounted = false;
                this.refs = {};
            }
            /**
             * This function verifies if a property name of the input object
             * corresponds to a setter of the current tag. If this is the
             * case, it sets the value of that property to the setter
             *
             * @param {GenericObject<any>} v input object
             * @memberof AFXTag
             */
            set(v) {
                for (let k in v) {
                    let descriptor = this.descriptor_of(k);
                    if (descriptor && descriptor.set) {
                        this[k] = v[k];
                    }
                }
            }
            /**
             * Setter to set the tooltip text to the current tag.
             * The text should be in the following format:
             * ```text
             * cr|cl|ct|cb: tooltip text
             * ```
             *
             * @memberof AFXTag
             */
            set tooltip(v) {
                if (!v) {
                    return;
                }
                $(this).attr("tooltip", v);
            }
            /**
             *
             * This function looking for a property name of the tag
             * in its prototype chain. The descriptor of the property
             * will be returned if it exists
             *
             * @private
             * @param {string} k the property name to be queried
             * @returns {PropertyDescriptor} the property descriptor or undefined
             * @memberof AFXTag
             */
            descriptor_of(k) {
                let desc;
                let obj = this;
                do {
                    desc = Object.getOwnPropertyDescriptor(obj, k);
                } while (!desc && (obj = Object.getPrototypeOf(obj)));
                return desc;
            }
            /**
             * Setter: set the id of the tag in string or number
             *
             * Getter: get the id of the current tag
             *
             * @memberof AFXTag
             */
            set aid(v) {
                $(this).attr("data-id", v);
            }
            get aid() {
                return $(this).attr("data-id");
            }
            /**
             * Implementation from HTMLElement interface,
             * this function mount the current tag hierarchy
             *
             * @returns {void}
             * @memberof AFXTag
             */
            sync() {
                if (this._mounted) {
                    return;
                }
                this._mounted = true;
                this.mount();
                super.sync();
            }
            /**
             * Generate the DOM hierarchy of the current tag
             *
             * @param {API.Announcer} o observable object
             * @memberof AFXTag
             */
            afxml(o) {
                if (o)
                    this.observable = o;
                if (!this.aid)
                    this.aid = (Math.floor(Math.random() * 100000) + 1).toString();
                const children = $(this).children();
                for (let obj of this.layout()) {
                    const dom = this.mkui(obj);
                    if (dom) {
                        $(dom).appendTo(this);
                    }
                }
                if (this.refs.yield) {
                    for (let v of children) {
                        $(v).detach().appendTo(this.refs.yield);
                    }
                }
                const attrs = {};
                for (let i = 0; i < this.attributes.length; i++) {
                    const element = this.attributes[i];
                    let descriptor = this.descriptor_of(element.nodeName);
                    if (descriptor && descriptor.set) {
                        let value = "";
                        try {
                            value = JSON.parse(element.nodeValue);
                        }
                        catch (e) {
                            value = element.nodeValue;
                        }
                        attrs[element.nodeName] = value;
                    }
                }
                super.afxml(this.observable);
                this.init();
                for (let k in attrs) {
                    this[k] = attrs[k];
                }
            }
            /**
             * Update the current tag hierarchy
             *
             * @param {*} d any data object
             * @memberof AFXTag
             */
            update(d) {
                this.reload(d);
                super.update(d);
            }
            /**
             * This function is used to re-render the current
             * tag
             *
             * @protected
             * @memberof AFXTag
             */
            calibrate() { }
            /**
             * This function parses the input layout object
             * and generates all the elements defined by
             * the tag
             *
             * @private
             * @param {TagLayoutType} tag tag layout object
             * @returns {Element} the DOM element specified by the tag layout
             * @memberof AFXTag
             */
            mkui(tag) {
                if (!tag) {
                    return undefined;
                }
                const dom = $(`<${tag.el}>`);
                if (tag.class) {
                    $(dom).addClass(tag.class);
                }
                if (tag.id) {
                    $(dom).attr("data-id", tag.id);
                }
                if (tag.height) {
                    $(dom).attr("data-height", tag.height);
                }
                if (tag.width) {
                    $(dom).attr("data-width", tag.width);
                }
                if (tag.tooltip) {
                    $(dom).attr("tooltip", tag.tooltip.__());
                }
                if (tag.children) {
                    for (let v of tag.children) {
                        $(this.mkui(v)).appendTo(dom);
                    }
                }
                if (tag.ref) {
                    this.refs[tag.ref] = dom[0];
                }
                // dom.mount @observable
                return dom[0]; //.uify(@observable)
            }
            /**
             * This function inserts or removes an attribute name
             * to/from the target element based on the input `flag`.
             *
             * @protected
             * @param {boolean} flag indicates whether the attribute name should be inserted o removed
             * @param {string} v the attribute name
             * @param {HTMLElement} [el] the target element
             * @memberof AFXTag
             */
            attsw(flag, v, el) {
                if (flag)
                    this.atton(v, el);
                else
                    this.attoff(v, el);
            }
            /**
             * Insert the attribute name to the target element
             *
             * @protected
             * @param {string} v the attribute name
             * @param {HTMLElement} [el] the target element
             * @memberof AFXTag
             */
            atton(v, el) {
                const element = el ? el : this;
                $(element).attr(v, "");
            }
            /**
             * Remove the attribute name from the target element
             *
             * @protected
             * @param {string} v attribute name
             * @param {HTMLElement} [el] the target element
             * @memberof AFXTag
             */
            attoff(v, el) {
                const element = el ? el : this;
                element.removeAttribute(v);
            }
            /**
             * Verify if the target element has an attribute name
             *
             * @protected
             * @param {string} v attribute name
             * @param {HTMLElement} [el] target element
             * @returns {boolean}
             * @memberof AFXTag
             */
            hasattr(v, el) {
                const element = el ? el : this;
                return element.hasAttribute(v);
            }
        }
        GUI.AFXTag = AFXTag;
        HTMLElement.prototype.update = function (d) {
            $(this)
                .children()
                .each(function () {
                if (this.update)
                    return this.update(d);
            });
        };
        HTMLElement.prototype.sync = function () {
            $(this)
                .children()
                .each(function () {
                return this.sync();
            });
        };
        HTMLElement.prototype.afxml = function (o) {
            $(this)
                .children()
                .each(function () {
                return this.afxml(o);
            });
        };
        HTMLElement.prototype.uify = function (o, toplevel) {
            this.afxml(o);
            this.sync();
            if (o && toplevel)
                o.trigger("mounted", this.aid);
        };
        /**
         * All the AFX tags are defined in this namespace,
         * these tags are defined as custom DOM elements and will be
         * stored in the `customElements` registry of the browser
         */
        let tag;
        (function (tag) {
            /**
             * Define an AFX tag as a custom element and add it to the
             * global `customElements` registry. If the tag is redefined, i.e.
             * the tag already exists, its behavior will be updated with the
             * new definition
             *
             * @export
             * @template T all classes that extends [[AFXTag]]
             * @param {string} name name of the tag
             * @param {{ new (): T }} cls the class that defines the tag
             * @returns {void}
             */
            function define(name, cls) {
                try {
                    customElements.define(name, cls);
                }
                catch (error) {
                    const proto = customElements.get(name);
                    if (cls) {
                        const props = Object.getOwnPropertyNames(cls.prototype);
                        // redefine the class
                        for (let prop of props) {
                            proto.prototype[prop] = cls.prototype[prop];
                        }
                        return;
                    }
                    throw error;
                }
            }
            tag.define = define;
        })(tag = GUI.tag || (GUI.tag = {}));
    })(GUI = OS.GUI || (OS.GUI = {}));
})(OS || (OS = {}));

var OS;
(function (OS) {
    let GUI;
    (function (GUI) {
        let tag;
        (function (tag) {
            /**
             * A WindowTag represents a virtual window element
             * used by AntOS applications and dialogs.
             *
             * @export
             * @class WindowTag
             * @extends {AFXTag}
             */
            class WindowTag extends GUI.AFXTag {
                /**
                 * Creates an instance of WindowTag.
                 * @memberof WindowTag
                 */
                constructor() {
                    super();
                }
                /**
                 * blur overlay: If active the window overlay will be shown
                 * on inactive (blur event)
                 *
                 * Setter: Enable the switch
                 *
                 * Getter: Check whether the switch is enabled
                 *
                 * @memberof WindowTag
                 */
                set blur_overlay(v) {
                    this.attsw(v, "blur-overlay");
                }
                get blur_overlay() {
                    return this.hasattr("blur-overlay");
                }
                /**
                 * Setter: set menu open event handler
                 *
                 * @memberof WindowTag
                 */
                set onmenuopen(f) {
                    this._onmenuopen = f;
                }
                /**
                 * Init window tag
                 * - `shown`: false
                 * - `isMaxi`: false
                 * - `minimizable`: false
                 * - `resizable`: true
                 * - `apptitle`: Untitled
                 *
                 * @protected
                 * @memberof WindowTag
                 */
                init() {
                    this._shown = false;
                    this._isMaxi = false;
                    this._history = {};
                    this.desktop = GUI.workspace;
                    this._desktop_pos = $(this.desktop).offset();
                    this.minimizable = true;
                    this.resizable = true;
                    this.apptitle = "Untitled";
                    this._onmenuopen = undefined;
                }
                /**
                 * Do nothing
                 *
                 * @protected
                 * @memberof WindowTag
                 */
                calibrate() { }
                /**
                 * Do nothing
                 *
                 * @protected
                 * @param {*} [d]
                 * @memberof WindowTag
                 */
                reload(d) { }
                /**
                 * Setter: Set the window width
                 *
                 * Getter: Get the window width
                 *
                 * @memberof WindowTag
                 */
                set width(v) {
                    this._width = v;
                    if (!v) {
                        return;
                    }
                    this.setsize({ w: v, h: this.height });
                }
                get width() {
                    return this._width;
                }
                /**
                 * Setter: Set the window height
                 *
                 * Getter: Get the window height
                 *
                 * @memberof WindowTag
                 */
                set height(v) {
                    this._height = v;
                    if (!v) {
                        return;
                    }
                    this.setsize({
                        w: this.width,
                        h: v,
                    });
                }
                get height() {
                    return this._height;
                }
                /**
                 * Set the application menu content
                 *
                 * @memberof WindowTag
                 */
                set menu(v) {
                    if (!v || v.length == 0) {
                        $(this.refs.btnMenu).hide();
                    }
                    else {
                        this.refs.stackmenu.nodes = v;
                        $(this.refs.btnMenu).show();
                    }
                }
                /**
                 * Setter: enable/disable window minimizable
                 *
                 * getter: Check whether the window is minimizable
                 *
                 * @memberof WindowTag
                 */
                set minimizable(v) {
                    this.attsw(v, "minimizable");
                    if (v) {
                        $(this.refs["minbt"]).show();
                    }
                    else {
                        $(this.refs["minbt"]).hide();
                    }
                }
                get minimizable() {
                    return this.hasattr("minimizable");
                }
                /**
                 * Setter: enable/disable widow resizable
                 *
                 * Getter: Check whether the current window is resizable
                 *
                 * @memberof WindowTag
                 */
                set resizable(v) {
                    this.attsw(v, "resizable");
                    if (v) {
                        $(this.refs["maxbt"]).show();
                        $(this.refs["grip"]).show();
                        $(this.refs["grip_bottom"]).show();
                        $(this.refs["grip_right"]).show();
                    }
                    else {
                        $(this.refs["maxbt"]).hide();
                        $(this.refs["grip"]).hide();
                        $(this.refs["grip_bottom"]).hide();
                        $(this.refs["grip_right"]).hide();
                    }
                }
                get resizable() {
                    return this.hasattr("resizable");
                }
                /**
                 * Setter: Set the window title
                 *
                 * Getter: Get window title
                 *
                 * @memberof WindowTag
                 */
                set apptitle(v) {
                    $(this).attr("apptitle", v.__());
                    if (v) {
                        this.refs["txtTitle"].text = v;
                        this.observable.trigger("apptitlechange", this);
                    }
                }
                get apptitle() {
                    return $(this).attr("apptitle");
                }
                /**
                 * Resize all the children of the window based on its width and height
                 *
                 * @private
                 * @memberof WindowTag
                 */
                resize() {
                    const ch = $(this.refs["yield"]).height() /
                        $(this.refs["yield"]).children().length;
                    $(this.refs["yield"])
                        .children()
                        .each(function (e) {
                        $(this).css("height", `${ch}px`);
                    });
                }
                /**
                 * Mount the window tag and bind basic events
                 *
                 * @protected
                 * @returns {void}
                 * @memberof WindowTag
                 */
                mount() {
                    const btn_menu = this.refs.btnMenu;
                    const min_btn = this.refs["minbt"];
                    const max_btn = this.refs["maxbt"];
                    const close_btn = this.refs["closebt"];
                    const stackmenu = this.refs.stackmenu;
                    stackmenu.context = true;
                    btn_menu.iconclass = "bi bi-list";
                    min_btn.iconclass = "bi bi-dash";
                    max_btn.iconclass = "bi bi-stop";
                    close_btn.iconclass = "bi bi-x";
                    this.contextmenuHandle = function (e) { };
                    min_btn.onbtclick = (_) => {
                        return this.observable.trigger("hide", {
                            id: this.aid,
                        });
                    };
                    btn_menu.onbtclick = (e) => {
                        e.data.stopPropagation();
                        if ($(stackmenu).is(":hidden")) {
                            if (this._onmenuopen) {
                                this._onmenuopen(stackmenu);
                            }
                            else {
                                stackmenu.reset();
                            }
                            stackmenu.show();
                        }
                        else {
                            $(stackmenu).hide();
                        }
                    };
                    max_btn.onbtclick = (_) => {
                        return this.toggle_window();
                    };
                    close_btn.onbtclick = (_) => {
                        return this.observable.trigger("exit", {
                            id: this.aid,
                        });
                    };
                    stackmenu.onmenuselect = (e) => {
                        if (!e.data.item.data.nodes) {
                            stackmenu.selected = -1;
                        }
                    };
                    const left = ($(this.desktop).width() - this.width) / 2;
                    const top = ($(this.desktop).height() - this.height) / 2;
                    $(this)
                        .css("position", "absolute")
                        .css("left", `${left}px`)
                        .css("top", `${top}px`)
                        .css("z-index", 10);
                    $(this).on("pointerdown", (e) => {
                        if (this._shown) {
                            return;
                        }
                        return this.observable.trigger("focus", {
                            id: this.aid,
                        });
                    });
                    $(this.refs["dragger"]).on("dblclick", (e) => {
                        return this.toggle_window();
                    });
                    this.observable.on("resize", (e) => this.resize());
                    this.observable.on("focus", () => {
                        $(this)
                            .show()
                            .removeClass("unactive");
                        this._shown = true;
                        $(this.refs.win_overlay).hide();
                        $(this).trigger("focus");
                    });
                    this.observable.on("blur", () => {
                        this._shown = false;
                        $(this).addClass("unactive");
                        if (this.blur_overlay)
                            $(this.refs.win_overlay).show();
                    });
                    this.observable.on("hide", () => {
                        $(this).hide();
                        return (this._shown = false);
                    });
                    this.observable.on("toggle", () => {
                        if (this._shown) {
                            return this.observable.trigger("hide", {
                                id: this.aid,
                            });
                        }
                        else {
                            return this.observable.trigger("focus", {
                                id: this.aid,
                            });
                        }
                    });
                    this.observable.on("loaded", () => {
                        $(this.refs.panel).removeClass("loading");
                        $(this).css("cursor", "auto");
                    });
                    this.observable.on("loading", () => {
                        if (!$(this.refs.panel).hasClass("loading"))
                            $(this.refs.panel).addClass("loading");
                        $(this).css("cursor", "wait");
                    });
                    this.enable_dragging();
                    this.enable_resize();
                    this.setsize({
                        w: this.width,
                        h: this.height,
                    });
                    $(this).attr("tabindex", 0).css("outline", "none");
                    if (OS.mobile) {
                        this.toggle_window();
                        //this.minimizable = false;
                        this.resizable = false;
                    }
                    this.observable.on("desktopresize", (e) => {
                        if (this._isMaxi) {
                            this._isMaxi = false;
                            this.toggle_window(true);
                        }
                        /*else
                        {
                            const w = this.width > e.data.width ? e.data.width: this.width;
                            const h = this.height > e.data.height ? e.data.height: this.height;
                            this.setsize({ w: w, h: h });
                        }*/
                    });
                    this.observable.trigger("rendered", {
                        id: this.aid,
                    });
                }
                /**
                 * Set the window size
                 *
                 * @private
                 * @param {GenericObject<any>} o format: `{ w: window_width, h: window_height }`
                 * @returns {void}
                 * @memberof WindowTag
                 */
                setsize(o) {
                    if (!o) {
                        return;
                    }
                    this._width = o.w;
                    this._height = o.h;
                    $(this).css("width", `${o.w}px`).css("height", `${o.h}px`);
                    $(this.refs.winwrapper).css("height", `${o.h}px`);
                    this.observable.trigger("resize", {
                        id: this.aid,
                        data: o,
                    });
                }
                /**
                 * Enable to drag window on the virtual desktop
                 *
                 * @private
                 * @memberof WindowTag
                 */
                enable_dragging() {
                    $(this.refs["dragger"])
                        .css("user-select", "none")
                        .css("cursor", "default");
                    $(this.refs.dragger).on("pointerdown", (e) => {
                        e.originalEvent.preventDefault();
                        const offset = $(this).offset();
                        offset.top = e.clientY - offset.top;
                        offset.left = e.clientX - offset.left;
                        $(window).on("pointermove", (e) => {
                            $(this.refs.win_overlay).show();
                            let left, top;
                            if (this._isMaxi) {
                                this.toggle_window();
                                top = 0;
                                const letf = e.clientX - $(this).width() / 2;
                                offset.top = 10;
                                offset.left = $(this).width() / 2;
                            }
                            else {
                                top =
                                    e.clientY -
                                        offset.top -
                                        this._desktop_pos.top;
                                left =
                                    e.clientX -
                                        this._desktop_pos.top -
                                        offset.left;
                                left = left < 0 ? 0 : left;
                                top = top < 0 ? 0 : top;
                            }
                            return $(this)
                                .css("top", `${top}px`)
                                .css("left", `${left}px`);
                        });
                        return $(window).on("pointerup", (e) => {
                            $(this.refs.win_overlay).hide();
                            $(window).off("pointermove", null);
                            return $(window).off("pointerup", null);
                        });
                    });
                }
                /**
                 * Enable window resize, this only works if the window
                 * is resizable
                 *
                 * @private
                 * @memberof WindowTag
                 */
                enable_resize() {
                    const offset = { top: 0, left: 0 };
                    let target = undefined;
                    const mouse_move_hdl = (e) => {
                        let w = $(this).width();
                        let h = $(this).height();
                        $(this.refs.win_overlay).show();
                        if (target != this.refs.grip_bottom) {
                            w += e.clientX - offset.left;
                        }
                        if (target != this.refs.grip_right) {
                            h += e.clientY - offset.top;
                        }
                        w = w < 100 ? 100 : w;
                        h = h < 100 ? 100 : h;
                        offset.top = e.clientY;
                        offset.left = e.clientX;
                        this._isMaxi = false;
                        this.setsize({ w, h });
                    };
                    const mouse_up_hdl = (e) => {
                        $(this.refs.win_overlay).hide();
                        $(window).off("pointermove", mouse_move_hdl);
                        return $(window).off("pointerup", mouse_up_hdl);
                    };
                    $(this.refs["grip"]).on("pointerdown", (e) => {
                        e.preventDefault();
                        offset.top = e.clientY;
                        offset.left = e.clientX;
                        target = this.refs.grip;
                        $(window).on("pointermove", mouse_move_hdl);
                        $(window).on("pointerup", mouse_up_hdl);
                    });
                    $(this.refs.grip_bottom).on("pointerdown", (e) => {
                        e.preventDefault();
                        offset.top = e.clientY;
                        offset.left = e.clientX;
                        target = this.refs.grip_bottom;
                        $(window).on("pointermove", mouse_move_hdl);
                        $(window).on("pointerup", mouse_up_hdl);
                    });
                    $(this.refs.grip_right).on("pointerdown", (e) => {
                        e.preventDefault();
                        offset.top = e.clientY;
                        offset.left = e.clientX;
                        target = this.refs.grip_right;
                        $(window).on("pointermove", mouse_move_hdl);
                        $(window).on("pointerup", mouse_up_hdl);
                    });
                }
                /**
                 * Maximize the window or restore its previous width, height,
                 * and position
                 *
                 * @private
                 * @returns {void}
                 * @memberof WindowTag
                 */
                toggle_window(force) {
                    let h, w;
                    if (!this.resizable && !force) {
                        return;
                    }
                    if (this._isMaxi === false) {
                        this._history = {
                            top: $(this).css("top"),
                            left: $(this).css("left"),
                            width: $(this).css("width"),
                            height: $(this).css("height"),
                        };
                        w = $(this.desktop).width() - 2;
                        h = $(this.desktop).height() - 2;
                        $(this).css("top", "0").css("left", "0");
                        this.setsize({ w, h });
                        this._isMaxi = true;
                    }
                    else {
                        this._isMaxi = false;
                        $(this)
                            .css("top", this._history.top)
                            .css("left", this._history.left);
                        this.setsize({
                            w: parseInt(this._history.width),
                            h: parseInt(this._history.height),
                        });
                    }
                }
                /**
                 * Layout definition of the window tag
                 *
                 * @protected
                 * @returns {TagLayoutType[]}
                 * @memberof WindowTag
                 */
                layout() {
                    return [
                        {
                            el: "div",
                            class: "afx-window-wrapper",
                            ref: "winwrapper",
                            children: [
                                {
                                    el: "ul",
                                    ref: 'panel',
                                    class: "afx-window-top",
                                    children: [
                                        {
                                            el: "li",
                                            children: [
                                                {
                                                    el: "afx-button",
                                                    ref: "btnMenu",
                                                },
                                            ],
                                        },
                                        {
                                            el: "li",
                                            class: "afx-window-title",
                                            ref: "dragger",
                                            children: [
                                                {
                                                    el: "afx-label",
                                                    ref: "txtTitle",
                                                },
                                            ],
                                        },
                                        {
                                            el: "li",
                                            class: "afx-window-minimize",
                                            children: [
                                                {
                                                    el: "afx-button",
                                                    ref: "minbt",
                                                }
                                            ]
                                        },
                                        {
                                            el: "li",
                                            class: "afx-window-maximize",
                                            children: [
                                                {
                                                    el: "afx-button",
                                                    ref: "maxbt",
                                                }
                                            ]
                                        },
                                        {
                                            el: "li",
                                            class: "afx-window-close",
                                            children: [
                                                {
                                                    el: "afx-button",
                                                    ref: "closebt",
                                                }
                                            ]
                                        },
                                    ],
                                },
                                {
                                    el: "div",
                                    ref: "yield",
                                    class: "afx-window-content",
                                },
                                {
                                    el: "div",
                                    ref: "grip",
                                    class: "afx-window-grip",
                                },
                                {
                                    el: "div",
                                    ref: "grip_bottom",
                                    class: "afx-window-grip-bottom",
                                },
                                {
                                    el: "div",
                                    ref: "grip_right",
                                    class: "afx-window-grip-right",
                                },
                                {
                                    el: "div",
                                    ref: "win_overlay",
                                    class: "afx-window-overlay",
                                },
                                {
                                    el: "afx-stack-menu",
                                    ref: "stackmenu"
                                }
                            ],
                        },
                    ];
                }
            }
            tag.WindowTag = WindowTag;
            tag.define("afx-app-window", WindowTag);
        })(tag = GUI.tag || (GUI.tag = {}));
    })(GUI = OS.GUI || (OS.GUI = {}));
})(OS || (OS = {}));

var OS;
(function (OS) {
    let GUI;
    (function (GUI) {
        let tag;
        (function (tag) {
            /**
             * A tile layout organize it child elements
             * in a fixed horizontal or vertical direction.
             *
             * The size of each child element is attributed based
             * on its configuration of automatically based on the
             * remaining space in the layout
             *
             *
             * @export
             * @class TileLayoutTag
             * @extends {AFXTag}
             */
            class TileLayoutTag extends GUI.AFXTag {
                /**
                 *C reates an instance of TileLayoutTag.
                 * @memberof TileLayoutTag
                 */
                constructor() {
                    super();
                }
                /**
                 * Do nothing
                 *
                 * @protected
                 * @memberof TileLayoutTag
                 */
                init() {
                    this.padding = 0;
                }
                /**
                 * Do nothing
                 *
                 * @protected
                 * @param {*} [d]
                 * @memberof TileLayoutTag
                 */
                reload(d) { }
                /**
                 * Setter: Set the name of the tile container, should be: `hbox` or `vbox`
                 *
                 * Getter: Get the name of the tile container
                 *
                 * @memberof TileLayoutTag
                 */
                set name(v) {
                    if (!v) {
                        return;
                    }
                    $(this).attr("name", v);
                    $(this.refs.yield)
                        .removeClass()
                        .addClass(`afx-${v}-container`);
                    this.calibrate();
                }
                get name() {
                    return $(this).attr("name");
                }
                /**
                 * Setter:
                 *
                 * SET the layout direction, should be:
                 * - `row`: horizontal direction
                 * - `column`: vertical direction
                 *
                 * Getter:
                 *
                 * Get layout direction
                 *
                 * @memberof TileLayoutTag
                 */
                set dir(v) {
                    if (!v) {
                        return;
                    }
                    $(this).attr("dir", v);
                    $(this.refs.yield).css("flex-direction", v);
                    this.calibrate();
                }
                get dir() {
                    return $(this).attr("dir");
                }
                /**
                 * Setter:
                 *
                 * SET content padding
                 *
                 * Getter:
                 *
                 * Get content padding
                 *
                 * @memberof TileLayoutTag
                 */
                set padding(v) {
                    $(this).attr("padding", v);
                    this._padding = v;
                }
                get padding() {
                    return this._padding;
                }
                /**
                 * Mount the element
                 *
                 * @protected
                 * @returns {void}
                 * @memberof TileLayoutTag
                 */
                mount() {
                    $(this).css("display", "block");
                    $(this.refs.yield)
                        .css("display", "flex");
                    this.observable.on("resize", (e) => this.calibrate());
                    return this.calibrate();
                }
                /**
                 * re-organize the layout
                 *
                 * @returns {void}
                 * @memberof TileLayoutTag
                 */
                calibrate() {
                    $(this.refs.yield)
                        .css("padding", this.padding)
                        .css("width", `${$(this).width() - this.padding * 2}px`)
                        .css("height", `${$(this).height() - this.padding * 2}px`);
                    if (this.dir === "row") {
                        return this.hcalibrate();
                    }
                    if (this.dir === "column") {
                        return this.vcalibrate();
                    }
                }
                /**
                 * Organize the layout in horizontal direction, only work when
                 * the layout direction set to horizontal
                 *
                 * @private
                 * @returns {void}
                 * @memberof TileLayoutTag
                 */
                hcalibrate() {
                    const auto_width = [];
                    let ocwidth = 0;
                    const avaiWidth = $(this).width() - this.padding * 2;
                    $(this.refs.yield)
                        .children()
                        .each(function (e) {
                        $(this).css("height", "100%");
                        let attv = $(this).attr("data-width");
                        let dw = 0;
                        if (!attv || attv == "grow") {
                            $(this).css("flex-grow", "1");
                            auto_width.push(this);
                            return;
                        }
                        if (attv == "content") {
                            ocwidth += $(this).width();
                            return;
                        }
                        if (attv[attv.length - 1] === "%") {
                            dw =
                                (parseInt(attv.slice(0, -1)) *
                                    avaiWidth) /
                                    100;
                        }
                        else {
                            dw = parseInt(attv);
                        }
                        $(this).css("width", `${dw}px`);
                        ocwidth += dw;
                    });
                    const csize = (avaiWidth - ocwidth) / auto_width.length;
                    if (csize > 0) {
                        $.each(auto_width, (i, v) => $(v).css("width", `${csize}px`));
                    }
                }
                /**
                 * Organize the layout in vertical direction, only work when
                 * the layout direction set to vertical
                 *
                 * @private
                 * @returns {void}
                 * @memberof TileLayoutTag
                 */
                vcalibrate() {
                    const auto_height = [];
                    let ocheight = 0;
                    const avaiheight = $(this).innerHeight() - this.padding * 2;
                    $(this.refs.yield)
                        .children()
                        .each(function (e) {
                        let dh = 0;
                        $(this).css("width", "100%");
                        let attv = $(this).attr("data-height");
                        if (!attv || attv == "grow") {
                            $(this).css("flex-grow", "1");
                            auto_height.push(this);
                            return;
                        }
                        if (attv == "content") {
                            ocheight += $(this).height();
                            return;
                        }
                        if (attv[attv.length - 1] === "%") {
                            dh =
                                (parseInt(attv.slice(0, -1)) *
                                    avaiheight) /
                                    100;
                        }
                        else {
                            dh = parseInt(attv);
                        }
                        $(this).css("height", `${dh}px`);
                        ocheight += dh;
                    });
                    const csize = (avaiheight - ocheight) / auto_height.length;
                    if (csize > 0) {
                        $.each(auto_height, (i, v) => $(v).css("height", `${csize}px`));
                    }
                }
                /**
                 * Layout definition
                 *
                 * @returns
                 * @memberof TileLayoutTag
                 */
                layout() {
                    return [
                        {
                            el: "div",
                            ref: "yield",
                        },
                    ];
                }
            }
            tag.TileLayoutTag = TileLayoutTag;
            /**
             * A HBox organize its child elements in horizontal direction
             *
             * @export
             * @class HBoxTag
             * @extends {TileLayoutTag}
             */
            class HBoxTag extends TileLayoutTag {
                /**
                 * Creates an instance of HBoxTag.
                 * @memberof HBoxTag
                 */
                constructor() {
                    super();
                }
                /**
                 * Mount the tag
                 *
                 * @protected
                 * @memberof HBoxTag
                 */
                mount() {
                    super.mount();
                    this.dir = "row";
                    this.name = "hbox";
                }
            }
            tag.HBoxTag = HBoxTag;
            /**
             * A VBox organize its child elements in vertical direction
             *
             * @export
             * @class VBoxTag
             * @extends {TileLayoutTag}
             */
            class VBoxTag extends TileLayoutTag {
                /**
                 *Creates an instance of VBoxTag.
                 * @memberof VBoxTag
                 */
                constructor() {
                    super();
                }
                /**
                 * Mount the tag
                 *
                 * @protected
                 * @memberof VBoxTag
                 */
                mount() {
                    super.mount();
                    this.dir = "column";
                    this.name = "vbox";
                }
            }
            tag.VBoxTag = VBoxTag;
            tag.define("afx-tile", TileLayoutTag);
            tag.define("afx-hbox", HBoxTag);
            tag.define("afx-vbox", VBoxTag);
        })(tag = GUI.tag || (GUI.tag = {}));
    })(GUI = OS.GUI || (OS.GUI = {}));
})(OS || (OS = {}));

var OS;
(function (OS) {
    let GUI;
    (function (GUI) {
        let tag;
        (function (tag) {
            /**
             * A `resizer` tag is basically used to dynamically resize an element using mouse.
             * It is usually put inside a [[TileLayoutTag]] an can be attached to any element. Example:
             *
             * The resizer tag in the following example  will be attached to the first `afx-vbox`,
             * and allows to resize this element using mouse
             *
             * ```xml
             * <afx-hbox>
             *      <afx-vbox>...</afx-vbox>
             *      <afx-resizer></afx-resizer>
             *      <afx-vbox>...</afx-vbox>
             * </afx-hbox>
             * ```
             *
             * @export
             * @class ResizerTag
             * @extends {AFXTag}
             */
            class ResizerTag extends GUI.AFXTag {
                /**
                 *Creates an instance of ResizerTag.
                 * @memberof ResizerTag
                 */
                constructor() {
                    super();
                }
                /**
                 * Set the properties of the tag to default values
                 *
                 * @protected
                 * @memberof ResizerTag
                 */
                init() {
                    this._resizable_el = undefined;
                    this._parent = $(this).parent().parent()[0];
                    this._minsize = 0;
                }
                /**
                 * Do nothing
                 *
                 * @protected
                 * @param {*} [d]
                 * @memberof ResizerTag
                 */
                reload(d) { }
                /**
                 * Setter:
                 *
                 * Set resize direction, two possible values:
                 * - `hz` - horizontal direction, resize by width
                 * - `ve` - vertical direction, resize by height
                 *
                 * Getter:
                 *
                 * Get the resize direction
                 *
                 * @memberof ResizerTag
                 */
                set dir(v) {
                    let att;
                    $(this).attr("dir", v);
                    $(this).off("pointerdown", null);
                    if (v === "hz") {
                        $(this).css("cursor", "col-resize");
                        $(this).addClass("horizontal");
                        if (this._resizable_el) {
                            att = $(this._resizable_el).attr("min-width");
                            if (att) {
                                this._minsize = parseInt(att);
                            }
                        }
                    }
                    else if (v === "ve") {
                        $(this).css("cursor", "row-resize");
                        $(this).addClass("vertical");
                        if (this._resizable_el) {
                            att = $(this._resizable_el).attr("min-height");
                            if (att) {
                                this._minsize = parseInt(att);
                            }
                        }
                    }
                    if (this._minsize === 0) {
                        this._minsize = 10;
                    }
                    this.make_draggable();
                }
                get dir() {
                    return $(this).attr("dir");
                }
                /**
                 * Getter : Check whether the resizer should attach to its next or previous element
                 *
                 * Setter: if `v=true` select next element as attached element of the resizer, otherwise
                 * select the previous element
                 * @readonly
                 * @type {boolean}
                 * @memberof ResizerTag
                 */
                get attachnext() {
                    return this.hasattr("attachnext");
                }
                set attachnext(v) {
                    this.attsw(v, "attachnext");
                }
                /**
                 * Setter:
                 * - set the resize event callback
                 *
                 * Getter:
                 * - get the resize event callback
                 *
                 * @memberof ResizerTag
                 */
                set onelresize(v) {
                    this._onresize = v;
                }
                get onelresize() {
                    return this._onresize;
                }
                /**
                 * Mount the tag to the DOM tree
                 *
                 * @protected
                 * @memberof ResizerTag
                 */
                mount() {
                    $(this).css(" display", "block");
                    const tagname = $(this._parent).prop("tagName");
                    if (this.attachnext) {
                        this._resizable_el =
                            $(this).next().length === 1
                                ? $(this).next()[0]
                                : undefined;
                    }
                    else {
                        this._resizable_el =
                            $(this).prev().length === 1
                                ? $(this).prev()[0]
                                : undefined;
                    }
                    if (tagname === "AFX-HBOX") {
                        this.dir = "hz";
                    }
                    else if (tagname === "AFX-VBOX") {
                        this.dir = "ve";
                    }
                    else {
                        this.dir = "hz";
                    }
                }
                /**
                 * Enable draggable on the element
                 *
                 * @private
                 * @memberof ResizerTag
                 */
                make_draggable() {
                    $(this).css("user-select", "none");
                    if (!this.dir || this.dir == "none") {
                        return;
                    }
                    $(this).on("pointerdown", (e) => {
                        e.preventDefault();
                        $(window).on("pointermove", (evt) => {
                            if (!this._resizable_el) {
                                return;
                            }
                            if (this.dir === "hz") {
                                return this.horizontalResize(evt);
                            }
                            else if (this.dir === "ve") {
                                return this.verticalResize(evt);
                            }
                        });
                        return $(window).on("pointerup", function (evt) {
                            $(window).off("pointermove", null);
                            $(window).off("pointerup", null);
                            return $(window).off("pointerup", null);
                        });
                    });
                }
                /**
                 * Resize the attached element in the horizontal direction (width)
                 *
                 * @private
                 * @param {JQuery.MouseEventBase} e JQuery mouse event
                 * @returns {void}
                 * @memberof ResizerTag
                 */
                horizontalResize(e) {
                    if (!this._resizable_el) {
                        return;
                    }
                    const offset = $(this._resizable_el).offset();
                    let w = 0;
                    if (this.attachnext) {
                        w = Math.round(offset.left + $(this._resizable_el).width() - e.clientX);
                    }
                    else {
                        w = Math.round(e.clientX - offset.left);
                    }
                    if (w < this._minsize) {
                        w = this._minsize;
                    }
                    $(this._resizable_el).attr("data-width", w.toString());
                    let evt = {
                        id: this.aid,
                        data: { w },
                    };
                    if (this.onelresize) {
                        this.onelresize(evt);
                    }
                    this.observable.trigger("resize", evt);
                }
                /**
                 * Resize the attached element in the vertical direction (height)
                 *
                 * @protected
                 * @param {JQuery.MouseEventBase} e JQuery mouse event
                 * @returns {void}
                 * @memberof ResizerTag
                 */
                verticalResize(e) {
                    if (!this._resizable_el) {
                        return;
                    }
                    const offset = $(this._resizable_el).offset();
                    let h = 0;
                    if (this.attachnext) {
                        h = Math.round(offset.top + $(this._resizable_el).height() - e.clientY);
                    }
                    else {
                        h = Math.round(e.clientY - offset.top);
                    }
                    if (h < this._minsize) {
                        h = this._minsize;
                    }
                    $(this._resizable_el).attr("data-height", h.toString());
                    let evt = {
                        id: this.aid,
                        data: { h },
                    };
                    if (this.onelresize) {
                        this.onelresize(evt);
                    }
                    return this.observable.trigger("resize", evt);
                }
                /**
                 * Layout definition of the tag, empty layout
                 *
                 * @protected
                 * @returns {TagLayoutType[]}
                 * @memberof ResizerTag
                 */
                layout() {
                    return [];
                }
            }
            tag.ResizerTag = ResizerTag;
            tag.define("afx-resizer", ResizerTag);
        })(tag = GUI.tag || (GUI.tag = {}));
    })(GUI = OS.GUI || (OS.GUI = {}));
})(OS || (OS = {}));

var OS;
(function (OS) {
    let GUI;
    (function (GUI) {
        let tag;
        (function (tag) {
            /**
             * This class defines basic AFX label tag.
             * A label contains a text and an icon (optional)
             *
             * @export
             * @class LabelTag
             * @extends {AFXTag}
             */
            class LabelTag extends GUI.AFXTag {
                /**
                 *Creates an instance of LabelTag.
                 * @memberof LabelTag
                 */
                constructor() {
                    super();
                }
                /**
                 * this implementation does nothing in this tag
                 *
                 * @protected
                 * @memberof LabelTag
                 */
                mount() {
                    $(this.refs.container)
                        .css("display", "flex");
                    $(this.refs.iclass)
                        .css("flex-shrink", 0);
                    $(this.refs.i)
                        .css("flex-shrink", 0);
                    $(this.refs.text)
                        .css("flex", 1);
                }
                /**
                 * Refresh the text in the label
                 *
                 * @protected
                 * @param {*} d
                 * @memberof LabelTag
                 */
                reload(d) {
                    this.text = this.text;
                }
                /**
                 * Reset to default some property value
                 *
                 * @protected
                 * @memberof LabelTag
                 */
                init() {
                    this.icon = undefined;
                    this.iconclass = undefined;
                    this.text = undefined;
                    this.selectable = false;
                }
                /**
                 * This implementation of the function does nothing
                 *
                 * @protected
                 * @memberof LabelTag
                 */
                calibrate() { }
                /**
                 * Set the VFS path of the label icon
                 *
                 * @memberof LabelTag
                 */
                set icon(v) {
                    $(this.refs.i).attr("style", "");
                    $(this).attr("icon", v);
                    if (v) {
                        $(this.refs.i)
                            .css("background", `url(${OS.API.handle.get}/${v})`)
                            .css("background-size", "100% 100%")
                            .css("background-repeat", "no-repeat");
                        $(this.refs.i).show();
                    }
                    else {
                        $(this.refs.i).hide();
                    }
                }
                /**
                 * set horizontal aligment of the label content
                 *
                 * @param {string} v shall be "left, right, or center"
                 */
                set halign(v) {
                    let align = "center";
                    switch (v) {
                        case "left":
                            align = "flex-start";
                            break;
                        case "right":
                            align = "flex-end";
                            break;
                        default:
                            break;
                    }
                    $(this.refs.container).css("justify-content", align);
                }
                /**
                 * set horizontal aligment of the label content
                 *
                 * @param {string} v shall be "top, bottom, or center"
                 */
                set valign(v) {
                    let align = "center";
                    switch (v) {
                        case "top":
                            align = "flex-start";
                            break;
                        case "bottom":
                            align = "flex-end";
                            break;
                        default:
                            break;
                    }
                    $(this.refs.container).css("align-items", align);
                }
                /**
                 * Set the CSS class of the label icon
                 *
                 * @memberof LabelTag
                 */
                set iconclass(v) {
                    $(this).attr("iconclass", v);
                    $(this.refs.iclass).removeClass();
                    if (v) {
                        $(this.refs.iclass).addClass(v);
                        $(this.refs.iclass).show();
                    }
                    else {
                        $(this.refs.iclass).hide();
                    }
                }
                /**
                 * Setter: Set the text of the label
                 *
                 * Getter: Get the text displayed on the label
                 *
                 * @memberof LabelTag
                 */
                set text(v) {
                    this._text = v;
                    if (v && v !== "") {
                        $(this.refs.text).show();
                        $(this.refs.text).html(v.__());
                    }
                    else {
                        $(this.refs.text).hide();
                    }
                }
                get text() {
                    return this._text;
                }
                /**
                 * Setter: Turn on/off text selection
                 *
                 * Getter: Check whether the label is selectable
                 *
                 * @memberof LabelTag
                 */
                set selectable(v) {
                    this.attsw(v, "selectable");
                    if (v) {
                        $(this.refs.text)
                            .css("user-select", "text")
                            .css("cursor", "text");
                    }
                    else {
                        $(this.refs.text)
                            .css("user-select", "none")
                            .css("cursor", "default");
                    }
                }
                get swon() {
                    return this.hasattr("selectable");
                }
                /**
                 * Lqbel layout definition
                 *
                 * @protected
                 * @returns {TagLayoutType[]}
                 * @memberof LabelTag
                 */
                layout() {
                    return [
                        {
                            el: "span",
                            ref: "container",
                            children: [
                                { el: "i", ref: "iclass" },
                                { el: "i", ref: "i", class: "icon-style" },
                                { el: "i", ref: "text", class: "label-text" },
                            ],
                        },
                    ];
                }
            }
            tag.LabelTag = LabelTag;
            tag.define("afx-label", LabelTag);
        })(tag = GUI.tag || (GUI.tag = {}));
    })(GUI = OS.GUI || (OS.GUI = {}));
})(OS || (OS = {}));

var OS;
(function (OS) {
    let GUI;
    (function (GUI) {
        let tag;
        (function (tag) {
            /**
             * This tag define a basic button and its behavior
             *
             * @export
             * @class ButtonTag
             * @extends {AFXTag}
             */
            class ButtonTag extends GUI.AFXTag {
                /**
                 *Creates an instance of ButtonTag.
                 * @memberof ButtonTag
                 */
                constructor() {
                    super();
                }
                /**
                 * Custom user data setter/gettter
                 *
                 * @memberof ButtonTag
                 */
                set data(v) {
                    this._data = v;
                    this.set(v);
                }
                get data() {
                    return this._data;
                }
                /**
                 * Set the click callback handle for the target button
                 *
                 * @memberof ButtonTag
                 */
                set onbtclick(v) {
                    this._onbtclick = v;
                }
                /**
                 * Set the path to the button icon, the path should be
                 * a VFS file path
                 *
                 * @memberof ButtonTag
                 */
                set icon(v) {
                    $(this).attr("icon", v);
                    this.refs.label.icon = v;
                }
                /**
                 * Set the icon class to the button, this property
                 * allows to style the button icon using CSS
                 *
                 * @memberof ButtonTag
                 */
                set iconclass(v) {
                    $(this).attr("iconclass", v);
                    this.refs.label.iconclass = v;
                }
                /**
                 * Setter: Set the text of the button
                 *
                 * Getter: Get the current button test
                 *
                 * @memberof ButtonTag
                 */
                set text(v) {
                    this.refs.label.text = v;
                }
                get text() {
                    return this.refs.label.text;
                }
                /**
                 * Setter: Enable or disable the button
                 *
                 * Getter: Get the `enable` property of the button
                 *
                 * @memberof ButtonTag
                 */
                set enable(v) {
                    $(this.refs.button).prop("disabled", !v);
                }
                get enable() {
                    return !$(this.refs.button).prop("disabled");
                }
                /**
                 * Setter: set or remove the attribute `selected` of the button
                 *
                 * Getter: check whether the attribute `selected` of the button is set
                 *
                 * @memberof ButtonTag
                 */
                set selected(v) {
                    $(this.refs.button).removeClass();
                    this.attsw(v, "selected");
                    if (v) {
                        $(this.refs.button).addClass("selected");
                    }
                }
                get selected() {
                    return this.hasattr("selected");
                }
                /**
                 * Setter: activate or deactivate the toggle mode of the button
                 *
                 * Getter: Check whether the button is in toggle mode
                 *
                 * @memberof ButtonTag
                 */
                set toggle(v) {
                    this.attsw(v, "toggle");
                }
                get toggle() {
                    return this.hasattr("toggle");
                }
                /**
                 * Mount the tag
                 *
                 * @protected
                 * @memberof ButtonTag
                 */
                mount() {
                    $(this.refs.button).on("click", (e) => {
                        if (this.toggle) {
                            this.selected = !this.selected;
                        }
                        const evt = {
                            id: this.aid,
                            data: e,
                        };
                        this._onbtclick(evt);
                        this.observable.trigger("btclick", evt);
                    });
                }
                /**
                 *  Init the tag before mounting
                 *
                 * @protected
                 * @memberof ButtonTag
                 */
                init() {
                    this.enable = true;
                    this.toggle = false;
                    this._onbtclick = (e) => { };
                }
                /**
                 * Re-calibrate the button, do nothing in this tag
                 *
                 * @protected
                 * @memberof ButtonTag
                 */
                calibrate() { }
                /**
                 * Update the current tag, do nothing in this tag
                 *
                 * @param {*} [d]
                 * @memberof ButtonTag
                 */
                reload(d) { }
                /**
                 * Button layout definition
                 *
                 * @protected
                 * @returns {TagLayoutType[]}
                 * @memberof ButtonTag
                 */
                layout() {
                    return [
                        {
                            el: "Button",
                            ref: "button",
                            children: [{ el: "afx-label", ref: "label" }],
                        },
                    ];
                }
            }
            tag.ButtonTag = ButtonTag;
            tag.define("afx-button", ButtonTag);
        })(tag = GUI.tag || (GUI.tag = {}));
    })(GUI = OS.GUI || (OS.GUI = {}));
})(OS || (OS = {}));

var OS;
(function (OS) {
    let GUI;
    (function (GUI) {
        let tag;
        (function (tag_1) {
            /**
             * A list item represent the individual view of an item in the [[ListView]].
             * This class is an abstract prototype class, implementation of any
             * list view item should extend it
             *
             *
             * @export
             * @abstract
             * @class ListViewItemTag
             * @extends {AFXTag}
             */
            class ListViewItemTag extends GUI.AFXTag {
                /**
                 *Creates an instance of ListViewItemTag.
                 * @memberof ListViewItemTag
                 */
                constructor() {
                    super();
                    this._onselect = this._onctxmenu = this._onclick = this._ondbclick = this._onclose = (e) => { };
                }
                /**
                 * Setter: Turn on/off the `closable` feature of the list item
                 *
                 * Getter: Check whether the item is closable
                 *
                 * @memberof ListViewItemTag
                 */
                set closable(v) {
                    this.attsw(v, "closable");
                    if (v) {
                        $(this.refs.btcl).show();
                    }
                    else {
                        $(this.refs.btcl).hide();
                    }
                }
                get closable() {
                    return this.hasattr("closable");
                }
                /**
                 * Set item select event handle
                 *
                 * @memberof ListViewItemTag
                 */
                set onitemselect(v) {
                    this._onselect = v;
                }
                /**
                 * Setter: select/unselect the current item
                 *
                 * Getter: Check whether the current item is selected
                 *
                 * @memberof ListViewItemTag
                 */
                set selected(v) {
                    this.attsw(v, "selected");
                    $(this.refs.item).removeClass();
                    this._data.selected = v;
                    if (!v) {
                        return;
                    }
                    $(this.refs.item).addClass("selected");
                    this._onselect({ id: this.aid, data: this });
                }
                get selected() {
                    return this.hasattr("selected");
                }
                /**
                 * Set the context menu event handle
                 *
                 * @memberof ListViewItemTag
                 */
                set onctxmenu(v) {
                    this._onctxmenu = v;
                }
                /**
                 * Set the item click event handle
                 *
                 * @memberof ListViewItemTag
                 */
                set onitemclick(v) {
                    this._onclick = v;
                }
                /**
                 * Set the item double click event handle
                 *
                 * @memberof ListViewItemTag
                 */
                set onitemdbclick(v) {
                    this._ondbclick = v;
                }
                /**
                 * set the item close event handle
                 *
                 * @memberof ListViewItemTag
                 */
                set onitemclose(v) {
                    this._onclose = v;
                }
                /**
                 * Mount the tag and bind some events
                 *
                 * @protected
                 * @memberof ListViewItemTag
                 */
                mount() {
                    $(this).addClass("afx-list-item");
                    $(this.refs.item).on("contextmenu", (e) => {
                        this._onctxmenu({ id: this.aid, data: this });
                    });
                    $(this.refs.item).on("click", (e) => {
                        this._onclick({ id: this.aid, data: this, originalEvent: e });
                        e.stopPropagation();
                    });
                    $(this.refs.item).on("dblclick", (e) => {
                        this._ondbclick({ id: this.aid, data: this, originalEvent: e });
                        e.stopPropagation();
                    });
                    $(this.refs.btcl).on("click", (e) => {
                        this._onclose({ id: this.aid, data: this, originalEvent: e });
                        e.preventDefault();
                        e.stopPropagation();
                    });
                }
                /**
                 * Layout definition of the item tag.
                 * This function define the outer layout of the item.
                 * Custom inner layout of each item implementation should
                 * be defined in [[itemlayout]]
                 *
                 * @protected
                 * @returns {TagLayoutType[]}
                 * @memberof ListViewItemTag
                 */
                layout() {
                    let children = [{ el: "i", class: "closable", ref: "btcl" }];
                    const itemlayout = this.itemlayout();
                    if (Array.isArray(itemlayout)) {
                        children = children.concat(itemlayout);
                    }
                    else {
                        children.unshift(itemlayout);
                    }
                    return [
                        {
                            el: "li",
                            ref: "item",
                            children: children,
                        },
                    ];
                }
                /**
                 * Setter:
                 *
                 * Set the data of the list item. This will
                 * trigger the [[ondatachange]] function
                 *
                 * Getter:
                 *
                 * Get the data of the current list item
                 *
                 * @memberof ListViewItemTag
                 */
                set data(v) {
                    this._data = v;
                    this.ondatachange();
                }
                get data() {
                    return this._data;
                }
            }
            tag_1.ListViewItemTag = ListViewItemTag;
            /**
             * The layout of a simple list item contains only a
             * AFX label
             *
             * @export
             * @class SimpleListItemTag
             * @extends {ListViewItemTag}
             */
            class SimpleListItemTag extends ListViewItemTag {
                /**
                 *Creates an instance of SimpleListItemTag.
                 * @memberof SimpleListItemTag
                 */
                constructor() {
                    super();
                }
                /**
                 * Reset some property to default
                 *
                 * @protected
                 * @memberof SimpleListItemTag
                 */
                init() {
                    this.closable = false;
                    this.data = {};
                }
                /**
                 * Do nothing
                 *
                 * @protected
                 * @memberof SimpleListItemTag
                 */
                calibrate() { }
                /**
                 * Refresh the inner label when the item data
                 * is changed
                 *
                 * @protected
                 * @returns {void}
                 * @memberof SimpleListItemTag
                 */
                ondatachange() {
                    const v = this.data;
                    if (!v) {
                        return;
                    }
                    const label = this.refs.label;
                    label.set(v);
                    if (v.selected) {
                        this.selected = v.selected;
                    }
                    if (v.closable) {
                        this.closable = v.closable;
                    }
                }
                /**
                 * Re-render the list item
                 *
                 * @protected
                 * @memberof SimpleListItemTag
                 */
                reload() {
                    this.data = this.data;
                }
                /**
                 * List item custom layout definition
                 *
                 * @protected
                 * @returns {TagLayoutType | TagLayoutType[]}
                 * @memberof SimpleListItemTag
                 */
                itemlayout() {
                    return { el: "afx-label", ref: "label" };
                }
            }
            tag_1.SimpleListItemTag = SimpleListItemTag;
            /**
             * The layout of a double line list item contains two
             * AFX labels
             *
             * @export
             * @class DoubleLineListItemTag
             * @extends {ListViewItemTag}
             */
            class DoubleLineListItemTag extends ListViewItemTag {
                /**
                 *Creates an instance of DoubleLineListItemTag.
                 * @memberof DoubleLineListItemTag
                 */
                constructor() {
                    super();
                }
                /**
                 * Reset some property to default
                 *
                 * @protected
                 * @memberof DoubleLineListItemTag
                 */
                init() {
                    this.closable = false;
                    this.data = {};
                }
                /**
                 * Do nothing
                 *
                 * @protected
                 * @memberof DoubleLineListItemTag
                 */
                calibrate() { }
                /**
                 * Refresh the inner label when the item data
                 * is changed
                 *
                 * @protected
                 * @returns {void}
                 * @memberof DoubleLineListItemTag
                 */
                ondatachange() {
                    const v = this.data;
                    if (!v) {
                        return;
                    }
                    const line1 = this.refs.line1;
                    const line2 = this.refs.line2;
                    line1.set(v);
                    if (v.description) {
                        line2.set(v.description);
                    }
                    if (v.selected) {
                        this.selected = v.selected;
                    }
                    if (v.closable) {
                        this.closable = v.closable;
                    }
                }
                /**
                 * Re-render the list item
                 *
                 * @protected
                 * @memberof DoubleLineListItemTag
                 */
                reload() {
                    this.data = this.data;
                }
                /**
                 * List item custom layout definition
                 *
                 * @protected
                 * @returns {TagLayoutType | TagLayoutType[]}
                 * @memberof DoubleLineListItemTag
                 */
                itemlayout() {
                    return [{ el: "afx-label", ref: "line1", class: "title" }, { el: "afx-label", ref: "line2", class: "description" }];
                }
            }
            tag_1.DoubleLineListItemTag = DoubleLineListItemTag;
            /**
             * This tag defines a traditional or a dropdown list widget.
             * It contains a collection of list items in which layout
             * of each item may be variable
             *
             * @export
             * @class ListViewTag
             * @extends {AFXTag}
             */
            class ListViewTag extends GUI.AFXTag {
                /**
                 *Creates an instance of ListViewTag.
                 * @memberof ListViewTag
                 */
                constructor() {
                    super();
                    this._onlistdbclick = this._onlistselect = this._ondragndrop = (e) => { };
                    this._onitemclose = (e) => {
                        return true;
                    };
                    this._onmousedown = this._onmouseup = this._onmousemove = (e) => { };
                    this._selectedItems = [];
                    this._selectedItem = undefined;
                }
                /**
                 * Reset the tag's properties to the default values
                 *
                 * @protected
                 * @memberof ListViewTag
                 */
                init() {
                    this.data = [];
                    this.multiselect = false;
                    this.dropdown = false;
                    this.selected = -1;
                    this.dragndrop = false;
                    this.itemtag = "afx-list-item";
                    $(this).addClass("afx-list-view");
                }
                /**
                 * This function does nothing
                 *
                 * @protected
                 * @param {*} [d]
                 * @memberof ListViewTag
                 */
                reload(d) { }
                /**
                 * Setter: toggle between dropdown and traditional list
                 *
                 * Getter: Check whether the list is dropdown or traditional list
                 *
                 * @memberof ListViewTag
                 */
                set dropdown(v) {
                    this.attsw(v, "dropdown");
                    $(this.refs.container).removeAttr("style");
                    $(this.refs.mlist).removeAttr("style");
                    $(this).removeClass("dropdown");
                    const drop = (e) => {
                        return this.dropoff(e);
                    };
                    const show = (e) => {
                        return this.showlist(e);
                    };
                    if (v) {
                        $(this).addClass("dropdown");
                        $(this.refs.current).show();
                        $(document).on("click", drop);
                        $(this.refs.current).on("click", show);
                        $(this.refs.mlist).hide();
                        this.calibrate();
                    }
                    else {
                        $(this.refs.current).hide();
                        $(document).off("click", drop);
                        $(this.refs.current).off("click", show);
                    }
                }
                /**
                 * Set drag and drop event handle
                 *
                 * @memberof ListViewTag
                 */
                set ondragndrop(v) {
                    this._ondragndrop = v;
                }
                /**
                 * Set list select event handle
                 *
                 * @memberof ListViewTag
                 */
                set onlistselect(v) {
                    this._onlistselect = v;
                }
                /**
                 * Set double click event handle
                 *
                 * @memberof ListViewTag
                 */
                set onlistdbclick(v) {
                    this._onlistdbclick = v;
                }
                /**
                 * Set item close event handle
                 *
                 * @memberof ListViewTag
                 */
                set onitemclose(v) {
                    this._onitemclose = v;
                }
                get dropdown() {
                    return this.hasAttribute("dropdown");
                }
                /**
                 * Setter:
                 *
                 * Set the default tag name of list's items.
                 * If the tag name is not specified in the
                 * data of a list item, this tag will be used
                 *
                 * Getter:
                 *
                 * Get the default tag name of list item
                 *
                 * @memberof ListViewTag
                 */
                set itemtag(v) {
                    $(this).attr("itemtag", v);
                }
                get itemtag() {
                    return $(this).attr("itemtag");
                }
                /**
                 * Setter:
                 *
                 * Turn on/off of the `multiselect` feature
                 *
                 * Getter:
                 *
                 * Check whether multi-select is allowed
                 * in this list
                 *
                 * @memberof ListViewTag
                 */
                set multiselect(v) {
                    this.attsw(v, "multiselect");
                }
                get multiselect() {
                    if (this.dropdown) {
                        return false;
                    }
                    return this.hasattr("multiselect");
                }
                /**
                 * Setter: Enable/disable drag and drop event in the list
                 *
                 * Getter: Check whether the drag and drop event is enabled
                 *
                 * @memberof ListViewTag
                 */
                set dragndrop(v) {
                    this.attsw(v, "dragndrop");
                }
                get dragndrop() {
                    return this.hasattr("dragndrop");
                }
                /**
                 * Set the buttons layout of the list.
                 * Button layout allows to add some custom
                 * behaviors to the list.
                 *
                 * Each button data should define the [[onbtclick]]
                 * event handle to specify the custom behavior
                 *
                 * When the list is configured as dropdown. The buttons
                 * layout will be disabled
                 *
                 * Example of a button data:
                 *
                 * ```
                 * {
                 *      text: "Button text",
                 *      icon: "home://path/to/icon.png",
                 *      iconclass: "icon-class-name",
                 *      onbtclick: (e) => console.log(e)
                 * }
                 * ```
                 *
                 * @memberof ListViewTag
                 */
                set buttons(v) {
                    if (this.dropdown) {
                        return;
                    }
                    if (!v || !(v.length > 0)) {
                        return;
                    }
                    $(this.refs.btlist).empty();
                    for (let item of v) {
                        $(this.refs.btlist).show();
                        const bt = $("<afx-button>").appendTo(this.refs.btlist);
                        bt[0].uify(this.observable);
                        bt[0].set(item);
                    }
                }
                /**
                 * Getter: Get list direction: horizontal or vertical (default)
                 *
                 * Setter: Get list direction: horizontal or vertical
                 *
                 * @type {string}
                 * @memberof ListViewTag
                 */
                set dir(v) {
                    if (this.dropdown) {
                        $(this).attr("dir", "vertical");
                    }
                    else {
                        $(this).attr("dir", v);
                    }
                    this.calibrate();
                }
                get dir() {
                    return $(this).attr("dir");
                }
                /**
                 * Getter: Get data of the list
                 *
                 * Setter: Set data to the list
                 *
                 * @type {GenericObject<any>[]}
                 * @memberof ListViewTag
                 */
                get data() {
                    return this._data;
                }
                set data(data) {
                    this._data = data;
                    this._selectedItem = undefined;
                    this._selectedItems = [];
                    $(this.refs.mlist).empty();
                    for (let item of data) {
                        this.push(item, false);
                    }
                    $(this.refs.container).off("mousedown", this._onmousedown);
                    if (this.dragndrop && !this.dropdown) {
                        $(this.refs.container).on("mousedown", this._onmousedown);
                    }
                    this.ondatachange();
                }
                /**
                 * Do nothing
                 *
                 * @protected
                 * @memberof ListViewTag
                 */
                ondatachange() { }
                /**
                 * Setter: Select list item(s) by their indexes
                 *
                 * Getter: Get the indexes of all selected items
                 *
                 * @memberof ListViewTag
                 */
                set selected(idx) {
                    if (!this.data) {
                        return;
                    }
                    const select = (i) => {
                        if (i < 0) {
                            this.unselect();
                            return;
                        }
                        const data = this.data;
                        if (i >= data.length) {
                            return;
                        }
                        const el = data[i].domel;
                        el.selected = true;
                    };
                    if (Array.isArray(idx)) {
                        if (this.multiselect) {
                            for (const i of idx) {
                                select(i);
                            }
                        }
                    }
                    else {
                        select(idx);
                    }
                }
                /**
                 * Get the latest selected item
                 *
                 * @readonly
                 * @type {ListViewItemTag}
                 * @memberof ListViewTag
                 */
                get selectedItem() {
                    return this._selectedItem;
                }
                /**
                 * Get all the selected items
                 *
                 * @readonly
                 * @type {ListViewItemTag[]}
                 * @memberof ListViewTag
                 */
                get selectedItems() {
                    return this._selectedItems;
                }
                /**
                 * get the selected item index
                 *
                 * @readonly
                 * @type {number}
                 * @memberof ListViewTag
                 */
                get selected() {
                    if (this.multiselect) {
                        return this.selectedItems.map(function (it) {
                            return $(it).index();
                        });
                    }
                    return $(this.selectedItem).index();
                }
                /**
                 * Add an item to the beginning of the list
                 *
                 * @param {GenericObject<any>} item
                 * @returns {ListViewItemTag} the added list item element
                 * @memberof ListViewTag
                 */
                unshift(item) {
                    return this.push(item, true);
                }
                /**
                 * check whether the list has data
                 *
                 * @private
                 * @param {GenericObject<any>} v
                 * @returns
                 * @memberof ListViewTag
                 */
                has_data(v) {
                    return this.data && this.data.includes(v);
                }
                /**
                 * Add an item to the beginning or end of the list
                 *
                 * @param {GenericObject<any>} item list item data
                 * @param {boolean} flag indicates whether to add the item in the beginning of the list
                 * @returns {ListViewItemTag} the added list item element
                 * @memberof ListViewTag
                 */
                push(item, flag) {
                    let tag = this.itemtag;
                    if (item.tag)
                        tag = item.tag;
                    const el = $(`<${tag}>`);
                    if (flag) {
                        if (!this.has_data(item)) {
                            this.data.unshift(item);
                        }
                        $(this.refs.mlist).prepend(el[0]);
                    }
                    else {
                        if (!this.has_data(item)) {
                            this.data.push(item);
                        }
                        el.appendTo(this.refs.mlist);
                    }
                    el[0].uify(this.observable);
                    const element = el[0];
                    $(element).attr("list-id", this.aid);
                    element.onctxmenu = (e) => {
                        return this.iclick(e, true);
                    };
                    element.onitemdbclick = (e) => {
                        this.idbclick(e);
                        this.iclick(e, false);
                    };
                    element.onitemclick = (e) => {
                        return this.iclick(e, false);
                    };
                    element.onitemselect = (e) => {
                        return this.iselect(e);
                    };
                    element.onitemclose = (e) => {
                        return this.iclose(e);
                    };
                    element.data = item;
                    item.domel = el[0];
                    return element;
                }
                /**
                 * Delete an item
                 *
                 * @param {ListViewItemTag} item item DOM element
                 * @memberof ListViewTag
                 */
                delete(item) {
                    const el = item.data;
                    const data = this.data;
                    if (this.selectedItem === item) {
                        this._selectedItem = undefined;
                    }
                    const list = this.selectedItems;
                    if (list.includes(item)) {
                        list.splice(list.indexOf(item), 1);
                    }
                    if (data.includes(el)) {
                        data.splice(data.indexOf(el), 1);
                    }
                    $(item).remove();
                }
                /**
                 * Select item next to the currently selected item.
                 * If there is no item selected, the first item will
                 * be selected
                 *
                 * @returns {void}
                 * @memberof ListViewTag
                 */
                selectNext() {
                    if (this.multiselect) {
                        return;
                    }
                    const el = this.selectedItem;
                    let idx = 0;
                    if (el) {
                        idx = $(el).index() + 1;
                    }
                    this.selected = idx;
                }
                /**
                 * Select the previous item in the list.
                 *
                 * @returns {void}
                 * @memberof ListViewTag
                 */
                selectPrev() {
                    if (this.multiselect) {
                        return;
                    }
                    const el = this.selectedItem;
                    let idx = 0;
                    if (el) {
                        idx = $(el).index() - 1;
                    }
                    this.selected = idx;
                }
                /**
                 * Unselect all the selected items in the list
                 *
                 * @returns {void}
                 * @memberof ListViewTag
                 */
                unselect() {
                    for (let v of this.selectedItems) {
                        v.selected = false;
                    }
                    this._selectedItems = [];
                    this._selectedItem = undefined;
                }
                /**
                 * This function triggers the click event on an item
                 *
                 * @private
                 * @param {TagEventType} e tag event object
                 * @param {boolean} flag indicates whether this is a double click event
                 * @returns {void}
                 * @memberof ListViewTag
                 */
                iclick(e, flag) {
                    if (!e.data) {
                        return;
                    }
                    const list = this.selectedItems;
                    if (this.multiselect && list.includes(e.data) && !flag) {
                        list.splice(list.indexOf(e.data), 1);
                        e.data.selected = false;
                        return;
                    }
                    e.data.selected = true;
                }
                /**
                 * This function triggers the double click event on an item
                 *
                 * @protected
                 * @param {TagEventType} e tag event object
                 * @returns
                 * @memberof ListViewTag
                 */
                idbclick(e) {
                    const evt = {
                        id: this.aid,
                        data: { item: e.data },
                    };
                    this._onlistdbclick(evt);
                    return this.observable.trigger("listdbclick", evt);
                }
                /**
                 * This function triggers the list item select event
                 *
                 * @protected
                 * @param {TagEventType} e tag event object
                 * @returns
                 * @memberof ListViewTag
                 */
                iselect(e) {
                    if (!e.data) {
                        return;
                    }
                    var edata = { item: e.data, items: [] };
                    if (this.multiselect) {
                        if (this.selectedItems.includes(e.data)) {
                            return;
                        }
                        this._selectedItem = e.data;
                        this.selectedItems.push(e.data);
                        edata.items = this.selectedItems;
                    }
                    else {
                        if (this.selectedItems.length > 0) {
                            for (const item of this.selectedItems) {
                                if (item != e.data) {
                                    item.selected = false;
                                }
                            }
                        }
                        if (this.selectedItem === e.data) {
                            return;
                        }
                        if (this.selectedItem) {
                            this.selectedItem.selected = false;
                        }
                        this._selectedItem = e.data;
                        this._selectedItems = [e.data];
                        edata.items = [e.data];
                        //scroll element
                        const li = $(e.data).children()[0];
                        const offset = $(this.refs.container).offset();
                        const top = $(this.refs.container).scrollTop();
                        if ($(li).offset().top + $(li).height() >
                            $(this.refs.container).height() + offset.top) {
                            $(this.refs.container).scrollTop(top +
                                $(this.refs.container).height() -
                                $(li).height());
                        }
                        else if ($(li).offset().top < offset.top) {
                            $(this.refs.container).scrollTop(top -
                                $(this.refs.container).height() +
                                $(li).height());
                        }
                    }
                    if (this.dropdown) {
                        const label = this.refs.drlabel;
                        label.set(e.data.data);
                        $(this.refs.mlist).hide();
                    }
                    const evt = { id: this.aid, data: edata };
                    this._onlistselect(evt);
                    return this.observable.trigger("listselect", evt);
                }
                /**
                 * Mount the tag and bind some basic event
                 *
                 * @protected
                 * @returns {void}
                 * @memberof ListViewTag
                 */
                mount() {
                    this._dnd = {
                        from: undefined,
                        to: undefined,
                    };
                    this._onmousedown = (e) => {
                        if (this.multiselect || this.selectedItems == undefined || this.selectedItems.length == 0) {
                            return;
                        }
                        let el = $(e.target).closest(`[list-id='${this.aid}']`);
                        if (el.length === 0) {
                            return;
                        }
                        el = el[0];
                        if (!this.selectedItems.includes(el)) {
                            return;
                        }
                        this._dnd.from = this.selectedItems;
                        this._dnd.to = undefined;
                        $(window).on("mouseup", this._onmouseup);
                        $(window).on("mousemove", this._onmousemove);
                    };
                    this._onmouseup = (e) => {
                        $(window).off("mouseup", this._onmouseup);
                        $(window).off("mousemove", this._onmousemove);
                        $("#systooltip").hide();
                        let el = $(e.target).closest(`[list-id='${this.aid}']`);
                        if (el.length === 0) {
                            return;
                        }
                        el = el[0];
                        if (this._dnd.from.includes(el)) {
                            return;
                        }
                        this._dnd.to = el;
                        this._ondragndrop({ id: this.aid, data: this._dnd });
                        this._dnd = {
                            from: undefined,
                            to: undefined,
                        };
                    };
                    this._onmousemove = (e) => {
                        if (!e) {
                            return;
                        }
                        if (!this._dnd.from) {
                            return;
                        }
                        const data = {
                            text: '',
                            items: this._dnd.from
                        };
                        if (this._dnd.from.length == 1) {
                            data.text = this._dnd.from[0].data.text;
                        }
                        else {
                            data.text = __("{0} selected elements", this._dnd.from.length).__();
                        }
                        const $label = $("#systooltip");
                        const top = e.clientY + 5;
                        const left = e.clientX + 5;
                        $label.show();
                        const label = $label[0];
                        label.set(data);
                        return $label
                            .css("top", top + "px")
                            .css("left", left + "px");
                    };
                    $(this.refs.drlabel).css("display", "inline-block");
                    $(this.refs.btlist).hide();
                    this.observable.on("resize", (e) => this.calibrate());
                    return this.calibrate();
                }
                /**
                 * This function triggers the item close event
                 *
                 * @private
                 * @param {TagEventType} e tag event object
                 * @returns {void}
                 * @memberof ListViewTag
                 */
                iclose(e) {
                    if (!e.data) {
                        return;
                    }
                    const evt = { id: this.aid, data: { item: e.data } };
                    const r = this._onitemclose(evt);
                    if (!r) {
                        return;
                    }
                    this.observable.trigger("itemclose", evt);
                    return this.delete(e.data);
                }
                /**
                 * Show the dropdown list.
                 * This function is called only when the list is a dropdown
                 * list
                 *
                 * @protected
                 * @param {*} e
                 * @returns {void}
                 * @memberof ListViewTag
                 */
                showlist(e) {
                    if (!this.dropdown) {
                        return;
                    }
                    if (!$(this.refs.mlist).is(":hidden")) {
                        $(this.refs.mlist).hide();
                        return;
                    }
                    const desktoph = $(Ant.OS.GUI.workspace).outerHeight();
                    const offset = $(this).offset().top + $(this.refs.mlist).outerHeight() * 1.5;
                    if (offset > desktoph) {
                        $(this.refs.mlist).css("top", `-${$(this.refs.mlist).outerHeight()}px`);
                    }
                    else {
                        $(this.refs.mlist).css("top", "98%");
                    }
                    $(this.refs.mlist).show();
                }
                /**
                 * Hide the dropdown list.
                 * This function is called only when the list is a dropdown
                 * list
                 *
                 * @protected
                 * @param {*} e
                 * @memberof ListViewTag
                 */
                dropoff(e) {
                    if ($(e.target).closest(this.refs.container).length === 0) {
                        $(this.refs.mlist).hide();
                    }
                }
                /**
                 * calibrate the list layout
                 *
                 * @protected
                 * @returns {void}
                 * @memberof ListViewTag
                 */
                calibrate() {
                    if (!this.dropdown) {
                        return;
                    }
                    const w = `${$(this).width()}px`;
                    const h = `${$(this).outerHeight()}px`;
                    $(this.refs.container).css("width", w);
                    $(this.refs.container).css("height", h);
                    $(this.refs.current).css("width", w);
                    $(this.refs.mlist).css("width", w);
                }
                /**
                 * List view layout definition
                 *
                 * @protected
                 * @returns {TagLayoutType[]}
                 * @memberof ListViewTag
                 */
                layout() {
                    return [
                        {
                            el: "div",
                            class: "list-container",
                            ref: "container",
                            children: [
                                {
                                    el: "div",
                                    ref: "current",
                                    children: [
                                        { el: "afx-label", ref: "drlabel" },
                                    ],
                                },
                                { el: "ul", ref: "mlist" },
                            ],
                        },
                        { el: "div", class: "button_container", ref: "btlist" },
                    ];
                }
            }
            tag_1.ListViewTag = ListViewTag;
            tag_1.define("afx-list-view", ListViewTag);
            tag_1.define("afx-list-item", SimpleListItemTag);
            tag_1.define("afx-dbline-list-item", DoubleLineListItemTag);
        })(tag = GUI.tag || (GUI.tag = {}));
    })(GUI = OS.GUI || (OS.GUI = {}));
})(OS || (OS = {}));

var OS;
(function (OS) {
    let GUI;
    (function (GUI) {
        let tag;
        (function (tag) {
            /**
             * A switch tag is basically used to visualize an boolean data value.
             *
             * @export
             * @class SwitchTag
             * @extends {AFXTag}
             */
            class SwitchTag extends GUI.AFXTag {
                /**
                 * Setter: Turn on/off the switch
                 *
                 * Getter: Check whether the switch is turned on
                 *
                 * @memberof SwitchTag
                 */
                set swon(v) {
                    this.attsw(v, "swon");
                    $(this.refs.switch).removeClass();
                    if (v) {
                        $(this.refs.switch).addClass("swon");
                    }
                }
                get swon() {
                    return this.hasattr("swon");
                }
                /**
                 * Setter: Enable the switch
                 *
                 * Getter: Check whether the switch is enabled
                 *
                 * @memberof SwitchTag
                 */
                set enable(v) {
                    this.attsw(v, "enable");
                }
                get enable() {
                    return this.hasattr("enable");
                }
                /**
                 * Set the onchange event handle
                 *
                 * @memberof SwitchTag
                 */
                set onswchange(v) {
                    this._onchange = v;
                }
                /**
                 * Mount the tag and bind the click event to the switch
                 *
                 * @protected
                 * @memberof SwitchTag
                 */
                mount() {
                    $(this.refs.switch).on("click", (e) => {
                        return this.makechange(e);
                    });
                }
                /**
                 * This function will turn the switch (on/off)
                 * and trigger the onchange event
                 *
                 * @private
                 * @param {JQuery.ClickEvent} e
                 * @returns
                 * @memberof SwitchTag
                 */
                makechange(e) {
                    if (!this.enable) {
                        return;
                    }
                    this.swon = !this.swon;
                    const evt = { id: this.aid, data: this.swon };
                    this._onchange(evt);
                    return this.observable.trigger("switch", evt);
                }
                /**
                 * Tag layout definition
                 *
                 * @protected
                 * @returns
                 * @memberof SwitchTag
                 */
                layout() {
                    return [
                        {
                            el: "span",
                            ref: "switch",
                        },
                    ];
                }
                /**
                 * Init the tag:
                 * - switch is turn off
                 * - switch is enabled
                 *
                 * @protected
                 * @memberof SwitchTag
                 */
                init() {
                    this.swon = false;
                    this.enable = true;
                    this._onchange = (e) => { };
                }
                /**
                 * Do nothing
                 *
                 * @protected
                 * @memberof SwitchTag
                 */
                calibrate() { }
                /**
                 * Do nothing
                 *
                 * @protected
                 * @param {*} [d]
                 * @memberof SwitchTag
                 */
                reload(d) { }
            }
            tag.SwitchTag = SwitchTag;
            tag.define("afx-switch", SwitchTag);
        })(tag = GUI.tag || (GUI.tag = {}));
    })(GUI = OS.GUI || (OS.GUI = {}));
})(OS || (OS = {}));

var OS;
(function (OS) {
    let GUI;
    (function (GUI) {
        let tag;
        (function (tag) {
            /**
             * A simple number sinner tag
             *
             * @export
             * @class NSpinnerTag
             * @extends {AFXTag}
             */
            class NSpinnerTag extends GUI.AFXTag {
                /**
                 *Creates an instance of NSpinnerTag.
                 * @memberof NSpinnerTag
                 */
                constructor() {
                    super();
                    this._onchange = (e) => { };
                }
                /**
                 * Init the spinner value to `0` and step to `1`
                 *
                 * @protected
                 * @memberof NSpinnerTag
                 */
                init() {
                    this._value = 0;
                    this.step = 1;
                }
                /**
                 * Do nothing
                 *
                 * @protected
                 * @param {*} [d]
                 * @memberof NSpinnerTag
                 */
                reload(d) { }
                /**
                 * Set the value change event handle
                 *
                 * @memberof NSpinnerTag
                 */
                set onvaluechange(f) {
                    this._onchange = f;
                }
                /**
                 * Mount the tag and bind basic events
                 *
                 * @protected
                 * @memberof NSpinnerTag
                 */
                mount() {
                    $(this.refs.holder).attr("type", "text");
                    $(this.refs.incr).on("click", (e) => {
                        this.value = this.value + this.step;
                    });
                    $(this.refs.decr).on("click", (e) => {
                        this.value = this.value - this.step;
                    });
                    // @observable.on "calibrate", () -> @calibrate()
                    this.observable.on("resize", () => this.calibrate());
                    $(this.refs.holder).on("keyup", (e) => {
                        if (e.which === 13) {
                            let val = parseInt(this.refs.holder.value);
                            if (!isNaN(val)) {
                                if (val < 0) {
                                    val = this.value;
                                }
                                return (this.value = val);
                            }
                        }
                    });
                    this.calibrate();
                }
                /**
                 * Calibrate the layout of the spinner
                 *
                 * @memberof NSpinnerTag
                 */
                calibrate() {
                }
                /**
                 * Setter: Set the spinner value
                 *
                 * Getter: Get the spinner value
                 *
                 * @memberof NSpinnerTag
                 */
                set value(v) {
                    if (this._value === v || isNaN(v)) {
                        return;
                    }
                    this._value = v;
                    $(this.refs.holder).val(this._value);
                    const evt = { id: this.aid, data: v };
                    this._onchange(evt);
                    this.observable.trigger("nspin", evt);
                }
                get value() {
                    return this._value;
                }
                /**
                 * Spinner layout definition
                 *
                 * @protected
                 * @returns {TagLayoutType[]}
                 * @memberof NSpinnerTag
                 */
                layout() {
                    return [
                        {
                            el: "input",
                            ref: "holder",
                        },
                        {
                            el: "ul",
                            ref: "spinner",
                            children: [
                                {
                                    el: "li",
                                    class: "incr",
                                    ref: "incr",
                                    children: [{ el: "i" }],
                                },
                                {
                                    el: "li",
                                    class: "decr",
                                    ref: "decr",
                                    children: [{ el: "i" }],
                                },
                            ],
                        },
                    ];
                }
            }
            tag.NSpinnerTag = NSpinnerTag;
            tag.define("afx-nspinner", NSpinnerTag);
        })(tag = GUI.tag || (GUI.tag = {}));
    })(GUI = OS.GUI || (OS.GUI = {}));
})(OS || (OS = {}));

var OS;
(function (OS) {
    let GUI;
    (function (GUI) {
        let tag;
        (function (tag_1) {
            /**
             * This class defines the abstract prototype of an menu entry.
             * Any implementation of menu entry tag should extend this class
             *
             * @export
             * @abstract
             * @class MenuEntryTag
             * @extends {AFXTag}
             */
            class MenuEntryTag extends GUI.AFXTag {
                /**
                 *Creates an instance of MenuEntryTag.
                 * @memberof MenuEntryTag
                 */
                constructor() {
                    super();
                    this._onmenuselect = this._onchildselect = (e) => { };
                }
                /**
                 * Init the tag before mounting
                 *
                 * @protected
                 * @memberof MenuEntryTag
                 */
                init() {
                    this.nodes = undefined;
                }
                /**
                 * Set the `menu entry select` event handle
                 *
                 * @memberof MenuEntryTag
                 */
                set onmenuselect(v) {
                    this._onmenuselect = v;
                }
                /**
                 * Setter: Set the `sub menu entry select` event handle
                 *
                 * Getter: get the current `sub menu entry select` event handle
                 *
                 * @memberof MenuEntryTag
                 */
                set onchildselect(v) {
                    this._onchildselect = v;
                }
                get onchildselect() {
                    return this._onchildselect;
                }
                /**
                 * Setter: Set data to the entry
                 *
                 * Getter: Get data of the current menu entry
                 *
                 * @memberof MenuEntryTag
                 */
                set data(data) {
                    this._data = data;
                    this.set(data);
                }
                get data() {
                    return this._data;
                }
                /**
                 * Check whether the current menu entry has sub-menu
                 *
                 * @protected
                 * @returns {boolean}
                 * @memberof MenuEntryTag
                 */
                has_nodes() {
                    const ch = this.nodes;
                    return ch && ch.length > 0;
                }
                /**
                 * Check whether the current menu entry is the root entry
                 *
                 * @protected
                 * @returns
                 * @memberof MenuEntryTag
                 */
                is_root() {
                    if (this.parent) {
                        return false;
                    }
                    else {
                        return true;
                    }
                }
                /**
                 * Layout definition of the menu entry
                 * This function define the outer layout of the menu entry.
                 * Custom inner layout of each item implementation should
                 * be defined in [[itemlayout]]
                 * @protected
                 * @returns {TagLayoutType[]}
                 * @memberof MenuEntryTag
                 */
                layout() {
                    return [
                        {
                            el: "li",
                            ref: "container",
                            children: [
                                {
                                    el: "a",
                                    ref: "entry",
                                    children: this.itemlayout(),
                                },
                                { el: "afx-menu", ref: "submenu" },
                            ],
                        },
                    ];
                }
                /**
                 * Setter: Set the sub-menu data
                 *
                 * Getter: Get the sub-menu data
                 *
                 * @memberof MenuEntryTag
                 */
                set nodes(v) {
                    $(this.refs.container).removeClass("afx_submenu");
                    if (!v || !(v.length > 0)) {
                        $(this.refs.submenu).hide();
                        return;
                    }
                    $(this.refs.container).addClass("afx_submenu");
                    $(this.refs.submenu).show().attr("style", "");
                    const element = this.refs.submenu;
                    element.parent = this;
                    element.root = this.root;
                    element.items = v;
                    // ensure that the data is in sync
                    this._data.nodes = v;
                    if (this.is_root()) {
                        $(this.refs.container).on("mouseleave", (e) => {
                            return $(this.refs.submenu).attr("style", "");
                        });
                    }
                }
                get nodes() {
                    if (this.data && this.data.nodes) {
                        return this.data.nodes;
                    }
                    return undefined;
                }
                /**
                 * Bind some base event to the menu entry
                 *
                 * @protected
                 * @memberof MenuEntryTag
                 */
                mount() {
                    $(this.refs.entry).on("click", (e) => this.select(e));
                }
                /**
                 * Hide the sub-menu of the current menu entry
                 *
                 * @private
                 * @returns {void}
                 * @memberof MenuEntryTag
                 */
                submenuoff() {
                    const p = this.parent;
                    if (!p) {
                        $(this.refs.submenu).attr("style", "");
                        return;
                    }
                    return p.submenuoff();
                }
                /**
                 * This function trigger two event:
                 * - the `onmenuselect` event on the current entry
                 * - the `onchildselect` event on the parent of the current entry
                 *
                 * @protected
                 * @param {JQuery.ClickEvent} e
                 * @memberof MenuEntryTag
                 */
                select(e) {
                    const evt = {
                        id: this.aid,
                        data: { item: this, event: e },
                    };
                    e.preventDefault();
                    if (this.is_root() && this.has_nodes()) {
                        $(this.refs.submenu).show();
                    }
                    else {
                        this.submenuoff();
                    }
                    this._onmenuselect(evt);
                    if (this.parent) {
                        this.parent.onchildselect(evt);
                    }
                    if (this.root) {
                        this.root.onmenuitemselect(evt);
                    }
                }
            }
            tag_1.MenuEntryTag = MenuEntryTag;
            /**
             * This class extends the [[MenuEntryTag]] prototype. It inner layout is
             * defined with the following elements:
             * - a [[SwitchTag]] acts as checker or radio
             * - a [[LabelTag]] to display the content of the menu entry
             * - a `span` element that display the keyboard shortcut of the entry
             *
             * @class SimpleMenuEntryTag
             * @extends {MenuEntryTag}
             */
            class SimpleMenuEntryTag extends MenuEntryTag {
                /**
                 *Creates an instance of SimpleMenuEntryTag.
                 * @memberof SimpleMenuEntryTag
                 */
                constructor() {
                    super();
                }
                /**
                 * Reset some properties to default value
                 *
                 * @protected
                 * @memberof SimpleMenuEntryTag
                 */
                init() {
                    super.init();
                    this.switch = false;
                    this.radio = false;
                    this.checked = false;
                }
                /**
                 * Do nothing
                 *
                 * @protected
                 * @memberof SimpleMenuEntryTag
                 */
                calibrate() { }
                /**
                 * Do nothing
                 *
                 * @protected
                 * @param {*} [d]
                 * @memberof SimpleMenuEntryTag
                 */
                reload(d) { }
                /**
                 * Setter: Turn on/off the checker feature of the menu entry
                 *
                 * Getter: Check whether the checker feature is enabled on this menu entry
                 *
                 * @memberof SimpleMenuEntryTag
                 */
                set switch(v) {
                    this.attsw(v, "switch");
                    if (this.radio || v) {
                        $(this.refs.switch).show();
                    }
                    else {
                        $(this.refs.switch).hide();
                    }
                }
                get switch() {
                    return this.hasattr("switch");
                }
                /**
                 * Setter: Turn on/off the radio feature of the menu entry
                 *
                 * Getter: Check whether the radio feature is enabled
                 *
                 * @memberof SimpleMenuEntryTag
                 */
                set radio(v) {
                    this.attsw(v, "radio");
                    if (this.switch || v) {
                        $(this.refs.switch).show();
                    }
                    else {
                        $(this.refs.switch).hide();
                    }
                }
                get radio() {
                    return this.hasattr("radio");
                }
                /**
                 * Setter:
                 *
                 * Toggle the switch on the menu entry, this setter
                 * only works when the `checker` or `radio` feature is
                 * enabled
                 *
                 * Getter:
                 *
                 * Check whether the switch is turned on
                 *
                 * @memberof SimpleMenuEntryTag
                 */
                set checked(v) {
                    this.attsw(v, "checked");
                    if (this.data)
                        this.data.checked = v;
                    if (!this.radio && !this.switch) {
                        return;
                    }
                    this.refs.switch.swon = v;
                }
                get checked() {
                    return this.hasattr("checked");
                }
                /**
                 * Set the label icon using a VFS path
                 *
                 * @memberof SimpleMenuEntryTag
                 */
                set icon(v) {
                    //$(this.refs.container).removeClass("fix_padding");
                    if (!v) {
                        return;
                    }
                    //$(this).attr("icon", v);
                    const label = this.refs.label;
                    label.icon = v;
                    //$(this.refs.container).addClass("fix_padding");
                }
                /**
                 * Set the label CSS icon class
                 *
                 * @memberof SimpleMenuEntryTag
                 */
                set iconclass(v) {
                    if (!v) {
                        return;
                    }
                    const label = this.refs.label;
                    label.iconclass = v;
                }
                /**
                 * Set the label text
                 *
                 * @memberof SimpleMenuEntryTag
                 */
                set text(v) {
                    if (v === undefined) {
                        return;
                    }
                    const label = this.refs.label;
                    label.text = v;
                }
                /**
                 * Set the keyboard shortcut text
                 *
                 * @memberof SimpleMenuEntryTag
                 */
                set shortcut(v) {
                    $(this.refs.shortcut).hide();
                    if (!v) {
                        return;
                    }
                    $(this.refs.shortcut).show();
                    $(this.refs.shortcut).text(v);
                }
                /**
                 * Uncheck all sub-menu items of the current menu entry
                 * that have the radio feature enabled
                 *
                 * @returns {void}
                 * @memberof SimpleMenuEntryTag
                 */
                reset_radio() {
                    if (!this.has_nodes()) {
                        return;
                    }
                    for (let v of this.nodes) {
                        if (!v.domel.radio) {
                            continue;
                        }
                        v.domel.checked = false;
                    }
                }
                /**
                 * Mount the current tag
                 *
                 * @protected
                 * @memberof SimpleMenuEntryTag
                 */
                mount() {
                    super.mount();
                    this.refs.switch.enable = false;
                }
                /**
                 * Trigger the onmenuselect and onchildselect events
                 *
                 * @protected
                 * @param {JQuery.ClickEvent} e Mouse click event
                 * @returns {void}
                 * @memberof SimpleMenuEntryTag
                 */
                select(e) {
                    if (this.switch) {
                        this.checked = !this.checked;
                    }
                    else if (this.radio) {
                        const p = this.parent;
                        if (p) {
                            p.reset_radio();
                        }
                        this.checked = !this.checked;
                    }
                    return super.select(e);
                }
                /**
                 * Inner item layout of the menu entry
                 *
                 * @returns
                 * @memberof SimpleMenuEntryTag
                 */
                itemlayout() {
                    return [
                        { el: "afx-switch", ref: "switch" },
                        { el: "afx-label", ref: "label" },
                        { el: "span", class: "shortcut", ref: "shortcut" },
                    ];
                }
            }
            tag_1.SimpleMenuEntryTag = SimpleMenuEntryTag;
            /**
             * A menu tag contains a collection of menu entries in which each
             * entry maybe a leaf entry or may contain a submenu
             *
             * @export
             * @class MenuTag
             * @extends {AFXTag}
             */
            class MenuTag extends GUI.AFXTag {
                /**
                 *Creates an instance of MenuTag.
                 * @memberof MenuTag
                 */
                constructor() {
                    super();
                }
                /**
                 * Reset some properties to  default value
                 *
                 * @protected
                 * @memberof MenuTag
                 */
                init() {
                    this.contentag = "afx-menu-entry";
                    this.context = false;
                    this._items = [];
                    this._onmenuselect = (e) => { };
                }
                /**
                 * Do nothing
                 *
                 * @protected
                 * @memberof MenuTag
                 */
                calibrate() { }
                /**
                 * Do nothing
                 *
                 * @protected
                 * @param {*} [d]
                 * @memberof MenuTag
                 */
                reload(d) { }
                /**
                 * Setter: Set the menu items data
                 *
                 * Getter: Get menu items data
                 *
                 * @memberof MenuTag
                 */
                set items(data) {
                    this._items = data;
                    $(this.refs.container).empty();
                    data.map((item) => this.push(item, false));
                }
                get items() {
                    return this._items;
                }
                /**
                 * Setter: Set whether the current menu is a context menu
                 *
                 * Getter: Check whether the current menu is a context menu
                 *
                 * @memberof MenuTag
                 */
                set context(v) {
                    this.attsw(v, "context");
                    $(this.refs.wrapper).removeClass("context");
                    if (!v) {
                        return;
                    }
                    $(this.refs.wrapper).addClass("context");
                    $(this).hide();
                }
                get context() {
                    return this.hasattr("context");
                }
                /**
                 * Set menu select event handle
                 *
                 * @memberof MenuTag
                 */
                set onmenuselect(v) {
                    this._onmenuselect = v;
                }
                /**
                 * Setter:
                 *
                 * Set the default tag name of the menu item.
                 * If the tag is not specified in an item data,
                 * this value will be used
                 *
                 * Getter:
                 *
                 * Get the default menu entry tag name
                 *
                 * @memberof MenuTag
                 */
                set contentag(v) {
                    $(this).attr("contentag", v);
                }
                get contentag() {
                    return $(this).attr("contentag");
                }
                /**
                 * Get the reference to the function that triggers
                 * the menu select event
                 *
                 * @readonly
                 * @type {TagEventCallback}
                 * @memberof MenuTag
                 */
                get onmenuitemselect() {
                    return this.handleselect;
                }
                /**
                 * This function triggers the menu select event
                 *
                 * @private
                 * @param {TagEventType} e
                 * @memberof MenuTag
                 */
                handleselect(e) {
                    if (this.context) {
                        $(this).hide();
                    }
                    e.id = this.aid;
                    this._onmenuselect(e);
                    this.observable.trigger("menuselect", e);
                }
                /**
                 * Show the current menu. This function is called
                 * only if the current menu is a context menu
                 *
                 * @param {JQuery.MouseEventBase} e JQuery mouse event
                 * @returns {void}
                 * @memberof MenuTag
                 */
                show(e) {
                    if (!this.context) {
                        return;
                    }
                    $(this)
                        .css("top", e.clientY - 15 + "px")
                        .css("left", e.clientX - 5 + "px")
                        .show();
                }
                /**
                 * Test whether the current menu is the root menu
                 *
                 * @private
                 * @returns {boolean}
                 * @memberof MenuTag
                 */
                is_root() {
                    return this.root === undefined;
                }
                /**
                 * Mount the menu tag and bind some basic events
                 *
                 * @protected
                 * @returns {void}
                 * @memberof MenuTag
                 */
                mount() {
                    $(this.refs.container).css("display", "contents");
                    if (!this.context) {
                        return;
                    }
                    $(this.refs.wrapper).on("mouseleave", (e) => {
                        if (!this.is_root()) {
                            return;
                        }
                        return $(this).hide();
                    });
                }
                /**
                 * Add a menu entry to the beginning of the current
                 * menu
                 *
                 * @param {GenericObject<any>} item menu entry data
                 * @memberof MenuTag
                 */
                unshift(item) {
                    this.push(item, true);
                }
                /**
                 * Delete a menu entry
                 *
                 * @param {MenuEntryTag} item reference to the DOM element of an menu entry
                 * @memberof MenuTag
                 */
                delete(item) {
                    const el = item.data;
                    const data = this.items;
                    if (data.includes(el)) {
                        data.splice(data.indexOf(el), 1);
                    }
                    $(item).remove();
                }
                /**
                 * Add an menu entry to the beginning or end of the menu
                 *
                 * @param {GenericObject<any>} item menu entry data
                 * @param {boolean} flag indicates whether the entry should be added to the beginning of the menu
                 * @returns {MenuEntryTag}
                 * @memberof MenuTag
                 */
                push(item, flag) {
                    let tag = this.contentag;
                    if (item.tag) {
                        tag = item.tag;
                    }
                    const el = $(`<${tag}>`);
                    if (flag) {
                        $(this.refs.container).prepend(el[0]);
                        if (!this.items.includes(item)) {
                            this.items.unshift(item);
                        }
                    }
                    else {
                        el.appendTo(this.refs.container);
                        if (!this.items.includes(item)) {
                            this.items.push(item);
                        }
                    }
                    const entry = el[0];
                    entry.uify(this.observable);
                    entry.parent = this.parent;
                    entry.root = this.parent ? this.parent.root : this;
                    entry.data = item;
                    item.domel = entry;
                    return entry;
                }
                /**
                 * Menu tag layout definition
                 *
                 * @returns
                 * @memberof MenuTag
                 */
                layout() {
                    return [
                        {
                            el: "ul",
                            ref: "wrapper",
                            children: [
                                { el: "li", class: "afx-corner-fix" },
                                { el: "div", ref: "container" },
                                { el: "li", class: "afx-corner-fix" },
                            ],
                        },
                    ];
                }
            }
            tag_1.MenuTag = MenuTag;
            tag_1.define("afx-menu", MenuTag);
            tag_1.define("afx-menu-entry", SimpleMenuEntryTag);
        })(tag = GUI.tag || (GUI.tag = {}));
    })(GUI = OS.GUI || (OS.GUI = {}));
})(OS || (OS = {}));

var OS;
(function (OS) {
    let GUI;
    (function (GUI) {
        let tag;
        (function (tag_1) {
            /**
             * A grid Row is a simple element that
             * contains a group of grid cell
             *
             * @export
             * @class GridRowTag
             * @extends {AFXTag}
             */
            class GridRowTag extends GUI.AFXTag {
                /**
                 *Creates an instance of GridRowTag.
                 * @memberof GridRowTag
                 */
                constructor() {
                    super();
                    this.refs.yield = this;
                    this._onselect = (e) => { };
                }
                /**
                 * Set item select event handle
                 *
                 * @memberof ListViewItemTag
                 */
                set onrowselect(v) {
                    this._onselect = v;
                }
                /**
                 * Setter: select/unselect the current item
                 *
                 * Getter: Check whether the current item is selected
                 *
                 * @memberof ListViewItemTag
                 */
                set selected(v) {
                    this.attsw(v, "selected");
                    $(this).removeClass();
                    if (!v) {
                        return;
                    }
                    $(this).addClass("afx-grid-row-selected");
                    this._onselect({ id: this.aid, data: this });
                }
                get selected() {
                    return this.hasattr("selected");
                }
                /**
                 * Mount the tag, do nothing
                 *
                 * @protected
                 * @memberof GridRowTag
                 */
                mount() { }
                /**
                 * Init the tag before mounting: reset the data placeholder
                 *
                 * @protected
                 * @memberof GridRowTag
                 */
                init() {
                    this.data = [];
                }
                /**
                 * Empty layout
                 *
                 * @protected
                 * @returns {TagLayoutType[]}
                 * @memberof GridRowTag
                 */
                layout() {
                    return [];
                }
                /**
                 * This function does nothing in this tag
                 *
                 * @protected
                 * @memberof GridRowTag
                 */
                calibrate() { }
                /**
                 * This function does nothing in this tag
                 *
                 * @protected
                 * @param {*} [d]
                 * @memberof GridRowTag
                 */
                reload(d) { }
            }
            tag_1.GridRowTag = GridRowTag;
            /**
             * Prototype of any grid cell, custom grid cell
             * definition should extend and implement this
             * abstract prototype
             *
             * @export
             * @abstract
             * @class GridCellPrototype
             * @extends {AFXTag}
             */
            class GridCellPrototype extends GUI.AFXTag {
                /**
                 *Creates an instance of GridCellPrototype.
                 * @memberof GridCellPrototype
                 */
                constructor() {
                    super();
                }
                /**
                 * Set the cell selected event callback
                 *
                 * @memberof GridCellPrototype
                 */
                set oncellselect(v) {
                    this._oncellselect = v;
                }
                /**
                 * Set the cell double click event callback
                 *
                 * @memberof GridCellPrototype
                 */
                set oncelldbclick(v) {
                    this._oncelldbclick = v;
                }
                /**
                 * Setter:
                 *
                 * Set the data of the cell, this will trigger
                 * the [[ondatachange]] function
                 *
                 * Getter:
                 *
                 * Get the current cell data placeholder
                 *
                 * @memberof GridCellPrototype
                 */
                set data(v) {
                    if (!v)
                        return;
                    this._data = v;
                    this.ondatachange();
                    if (!v.selected) {
                        return;
                    }
                    this.selected = v.selected;
                }
                get data() {
                    return this._data;
                }
                /**
                 * Setter:
                 *
                 * Set/unset the current cell as selected.
                 * This will trigger the [[cellselect]]
                 * event
                 *
                 * Getter:
                 *
                 * Check whether the current cell is selected
                 *
                 * @memberof GridCellPrototype
                 */
                set selected(v) {
                    this.attsw(v, "selected");
                    if (this._data)
                        this._data.selected = v;
                    if (!v) {
                        return;
                    }
                    this.cellselect({ id: this.aid, data: this }, false);
                }
                get selected() {
                    return this.hasattr("selected");
                }
                /**
                 * Update the current cell. This will
                 * reset the cell data
                 *
                 * @protected
                 * @param {*} d
                 * @memberof GridCellPrototype
                 */
                reload(d) {
                    this.data = this.data;
                }
                /**
                 * Mount the current cell to the grid
                 *
                 * @protected
                 * @memberof GridCellPrototype
                 */
                mount() {
                    $(this).attr("class", "afx-grid-cell");
                    this.oncelldbclick = this.oncellselect = (e) => { };
                    this.selected = false;
                    //$(this).css("display", "block");
                    $(this).on("click", (e) => {
                        let evt = { id: this.aid, data: this };
                        return this.cellselect(evt, false);
                    });
                    $(this).on("dblclick", (e) => {
                        let evt = { id: this.aid, data: this };
                        return this.cellselect(evt, true);
                    });
                }
                /**
                 * This function triggers the cell select
                 * event
                 *
                 * @private
                 * @param {TagEventType<GridCellPrototype>} e
                 * @param {boolean} flag
                 * @returns {void}
                 * @memberof GridCellPrototype
                 */
                cellselect(e, flag) {
                    const evt = { id: this.aid, data: { item: e.data } };
                    if (!flag) {
                        return this._oncellselect(evt);
                    }
                    return this._oncelldbclick(evt);
                }
            }
            tag_1.GridCellPrototype = GridCellPrototype;
            /**
             * Simple grid cell defines a grid cell with
             * an [[LabelTag]] as it cell layout
             *
             * @export
             * @class SimpleGridCellTag
             * @extends {GridCellPrototype}
             */
            class SimpleGridCellTag extends GridCellPrototype {
                /**
                 *Creates an instance of SimpleGridCellTag.
                 * @memberof SimpleGridCellTag
                 */
                constructor() {
                    super();
                }
                /**
                 * Reset the label of the cell with its data
                 *
                 * @protected
                 * @memberof SimpleGridCellTag
                 */
                ondatachange() {
                    const label = this.refs.cell;
                    label.icon = undefined;
                    label.iconclass = undefined;
                    this.refs.cell.set(this.data);
                }
                /**
                 * This function do nothing in this tag
                 *
                 * @protected
                 * @memberof SimpleGridCellTag
                 */
                init() { }
                /**
                 * This function do nothing in this tag
                 *
                 * @protected
                 * @memberof SimpleGridCellTag
                 */
                calibrate() { }
                /**
                 * The layout of the cell with a simple [[LabelTag]]
                 *
                 * @returns
                 * @memberof SimpleGridCellTag
                 */
                layout() {
                    return [
                        {
                            el: "afx-label",
                            ref: "cell",
                        },
                    ];
                }
            }
            tag_1.SimpleGridCellTag = SimpleGridCellTag;
            /**
             * A Grid contains a header and a collection grid rows
             * which has the same number of cells as the number of
             * the header elements
             *
             * @export
             * @class GridViewTag
             * @extends {AFXTag}
             */
            class GridViewTag extends GUI.AFXTag {
                /**
                 * Creates an instance of GridViewTag.
                 * @memberof GridViewTag
                 */
                constructor() {
                    super();
                }
                /**
                 * Set drag and drop event handle
                 *
                 * @memberof GridViewTag
                 */
                set ondragndrop(v) {
                    this._ondragndrop = v;
                    this.dragndrop = this.dragndrop;
                }
                /**
                 * Setter: Enable/disable drag and drop event in the list
                 *
                 * Getter: Check whether the drag and drop event is enabled
                 *
                 * @memberof GridViewTag
                 */
                set dragndrop(v) {
                    this.attsw(v, "dragndrop");
                    if (!v) {
                        $(this.refs.container).off("mousedown", this._onmousedown);
                    }
                    else {
                        $(this.refs.container).on("mousedown", this._onmousedown);
                    }
                }
                get dragndrop() {
                    return this.hasattr("dragndrop");
                }
                /**
                 * Init the grid view before mounting.
                 * Reset all the placeholders to default values
                 *
                 * @protected
                 * @memberof GridViewTag
                 */
                init() {
                    this._header = [];
                    this.headeritem = "afx-grid-cell";
                    this.cellitem = "afx-grid-cell";
                    this._selectedCell = undefined;
                    this._selectedRows = [];
                    this._selectedRow = undefined;
                    this._rows = [];
                    this.resizable = false;
                    this.dragndrop = false;
                    this._oncellselect = this._onrowselect = this._oncelldbclick = (e) => { };
                    this._ondragndrop = (e) => { };
                }
                /**
                 * This function does nothing
                 *
                 * @protected
                 * @param {*} [d]
                 * @memberof GridViewTag
                 */
                reload(d) { }
                /**
                 * set the cell select event callback
                 *
                 * @memberof GridViewTag
                 */
                set oncellselect(v) {
                    this._oncellselect = v;
                }
                /**
                 * set the row select event callback
                 *
                 * @memberof GridViewTag
                 */
                set onrowselect(v) {
                    this._onrowselect = v;
                }
                /**
                 * set the cell double click event callback
                 *
                 * @memberof GridViewTag
                 */
                set oncelldbclick(v) {
                    this._oncelldbclick = v;
                }
                /**
                 * Setter: set the tag name of the header cells
                 *
                 * Getter: get the grid header tag name
                 *
                 * @memberof GridViewTag
                 */
                set headeritem(v) {
                    $(this).attr("headeritem", v);
                }
                get headeritem() {
                    return $(this).attr("headeritem");
                }
                /**
                 * Setter: set the tag name of the grid cell
                 *
                 * Getter: get the tag name of the grid cell
                 *
                 * @memberof GridViewTag
                 */
                set cellitem(v) {
                    const currci = this.cellitem;
                    $(this).attr("cellitem", v);
                    if (v != currci) {
                        // force render data
                        $(this.refs.grid).empty();
                        this.rows = this.rows;
                    }
                }
                get cellitem() {
                    return $(this).attr("cellitem");
                }
                /**
                 * Setter: set the header data
                 *
                 * Getter: get the header data placeholder
                 *
                 * @type {GenericObject<any>[]}
                 * @memberof GridViewTag
                 */
                get header() {
                    return this._header;
                }
                set header(v) {
                    this._header = v;
                    if (!v || v.length === 0) {
                        $(this.refs.header).hide();
                        return;
                    }
                    $(this.refs.header).empty();
                    let i = 0;
                    for (let item of v) {
                        const element = $(`<${this.headeritem}>`).appendTo(this.refs.header)[0];
                        element.uify(this.observable);
                        element.data = item;
                        item.domel = element;
                        element.oncellselect = (e) => {
                            if (element.data.sort) {
                                this.sort(element.data, element.data.sort);
                                if (element.data.desc) {
                                    $(element).attr("sort", "desc");
                                }
                                else {
                                    $(element).attr("sort", "asc");
                                }
                            }
                        };
                        i++;
                        if (this.resizable) {
                            if (i != v.length) {
                                const rz = $(`<afx-resizer>`).appendTo(this.refs.header)[0];
                                $(rz).css("width", "3px");
                                let next_item = undefined;
                                if (i < v.length) {
                                    next_item = v[i];
                                }
                                rz.onelresize = (e) => {
                                    item.width = e.data.w + 3;
                                    if (next_item) {
                                        delete next_item.width;
                                    }
                                };
                                rz.uify(this.observable);
                            }
                        }
                    }
                    this.calibrate();
                }
                /**
                 * Get all the selected rows
                 *
                 * @readonly
                 * @type {GridRowTag[]}
                 * @memberof GridViewTag
                 */
                get selectedRows() {
                    return this._selectedRows;
                }
                /**
                 * Get the latest selected row
                 *
                 * @readonly
                 * @type {GridRowTag}
                 * @memberof GridViewTag
                 */
                get selectedRow() {
                    return this._selectedRow;
                }
                /**
                 * Get the current selected cell
                 *
                 * @readonly
                 * @type {GridCellPrototype}
                 * @memberof GridViewTag
                 */
                get selectedCell() {
                    return this._selectedCell;
                }
                /**
                 * Setter: set the rows data
                 *
                 * Getter: get the rows data
                 *
                 * @memberof GridViewTag
                 */
                set rows(rows) {
                    this._rows = rows;
                    if (!rows)
                        return;
                    for (const el of this._header) {
                        $(el.domel).attr("sort", "none");
                    }
                    // update existing row with new data
                    const ndrows = rows.length;
                    const ncrows = this.refs.grid.children.length;
                    const nmin = ndrows < ncrows ? ndrows : ncrows;
                    if (this.selectedRow) {
                        this.selectedRow.selected = false;
                        this._selectedRow = undefined;
                        this._selectedRows = [];
                    }
                    for (let i = 0; i < nmin; i++) {
                        const rowel = this.refs.grid.children[i];
                        rowel.data = rows[i];
                        rowel.data.domel = rowel;
                        for (let celi = 0; celi < rowel.children.length; celi++) {
                            const cel = rowel.children[celi];
                            cel.data = rows[i][celi];
                            cel.data.domel = cel;
                        }
                    }
                    // remove existing remaining rows
                    if (ndrows < ncrows) {
                        const arr = Array.prototype.slice.call(this.refs.grid.children);
                        const blacklist = arr.slice(nmin, ncrows);
                        for (const r of blacklist) {
                            this.delete(r);
                        }
                    }
                    // or add more rows
                    else if (ndrows > ncrows) {
                        for (let i = nmin; i < ndrows; i++) {
                            this.push(rows[i], false);
                        }
                    }
                }
                get rows() {
                    return this._rows;
                }
                /**
                 * Setter: activate deactivate multi-select
                 *
                 * Getter: check whether the `multiselect` option is activated
                 *
                 * @memberof GridViewTag
                 */
                set multiselect(v) {
                    this.attsw(v, "multiselect");
                }
                get multiselect() {
                    return this.hasattr("multiselect");
                }
                /**
                 * Set and Get the resizable attribute
                 *
                 * This allows to enable/disable column resize feature
                 *
                 * @memberof GridViewTag
                 */
                set resizable(v) {
                    this.attsw(v, "resizable");
                }
                get resizable() {
                    return this.hasattr("resizable");
                }
                /**
                * Sort the grid using a sort function
                *
                * @param {context: any} context of the executed function
                * @param {(a:GenericObject<any>[], b:GenericObject<any>[]) => boolean} a sort function that compares two rows data
                * * @param {index: number} current header index
                * @returns {void}
                * @memberof GridViewTag
                */
                sort(context, fn) {
                    const index = this._header.indexOf(context);
                    const __fn = (a, b) => {
                        return fn.call(context, a, b, index);
                    };
                    this._rows.sort(__fn);
                    context.desc = !context.desc;
                    this.rows = this._rows;
                }
                /**
                 * Delete a grid rows
                 *
                 * @param {GridRowTag} row row DOM element
                 * @returns {void}
                 * @memberof GridViewTag
                 */
                delete(row) {
                    if (!row) {
                        return;
                    }
                    const rowdata = row.data;
                    const data = this.rows;
                    if (this.selectedRow === row) {
                        this._selectedRow = undefined;
                    }
                    let parentRow = $(this.selectedCell).parent()[0];
                    if (parentRow === row) {
                        this._selectedCell = undefined;
                    }
                    const list = this.selectedRows;
                    if (list.includes(row)) {
                        list.splice(list.indexOf(row), 1);
                    }
                    if (data.includes(rowdata)) {
                        data.splice(data.indexOf(rowdata), 1);
                    }
                    $(row).remove();
                }
                /**
                 * Push a row to the grid
                 *
                 * @param {GenericObject<any>[]} row list of cell data
                 * @param {boolean} flag indicates where the row is add to beginning or end
                 * of the row
                 * @memberof GridViewTags
                 */
                push(row, flag) {
                    const rowel = $("<afx-grid-row>").css("display", "contents");
                    if (flag) {
                        $(this.refs.grid).prepend(rowel[0]);
                        if (!this.rows.includes(row)) {
                            this.rows.unshift(row);
                        }
                    }
                    else {
                        rowel.appendTo(this.refs.grid);
                        if (!this.rows.includes(row)) {
                            this.rows.push(row);
                        }
                    }
                    const el = rowel[0];
                    rowel[0].uify(this.observable);
                    el.data = row;
                    row.domel = rowel[0];
                    for (let cell of row) {
                        let tag = this.cellitem;
                        if (cell.tag) {
                            ({ tag } = cell);
                        }
                        const el = $(`<${tag}>`).appendTo(rowel);
                        cell.domel = el[0];
                        const element = el[0];
                        element.uify(this.observable);
                        element.oncellselect = (e) => this.cellselect(e, false);
                        element.oncelldbclick = (e) => this.cellselect(e, true);
                        element.data = cell;
                    }
                    el.onrowselect = (e) => this.rowselect({
                        id: el.aid,
                        data: { item: el }
                    });
                }
                /**
                 * Unshift a row to the grid
                 *
                 * @param {GenericObject<any>[]} row list of cell data in the row
                 * @memberof GridViewTag
                 */
                unshift(row) {
                    this.push(row, true);
                }
                /**
                 * This function triggers the cell select event
                 *
                 * @private
                 * @param {TagEventType<CellEventData>} e event contains cell event data
                 * @param {boolean} flag indicates whether the event is double clicked
                 * @returns {void}
                 * @memberof GridViewTag
                 */
                cellselect(e, flag) {
                    e.id = this.aid;
                    // return if e.data.item is selectedCell and not flag
                    if (this.selectedCell) {
                        $(this.selectedCell).attr("class", "afx-grid-cell");
                    }
                    this._selectedCell = e.data.item;
                    $(e.data.item).addClass("afx-grid-cell-selected");
                    if (flag) {
                        this.observable.trigger("celldbclick", e);
                        return this._oncelldbclick(e);
                    }
                    else {
                        this.observable.trigger("cellselect", e);
                        this._oncellselect(e);
                        const row = $(e.data.item).parent()[0];
                        row.selected = true;
                    }
                }
                /**
                 * This function triggers the row select event, a cell select
                 * event will also trigger this event
                 *
                 * @param {TagEventType<GridRowEventData>} e
                 * @returns {void}
                 * @memberof GridViewTag
                 */
                rowselect(e) {
                    if (!e.data.item) {
                        return;
                    }
                    const evt = {
                        id: this.aid,
                        data: {
                            item: undefined,
                            items: [],
                        },
                    };
                    const row = e.data.item;
                    if (this.multiselect) {
                        if (this.selectedRows.includes(row)) {
                            this.selectedRows.splice(this.selectedRows.indexOf(row), 1);
                            row.selected = false;
                            return;
                        }
                        else {
                            this.selectedRows.push(row);
                        }
                        evt.data.items = this.selectedRows;
                    }
                    else {
                        if (this.selectedRows.length > 0) {
                            for (const item of this.selectedRows) {
                                if (item != row) {
                                    item.selected = false;
                                }
                            }
                        }
                        if (this.selectedRow === row) {
                            return;
                        }
                        if (this.selectedRow)
                            this.selectedRow.selected = false;
                        evt.data.items = [row];
                        this._selectedRows = [row];
                    }
                    evt.data.item = row;
                    this._selectedRow = row;
                    this._onrowselect(evt);
                    return this.observable.trigger("rowselect", evt);
                }
                /**
                 * Unselect all the selected rows in the grid
                 *
                 * @returns {void}
                 * @memberof GridViewTag
                 */
                unselect() {
                    for (let v of this.selectedRows) {
                        v.selected = false;
                    }
                    this._selectedRows = [];
                    this._selectedRow = undefined;
                }
                /**
                 * Check whether the grid has header
                 *
                 * @private
                 * @returns {boolean}
                 * @memberof GridViewTag
                 */
                has_header() {
                    const h = this._header;
                    return h && h.length > 0;
                }
                /**
                 * Calibrate the grid
                 *
                 * @protected
                 * @memberof GridViewTag
                 */
                calibrate() {
                    this.calibrate_header();
                    if (this.has_header()) {
                        $(this.refs.container).css("height", $(this).height() -
                            $(this.refs.header).height() +
                            "px");
                    }
                    else {
                        $(this.refs.container).css("height", $(this).height() + "px");
                    }
                }
                /**
                 * Recalculate the size of each header cell, changing
                 * in header cell size will also resize the entire
                 * related column
                 *
                 * @private
                 * @returns {void}
                 * @memberof GridViewTag
                 */
                calibrate_header() {
                    if (!this.has_header()) {
                        return;
                    }
                    const colssize = [];
                    let ocw = 0;
                    let nauto = 0;
                    const totalw = $(this).parent().width();
                    $.each(this._header, function (i, item) {
                        if (item.width) {
                            colssize.push(item.width);
                            return (ocw += item.width);
                        }
                        else {
                            colssize.push(-1);
                            return nauto++;
                        }
                    });
                    if (nauto > 0) {
                        const cellw = Math.round((totalw - ocw) / nauto);
                        $.each(colssize, function (i, e) {
                            if (e !== -1) {
                                return;
                            }
                            return (colssize[i] = cellw);
                        });
                    }
                    let template = "";
                    let template_header = "";
                    let i = 0;
                    for (let v of colssize) {
                        template += `${v}px `;
                        i++;
                        template_header += `${v}px `;
                        if (i < colssize.length && this.resizable) {
                            template_header += "3px ";
                        }
                    }
                    $(this.refs.grid).css("grid-template-columns", template);
                    $(this.refs.header).css("grid-template-columns", template_header);
                }
                /**
                 * Mount the grid view tag
                 *
                 * @protected
                 * @returns {void}
                 * @memberof GridViewTag
                 */
                mount() {
                    $(this).css("overflow", "hidden");
                    $(this.refs.grid).css("display", "grid");
                    $(this.refs.header).css("display", "grid");
                    this.observable.on("resize", (e) => this.calibrate());
                    $(this.refs.container)
                        .css("width", "100%")
                        .css("overflow-x", "hidden")
                        .css("overflow-y", "auto");
                    // drag and drop
                    this._dnd = {
                        from: undefined,
                        to: undefined,
                    };
                    this._onmousedown = (e) => {
                        if (this.multiselect || this.selectedRows == undefined || this.selectedRows.length == 0) {
                            return;
                        }
                        let el = $(e.target).closest("afx-grid-row");
                        if (el.length === 0) {
                            return;
                        }
                        el = el[0];
                        if (!this.selectedRows.includes(el)) {
                            return;
                        }
                        this._dnd.from = this.selectedRows;
                        this._dnd.to = undefined;
                        $(window).on("mouseup", this._onmouseup);
                        $(window).on("mousemove", this._onmousemove);
                    };
                    this._onmouseup = (e) => {
                        $(window).off("mouseup", this._onmouseup);
                        $(window).off("mousemove", this._onmousemove);
                        $("#systooltip").hide();
                        let el = $(e.target).closest("afx-grid-row");
                        if (el.length === 0) {
                            return;
                        }
                        el = el[0];
                        if (this._dnd.from.includes(el)) {
                            return;
                        }
                        this._dnd.to = el;
                        this._ondragndrop({ id: this.aid, data: this._dnd });
                        this._dnd = {
                            from: undefined,
                            to: undefined,
                        };
                    };
                    this._onmousemove = (e) => {
                        if (!e) {
                            return;
                        }
                        if (!this._dnd.from) {
                            return;
                        }
                        const data = {
                            text: __("{0} selected elements", this._dnd.from.length).__(),
                            items: this._dnd.from
                        };
                        const $label = $("#systooltip");
                        const top = e.clientY + 5;
                        const left = e.clientX + 5;
                        $label.show();
                        const label = $label[0];
                        label.set(data);
                        return $label
                            .css("top", top + "px")
                            .css("left", left + "px");
                    };
                    return this.calibrate();
                }
                /**
                 * Layout definition of the grid view
                 *
                 * @protected
                 * @returns {TagLayoutType[]}
                 * @memberof GridViewTag
                 */
                layout() {
                    return [
                        { el: "div", ref: "header", class: "grid_row_header" },
                        {
                            el: "div",
                            ref: "container",
                            children: [{ el: "div", ref: "grid" }],
                        },
                    ];
                }
            }
            tag_1.GridViewTag = GridViewTag;
            tag_1.define("afx-grid-view", GridViewTag);
            tag_1.define("afx-grid-cell", SimpleGridCellTag);
            tag_1.define("afx-grid-row", GridRowTag);
        })(tag = GUI.tag || (GUI.tag = {}));
    })(GUI = OS.GUI || (OS.GUI = {}));
})(OS || (OS = {}));

var OS;
(function (OS) {
    let GUI;
    (function (GUI) {
        let tag;
        (function (tag) {
            /**
             * a TabBar allows to control a collection of tabs
             *
             * @export
             * @class TabBarTag
             * @extends {AFXTag}
             */
            class TabBarTag extends GUI.AFXTag {
                /**
                 *Creates an instance of TabBarTag.
                 * @memberof TabBarTag
                 */
                constructor() {
                    super();
                    this._ontabclose = (e) => true;
                    this._ontabselect = (e) => { };
                }
                /**
                 * Init the tag
                 *
                 * @protected
                 * @memberof TabBarTag
                 */
                init() {
                    this.selected = -1;
                    this.dir = "horizontal";
                    this._previous_touch = { x: 0, y: 0 };
                }
                /**
                 * Do nothing
                 *
                 * @protected
                 * @param {*} [d]
                 * @memberof TabBarTag
                 */
                reload(d) { }
                /**
                 * Setter: Enable/disable a tab to be closed
                 *
                 * Getter: Check whether tabs can be closed
                 *
                 * @memberof TabBarTag
                 */
                set closable(v) {
                    this.attsw(v, "closable");
                }
                get closable() {
                    return this.hasattr("closable");
                }
                /**
                 * Setter:
                 *
                 * Set the tab bar direction:
                 * - `horizontal`: horizontal direction
                 * - `vertical`: vertical direction
                 *
                 * Getter:
                 *
                 * Get the tab bar direction
                 *
                 * @memberof TabBarTag
                 */
                set dir(v) {
                    $(this).attr("dir", v);
                    if (!v) {
                        return;
                    }
                    this.refs.list.dir = v;
                }
                get dir() {
                    return $(this).attr("dir");
                }
                /**
                 * Add a tab in the end of the tab bar
                 *
                 * @param {GenericObject<any>} item tab data
                 * @memberof TabBarTag
                 */
                push(item) {
                    item.closable = this.closable;
                    return this.refs.list.push(item);
                }
                /**
                 * Delete a tab
                 *
                 * @param {ListViewItemTag} el reference to DOM element of a tab
                 * @memberof TabBarTag
                 */
                delete(el) {
                    this.refs.list.delete(el);
                }
                /**
                 * Add a tab to the beginning of the tab bar
                 *
                 * @param {GenericObject<any>} item tab data
                 * @memberof TabBarTag
                 */
                unshift(item) {
                    item.closable = this.closable;
                    return this.refs.list.unshift(item);
                }
                /**
                 * Setter: Set tabs data
                 *
                 * Getter: Get all tabs data
                 *
                 * @memberof TabBarTag
                 */
                set items(v) {
                    for (let i of v) {
                        i.closable = this.closable;
                    }
                    this.refs.list.data = v;
                }
                get items() {
                    return this.refs.list.data;
                }
                /**
                 * Setter: Select a tab by its index
                 *
                 * Getter: Get the currently selected tab
                 *
                 * @memberof TabBarTag
                 */
                set selected(v) {
                    this.refs.list.selected = v;
                }
                get selected() {
                    return this.refs.list.selected;
                }
                /**
                 * Get the latest selected item
                 *
                 * @readonly
                 * @type {ListViewItemTag}
                 * @memberof TabBarTag
                 */
                get selectedItem() {
                    return this.refs.list.selectedItem;
                }
                /**
                 * Set the tab close event handle
                 *
                 * @memberof TabBarTag
                 */
                set ontabclose(v) {
                    this._ontabclose = v;
                }
                /**
                 * Set the tab select event handle
                 *
                 * @memberof TabBarTag
                 */
                set ontabselect(v) {
                    this._ontabselect = v;
                }
                /**
                 * Mount the tab bar and bind some basic events
                 *
                 * @protected
                 * @memberof TabBarTag
                 */
                mount() {
                    $(this.refs.list).css("height", "100%");
                    this.refs.list.onitemclose = (e) => {
                        e.id = this.aid;
                        return this._ontabclose(e);
                    };
                    this.refs.list.onlistselect = (e) => {
                        this._ontabselect(e);
                        return this.observable.trigger("tabselect", e);
                    };
                    const list_container = $(".list-container", this.refs.list);
                    list_container.each((i, el) => {
                        el.addEventListener("touchstart", e => {
                            this._previous_touch.x = e.touches[0].pageX;
                            this._previous_touch.y = e.touches[0].pageY;
                        }, { passive: true });
                        el.addEventListener("touchmove", e => {
                            const offset = { x: 0, y: 0 };
                            offset.x = this._previous_touch.x - e.touches[0].pageX;
                            offset.y = this._previous_touch.y - e.touches[0].pageY;
                            if (this.dir == "horizontal") {
                                el.scrollLeft += offset.x;
                            }
                            else {
                                el.scrollTop += offset.y;
                            }
                            this._previous_touch.x = e.touches[0].pageX;
                            this._previous_touch.y = e.touches[0].pageY;
                        }, { passive: true });
                        el.addEventListener("wheel", (evt) => {
                            if (this.dir == "horizontal") {
                                el.scrollLeft += evt.deltaY;
                            }
                            else {
                                el.scrollTop += evt.deltaY;
                            }
                        }, { passive: true });
                    });
                }
                /**
                 * TabBar layout definition
                 *
                 * @protected
                 * @returns {TagLayoutType[]}
                 * @memberof TabBarTag
                 */
                layout() {
                    return [
                        {
                            el: "afx-list-view",
                            ref: "list",
                        },
                    ];
                }
            }
            tag.TabBarTag = TabBarTag;
            tag.define("afx-tab-bar", TabBarTag);
        })(tag = GUI.tag || (GUI.tag = {}));
    })(GUI = OS.GUI || (OS.GUI = {}));
})(OS || (OS = {}));

var OS;
(function (OS) {
    let GUI;
    (function (GUI) {
        let tag;
        (function (tag) {
            /**
             * A tab container allows to attach each tab on a [[TabBarTag]]
             * with a container widget. The attached container widget should be
             * composed inside a [[HBoxTag]]
             *
             * The tab bar in a tab container can be configured to display tabs
             * in horizontal (row) or vertical (column) order. Default to vertical order
             *
             * Once a tab is selected, its attached container will be shown
             *
             * @export
             * @class TabContainerTag
             * @extends {AFXTag}
             */
            class TabContainerTag extends GUI.AFXTag {
                /**
                 *Creates an instance of TabContainerTag.
                 * @memberof TabContainerTag
                 */
                constructor() {
                    super();
                    this._ontabselect = (e) => { };
                }
                /**
                 * Init the tab bar direction to vertical (column)
                 *
                 * @protected
                 * @memberof TabContainerTag
                 */
                init() {
                    this.dir = "column"; // or row
                }
                /**
                 * Do nothing
                 *
                 * @protected
                 * @param {*} [d]
                 * @memberof TabContainerTag
                 */
                reload(d) { }
                /**
                 * Set the tab select event handle
                 *
                 * @memberof TabContainerTag
                 */
                set ontabselect(f) {
                    this._ontabselect = f;
                }
                /**
                 * Get all tab items in the container
                 *
                 * @readonly
                 * @type {TabContainerTabType[]}
                 * @memberof TabContainerTag
                 */
                get tabs() {
                    return this.refs.bar.items;
                }
                /**
                 * Setter: Select a tab by its index
                 * Getter: Get the current selected index
                 *
                 * @memberof TabContainerTag
                 */
                set selectedIndex(i) {
                    this.refs.bar.selected = i;
                }
                get selectedIndex() {
                    return this.refs.bar.selected;
                }
                /**
                 * Setter:
                 *
                 * Set the tab bar direction:
                 * - `row`: horizontal direction
                 * - `column`: vertical direction
                 *
                 * Getter:
                 *
                 * Get the tab bar direction
                 *
                 * @memberof TabContainerTag
                 */
                set dir(v) {
                    $(this).attr("dir", v);
                    if (!v) {
                        return;
                    }
                    this.refs.wrapper.dir = v;
                    if (v === "row") {
                        this.refs.bar.dir = "vertical";
                    }
                    else {
                        this.refs.bar.dir = "horizontal";
                    }
                }
                get dir() {
                    return $(this).attr("dir");
                }
                /**
                 * Setter:
                 *
                 * Select a tab using the its tab data type.
                 * This will show the attached container to the tab
                 *
                 * Getter:
                 *
                 * Get the tab data of the currently selected Tab
                 *
                 * @memberof TabContainerTag
                 */
                set selectedTab(v) {
                    if (!v) {
                        return;
                    }
                    const selected = this._selectedTab;
                    this._selectedTab = v;
                    if (selected) {
                        $(selected.container).hide();
                    }
                    $(v.container).show();
                    this.observable.trigger("resize", undefined);
                    $(v.container).attr("tabindex", -1).css("outline", "none").trigger("focus");
                }
                get selectedTab() {
                    return this._selectedTab;
                }
                /**
                 * Set the tab bar width, this function only
                 * works when the tab bar direction is set to
                 * `row`
                 *
                 * @memberof TabContainerTag
                 */
                set tabbarwidth(v) {
                    if (!v) {
                        return;
                    }
                    $(this.refs.bar).attr("data-width", `${v}`);
                    this.observable.trigger("resize", undefined);
                }
                /**
                 * Set the tab bar height, this function only works
                 * when the tab bar direction is set to `column`
                 *
                 * @memberof TabContainerTag
                 */
                set tabbarheight(v) {
                    if (!v) {
                        return;
                    }
                    $(this.refs.bar).attr("data-height", `${v}`);
                    this.observable.trigger("resize", undefined);
                }
                /**
                 * Add a new tab with container to the container
                 *
                 * item should be in the following format:
                 *
                 * ```ts
                 * {
                 *  text: string,
                 *  icon?: string,
                 *  iconclass?: string,
                 *  container: HTMLElement
                 * }
                 * ```
                 *
                 * @param {GenericObject<any>} item tab descriptor
                 * @param {boolean} insert insert the tab content to the container ?
                 * @returns {ListViewItemTag} the tab DOM element
                 * @memberof TabContainerTag
                 */
                addTab(item, insert) {
                    if (insert) {
                        $(this.refs.yield).append(item.container);
                    }
                    $(item.container)
                        .css("width", "100%")
                        .css("height", "100%")
                        .hide();
                    const el = this.refs.bar.push(item);
                    el.selected = true;
                    return el;
                }
                /**
                 * Remove a tab from the container
                 *
                 * @param {ListViewItemTag} tab the tab item to be removed
                 * @memberof TabContainerTag
                 */
                removeTab(tab) {
                    if (tab.data.container) {
                        $(tab.data.container).remove();
                    }
                    this.refs.bar.delete(tab);
                }
                /**
                 * Mount the tag and bind basic events
                 *
                 * @protected
                 * @memberof TabContainerTag
                 */
                mount() {
                    this.refs.bar.ontabselect = (e) => {
                        const data = e.data.item
                            .data;
                        this.selectedTab = data;
                        return this._ontabselect({ data: data, id: this.aid });
                    };
                    this.observable.one("mounted", (id) => {
                        $(this.refs.yield)
                            .children()
                            .each((i, e) => {
                            const item = {};
                            if ($(e).attr("tabname")) {
                                item.text = $(e).attr("tabname");
                            }
                            if ($(e).attr("icon")) {
                                item.icon = $(e).attr("icon");
                            }
                            if ($(e).attr("iconclass")) {
                                item.iconclass = $(e).attr("iconclass");
                            }
                            item.container = e;
                            this.addTab(item, false);
                        });
                    });
                    this.observable.on("resize", (e) => this.calibrate());
                    this.calibrate();
                }
                /**
                 * calibrate the  tab container
                 *
                 * @memberof TabContainerTag
                 */
                calibrate() {
                    $(this.refs.wrapper).css("height", `${$(this).height()}px`);
                }
                /**
                 * Layout definition
                 *
                 * @protected
                 * @returns {TagLayoutType[]}
                 * @memberof TabContainerTag
                 */
                layout() {
                    return [
                        {
                            el: "afx-tile",
                            ref: "wrapper",
                            children: [
                                { el: "afx-tab-bar", ref: "bar" },
                                { el: "div", ref: "yield" },
                            ],
                        },
                    ];
                }
            }
            tag.TabContainerTag = TabContainerTag;
            tag.define("afx-tab-container", TabContainerTag);
        })(tag = GUI.tag || (GUI.tag = {}));
    })(GUI = OS.GUI || (OS.GUI = {}));
})(OS || (OS = {}));

var OS;
(function (OS) {
    let GUI;
    (function (GUI) {
        let tag;
        (function (tag_1) {
            /**
             * Abstract prototype of a tree node. All tree node definition should
             * extend this class
             *
             * @class TreeViewItemPrototype
             * @extends {AFXTag}
             */
            class TreeViewItemPrototype extends GUI.AFXTag {
                /**
                 *Creates an instance of TreeViewItemPrototype.
                 * @memberof TreeViewItemPrototype
                 */
                constructor() {
                    super();
                }
                /**
                 * Update the tree, this function
                 * is used to refresh/expand/collapse the
                 * current node based on the input parameter
                 *
                 * @protected
                 * @param {*} p string indication, the value should be:
                 * - `expand`: expand the current node
                 * - `collapse`: collapse the current node
                 * - other string: this string is considered as a tree path of a node. If this value
                 * is the value of current node tree path, the node will be refreshed. Otherwise, nothing
                 * happens
                 * @returns {void}
                 * @memberof TreeViewItemPrototype
                 */
                reload(p) {
                    if (!p || typeof p !== "string") {
                        return;
                    }
                    switch (p) {
                        case "expand":
                            this.open = true;
                            break;
                        case "collapse":
                            this.open = false;
                            break;
                        default:
                            if (p !== this.treepath) {
                                return;
                            }
                            this.open = true;
                    }
                }
                /**
                 * Setter:
                 *
                 * Set the data of the current node. This will trigger the
                 * [[ondatachange]] function
                 *
                 * Getter:
                 *
                 * Get the current node's data
                 *
                 * @memberof TreeViewItemPrototype
                 */
                set data(v) {
                    this._data = v;
                    if (!v) {
                        return;
                    }
                    this.open = v.open;
                    if (v.path) {
                        this.treepath = v.path;
                    }
                    this.selected = v.selected;
                    v.domel = this;
                    this.ondatachange();
                }
                get data() {
                    return this._data;
                }
                /**
                 * Setter:
                 *
                 * Select or unselect the current node.
                 * This will trigger the item select event
                 * on the tree root if the parameter is `true`
                 *
                 * Getter:
                 *
                 * Check whether the current node is selected
                 *
                 * @memberof TreeViewItemPrototype
                 */
                set selected(v) {
                    if (!this._data) {
                        return;
                    }
                    this.attsw(v, "selected");
                    $(this.refs.wrapper).removeClass();
                    this._data.selected = v;
                    if (v) {
                        this.treeroot.unselect();
                        // set selectedItem but not trigger the update
                        this.treeroot.itemclick(this._evt);
                        this._evt.data.dblclick = false;
                        $(this.refs.wrapper).addClass("afx_tree_item_selected");
                    }
                }
                get selected() {
                    return this.hasattr("selected");
                }
                /**
                 * Setter:
                 *
                 * Refresh the current node and expands its sub tree.
                 * This function only works if the current node is not
                 * a leaf node
                 *
                 * Getter:
                 *
                 * Check whether the current node is expanded
                 *
                 * @memberof TreeViewItemPrototype
                 */
                set open(v) {
                    if (!this.is_folder()) {
                        return;
                    }
                    this.attsw(v, "open");
                    $(this.refs.toggle).removeClass();
                    if (v) {
                        if (this.fetch) {
                            this.fetch(this)
                                .then((d) => {
                                if (!d) {
                                    return;
                                }
                                return (this.nodes = d);
                            })
                                .catch((e) => OS.announcer.oserror(e.toString(), e));
                        }
                        else {
                            this.nodes = this.nodes;
                        }
                        $(this.refs.childnodes).show();
                    }
                    else {
                        $(this.refs.childnodes).hide();
                    }
                    if (v) {
                        $(this.refs.toggle).addClass("afx-tree-view-folder-open");
                    }
                    else {
                        $(this.refs.toggle).addClass("afx-tree-view-folder-close");
                    }
                }
                get open() {
                    return this.hasattr("open");
                }
                /**
                 * Setter: Set the current indent level of this node from the root node
                 *
                 * Getter: Get the current indent level
                 *
                 * @type {number}
                 * @memberof TreeViewItemPrototype
                 */
                get indent() {
                    return this._indent;
                }
                set indent(v) {
                    if (!v) {
                        return;
                    }
                    this._indent = v;
                    $(this.refs.padding)
                        .css("display", "inline-block")
                        .css("height", "1px")
                        .css("padding", 0)
                        .css("margin", 0)
                        .css("background-color", "transparent")
                        .css("width", v * 15 + "px")
                        .css("flex-shrink", 0);
                }
                /**
                 * Check whether the current node is not a leaf node
                 *
                 * @private
                 * @returns {boolean}
                 * @memberof TreeViewItemPrototype
                 */
                is_folder() {
                    if (this.nodes) {
                        return true;
                    }
                    else {
                        return false;
                    }
                }
                /**
                 * Getter: Get the child nodes data of the current node
                 *
                 * Setter: Set the child nodes data of the current node
                 *
                 * @type {TreeViewDataType[]}
                 * @memberof TreeViewItemPrototype
                 */
                get nodes() {
                    if (!this._data)
                        return undefined;
                    return this._data.nodes;
                }
                set nodes(nodes) {
                    if (!nodes || !this.data) {
                        return;
                    }
                    this._data.nodes = nodes;
                    // return unless @get("nodes") and @get("nodes").length > 0
                    $(this.refs.childnodes).empty();
                    $(this.refs.wrapper).addClass("afx_folder_item");
                    const root = this.treeroot;
                    const result = [];
                    for (let v of nodes) {
                        const el = $("<afx-tree-view>").appendTo(this.refs.childnodes);
                        el[0].uify(this.observable);
                        const element = el[0];
                        element.treeroot = root;
                        element.indent = this.indent + 1;
                        element.open = this.open;
                        element.parent = this.parent;
                        element.treepath = `${this.treepath}/${element.aid}`;
                        element.fetch = this.fetch;
                        element.data = v;
                    }
                }
                /**
                 * Init the tag with default properties data
                 *
                 * @protected
                 * @memberof TreeViewItemPrototype
                 */
                init() {
                    this.treeroot = undefined;
                    this.treepath = this.aid.toString();
                    this._evt = {
                        id: this.aid,
                        data: { item: this, dblclick: false },
                    };
                    this._indent = 0;
                }
                /**
                 * Mount the tag and bind basic events
                 *
                 * @protected
                 * @memberof TreeViewItemPrototype
                 */
                mount() {
                    $(this.refs.container)
                        .css("padding", 0)
                        .css("margin", 0)
                        .css("display", "flex")
                        .css("flex-direction", "row")
                        .css("align-items", "center")
                        .css("white-space", "nowrap");
                    //$(this.refs.itemholder).css("display", "inline-block");
                    $(this.refs.wrapper).on("click", (e) => {
                        this.selected = true;
                    });
                    $(this.refs.wrapper).on("dblclick", (e) => {
                        this._evt.data.dblclick = true;
                        this.selected = true;
                    });
                    $(this.refs.toggle)
                        //.css("display", "inline-block")
                        .css("width", "15px")
                        .css("flex-shrink", 0)
                        .addClass("afx-tree-view-item")
                        .on("click", (e) => {
                        this.open = !this.open;
                        e.preventDefault();
                        return e.stopPropagation();
                    });
                }
                /**
                 * Layout definition of a node. This function
                 * returns the definition of the base outer layout
                 * of a node. Custom inner layout of the node should
                 * be defined in the [[itemlayout]] function
                 *
                 * @protected
                 * @returns {TagLayoutType[]}
                 * @memberof TreeViewItemPrototype
                 */
                layout() {
                    return [
                        {
                            el: "div",
                            ref: "wrapper",
                            children: [
                                {
                                    el: "ul",
                                    ref: "container",
                                    children: [
                                        { el: "li", ref: "padding" },
                                        { el: "li", ref: "toggle" },
                                        {
                                            el: "li",
                                            ref: "itemholder",
                                            class: "itemname",
                                            children: this.itemlayout(),
                                        },
                                    ],
                                },
                            ],
                        },
                        {
                            el: "ul",
                            ref: "childnodes",
                        },
                    ];
                }
            }
            tag_1.TreeViewItemPrototype = TreeViewItemPrototype;
            /**
             * SimpleTreeViewItem extends [[TreeViewItemPrototype]] and
             * define it inner layout using a [[LabelTag]]
             *
             * @export
             * @class SimpleTreeViewItem
             * @extends {TreeViewItemPrototype}
             */
            class SimpleTreeViewItem extends TreeViewItemPrototype {
                /**
                 *Creates an instance of SimpleTreeViewItem.
                 * @memberof SimpleTreeViewItem
                 */
                constructor() {
                    super();
                }
                /**
                 * Refresh the label when data changed
                 *
                 * @protected
                 * @returns {void}
                 * @memberof SimpleTreeViewItem
                 */
                ondatachange() {
                    if (!this.data) {
                        return;
                    }
                    const v = this.data;
                    const label = this.refs.label;
                    label.set(v);
                }
                /**
                 * Inner layout definition
                 *
                 * @protected
                 * @returns
                 * @memberof SimpleTreeViewItem
                 */
                itemlayout() {
                    return [{ el: "afx-label", ref: "label" }];
                }
            }
            tag_1.SimpleTreeViewItem = SimpleTreeViewItem;
            /**
             * A tree view widget presents a hierarchical list of nodes.
             *
             * @export
             * @class TreeViewTag
             * @extends {AFXTag}
             */
            class TreeViewTag extends GUI.AFXTag {
                /**
                 *Creates an instance of TreeViewTag.
                 * @memberof TreeViewTag
                 */
                constructor() {
                    super();
                }
                /**
                 * Init the tree view before mounting:
                 *
                 * @protected
                 * @memberof TreeViewTag
                 */
                init() {
                    this.itemtag = "afx-tree-view-item";
                    this._ontreeselect = this._ondragndrop = this._ontreedbclick = (e) => { };
                    this.indent = 0;
                    this.open = true;
                    this.treepath = this.aid.toString();
                }
                /**
                 * Layout definition
                 *
                 * @protected
                 * @returns {TagLayoutType[]}
                 * @memberof TreeViewTag
                 */
                layout() {
                    return [];
                }
                /**
                 * Do nothing
                 *
                 * @protected
                 * @param {*} [d]
                 * @memberof TreeViewTag
                 */
                reload(d) { }
                /**
                 * Setter: Enable/disable drag and drop event on the tree
                 *
                 * Getter: Check whether the drag and drop event is enabled
                 *
                 * @memberof TreeViewTag
                 */
                set dragndrop(v) {
                    this.attsw(v, "dragndrop");
                }
                get dragndrop() {
                    return this.hasattr("dragndrop");
                }
                /**
                 * Set the tree select event handle
                 *
                 * @memberof TreeViewTag
                 */
                set ontreeselect(v) {
                    this._ontreeselect = v;
                }
                /**
                 * Set the tree double click event handle
                 *
                 * @memberof TreeViewTag
                 */
                set ontreedbclick(v) {
                    this._ontreedbclick = v;
                }
                /**
                 * Setter:
                 *
                 * Set the default tag name of the tree node.
                 * If there is no tag name in the node data,
                 * this value will be used when creating node.
                 *
                 * Defaut to `afx-tree-view-item`
                 *
                 * Getter:
                 *
                 * Get the default node tag name
                 *
                 * @memberof TreeViewTag
                 */
                set itemtag(v) {
                    $(this).attr("itemtag", v);
                }
                get itemtag() {
                    return $(this).attr("itemtag");
                }
                /**
                 * Unselect the selected element in the tree
                 *
                 * @memberof TreeViewTag
                 */
                unselect() {
                    if (this.selectedItem) {
                        this._selectedItem.selected = false;
                    }
                }
                /**
                 * Setter: Set the selected node using its DOM element
                 *
                 * Getter: Get the DOM element of the selected node
                 *
                 * @type {TreeViewItemPrototype}
                 * @memberof TreeViewTag
                 */
                get selectedItem() {
                    return this._selectedItem;
                }
                set selectedItem(v) {
                    if (!v) {
                        return;
                    }
                    if (v === this.selectedItem) {
                        return;
                    }
                    v.selected = true;
                }
                /**
                 * Expand all nodes in the tree
                 *
                 * @returns {void}
                 * @memberof TreeViewTag
                 */
                expandAll() {
                    if (this.is_leaf()) {
                        return;
                    }
                    return this.update("expand");
                }
                /**
                 * Collapse all nodes in the tree
                 *
                 * @returns {void}
                 * @memberof TreeViewTag
                 */
                collapseAll() {
                    if (this.is_leaf()) {
                        return;
                    }
                    return this.update("collapse");
                }
                /**
                 * This function will trigger the tree select or tree double click
                 * event
                 *
                 * @param {TagEventType} e
                 * @returns {void}
                 * @memberof TreeViewTag
                 */
                itemclick(e) {
                    if (!e || !e.data) {
                        return;
                    }
                    if (e.data.item === this.selectedItem && !e.data.dblclick) {
                        return;
                    }
                    this._selectedItem = e.data.item;
                    const evt = { id: this.aid, data: e.data };
                    if (e.data.dblclick) {
                        this._ontreedbclick(evt);
                        return this.observable.trigger("treedbclick", evt);
                    }
                    else {
                        this._ontreeselect(evt);
                        return this.observable.trigger("treeselect", evt);
                    }
                }
                /**
                 * Check whether the current tree is a root tree
                 *
                 * @returns {boolean}
                 * @memberof TreeViewTag
                 */
                is_root() {
                    return this.treeroot === undefined;
                }
                /**
                 * Check whether the current tree tag is a leaf
                 *
                 * @returns {boolean}
                 * @memberof TreeViewTag
                 */
                is_leaf() {
                    const data = this.data;
                    if (!data) {
                        return true;
                    }
                    if (data.nodes) {
                        return false;
                    }
                    else {
                        return true;
                    }
                }
                /**
                 * Set drag and drop event handle
                 *
                 * @memberof TreeViewTag
                 */
                set ondragndrop(v) {
                    this._ondragndrop = v;
                }
                /**
                 * Setter:
                 *
                 * Set the tree data. This operation will create
                 * all tree node elements of the current tree
                 *
                 * Getter:
                 *
                 * Get the tree data
                 *
                 * @memberof TreeViewTag
                 */
                set data(v) {
                    this._selectedItem = undefined;
                    if (!v) {
                        return;
                    }
                    this._data = v;
                    $(this).empty();
                    if (v.path) {
                        this.treepath = v.path;
                    }
                    let tag = this.itemtag;
                    if (v.tag) {
                        tag = v.tag;
                    }
                    const el = $(`<${tag}>`).appendTo(this);
                    el[0].uify(this.observable);
                    const element = el[0];
                    element.treeroot = this.is_root() ? this : this.treeroot;
                    element.indent = this.indent;
                    element.treepath = this.treepath;
                    element.open = this.open;
                    element.fetch = this.fetch;
                    element.parent = this;
                    element.data = v;
                    if (this.is_root()) {
                        $(this).off("mousedown", this._treemousedown);
                        if (this.dragndrop) {
                            $(this).on("mousedown", this._treemousedown);
                        }
                    }
                }
                get data() {
                    return this._data;
                }
                /**
                 * Mount the tree view
                 *
                 * @protected
                 * @memberof TreeViewTag
                 */
                mount() {
                    this._dnd = {
                        from: [],
                        to: undefined,
                    };
                    this._treemousedown = (e) => {
                        let obj = $(e.target).closest("afx-tree-view");
                        if (obj.length === 0) {
                            return;
                        }
                        let el = obj[0];
                        if (el === this) {
                            return;
                        }
                        this._dnd.from = [el];
                        this._dnd.to = undefined;
                        $(window).on("mouseup", this._treemouseup);
                        return $(window).on("mousemove", this._treemousemove);
                    };
                    this._treemouseup = (e) => {
                        $(window).off("mouseup", this._treemouseup);
                        $(window).off("mousemove", this._treemousemove);
                        $("#systooltip").hide();
                        let obj = $(e.target).closest("afx-tree-view");
                        if (obj.length === 0) {
                            return;
                        }
                        let el = obj[0];
                        if (el.is_leaf()) {
                            el = el.parent;
                        }
                        if (el === this._dnd.from[0] ||
                            el === this._dnd.from[0].parent) {
                            return;
                        }
                        this._dnd.to = el;
                        this._ondragndrop({
                            id: this.aid,
                            data: this._dnd,
                        });
                        this._dnd = {
                            from: [],
                            to: undefined,
                        };
                    };
                    this._treemousemove = (e) => {
                        if (!e) {
                            return;
                        }
                        if (!this._dnd.from) {
                            return;
                        }
                        const data = this._dnd.from[0].data;
                        const $label = $("#systooltip");
                        const top = e.clientY + 5;
                        const left = e.clientX + 5;
                        $label.show();
                        const label = $label[0];
                        label.set(data);
                        $label.css("top", top + "px").css("left", left + "px");
                    };
                }
            }
            tag_1.TreeViewTag = TreeViewTag;
            tag_1.define("afx-tree-view", TreeViewTag);
            tag_1.define("afx-tree-view-item", SimpleTreeViewItem);
        })(tag = GUI.tag || (GUI.tag = {}));
    })(GUI = OS.GUI || (OS.GUI = {}));
})(OS || (OS = {}));

var OS;
(function (OS) {
    let GUI;
    (function (GUI) {
        let tag;
        (function (tag) {
            /**
             * A slider or track bar is a graphical control element with which
             * a user may set a value by moving an indicator, usually horizontally
             *
             * @class SliderTag
             * @extends {AFXTag}
             */
            class SliderTag extends GUI.AFXTag {
                /**
                 * Creates an instance of SliderTag.
                 * @memberof SliderTag
                 */
                constructor() {
                    super();
                }
                /**
                 *  Init the default value of the slider:
                 * - `max`: 100
                 * - `value`: 0
                 *
                 * @protected
                 * @memberof SliderTag
                 */
                init() {
                    this.enable = true;
                    this._max = 100;
                    this._value = 0;
                    this.precision = false;
                    this._onchange = this._onchanging = () => { };
                }
                /**
                 * Do nothing
                 *
                 * @protected
                 * @param {*} [d]
                 * @memberof SliderTag
                 */
                reload(d) { }
                /**
                 * Set value change event handle.
                 * This handle will be triggered when the
                 * slider indicator is released
                 *
                 * @memberof SliderTag
                 */
                set onvaluechange(f) {
                    this._onchange = f;
                }
                /**
                 * Set value changing event handle.
                 * This handle is triggered when moving the
                 * slider indicator
                 *
                 * @memberof SliderTag
                 */
                set onvaluechanging(f) {
                    this._onchanging = f;
                }
                /**
                 * Setter/Getter: set and get precision reading
                 *
                 * @memberof SliderTag
                 */
                set precision(v) {
                    this.attsw(v, "precision");
                }
                get precision() {
                    return this.hasattr("precision");
                }
                /**
                 * Setter: Enable/disable the slider
                 *
                 * Getter: Check whether the slider is enabled
                 *
                 * @memberof SliderTag
                 */
                set enable(v) {
                    this.attsw(v, "enable");
                    if (v) {
                        $(this)
                            .on("pointerover", () => {
                            return $(this.refs.point).show();
                        })
                            .on("pointerout", () => {
                            return $(this.refs.point).hide();
                        });
                    }
                    else {
                        $(this.refs.point).hide();
                        $(this).off("pointerover").off("pointerout");
                    }
                }
                get enable() {
                    return this.hasattr("enable");
                }
                /**
                 * Setter: Set the slider value
                 *
                 * Getter: Get the current slider value
                 *
                 * @memberof SliderTag
                 */
                set value(v) {
                    this._value = v;
                    this.calibrate();
                }
                get value() {
                    return this._value;
                }
                /**
                 * Setter: Set the maximum value of the slider
                 *
                 * Getter: Get the maximum value of the slider
                 *
                 * @memberof SliderTag
                 */
                set max(v) {
                    this._max = v;
                    this.calibrate();
                }
                get max() {
                    return this._max;
                }
                /**
                 * Mount the tag and bind some basic events
                 *
                 * @protected
                 * @memberof SliderTag
                 */
                mount() {
                    this.enable_dragging();
                    $(this.refs.point).css("position", "absolute");
                    $(this.refs.point).hide();
                    this.observable.on("resize", (e) => {
                        return this.calibrate();
                    });
                    $(this.refs.container).on("click", (e) => {
                        const offset = $(this.refs.container).offset();
                        const left = e.clientX - offset.left;
                        const maxw = $(this.refs.container).width();
                        this.value = (left * this.max) / maxw;
                        this.calibrate();
                        const evt = { id: this.aid, data: this.value };
                        this._onchange(evt);
                        return this._onchanging(evt);
                    });
                    this.calibrate();
                }
                /**
                 * Calibrate the slide based on its value and max value
                 *
                 * @memberof SliderTag
                 */
                calibrate() {
                    if (this.value > this.max) {
                        this._value = this.max;
                    }
                    if (!this.precision) {
                        this._value = Math.round(this.value);
                        $(this.refs.point).text(this.value);
                    }
                    else {
                        $(this.refs.point).text((Math.round(this.value * 100) / 100).toFixed(2));
                    }
                    $(this.refs.container).css("width", $(this).width() + "px");
                    const w = ($(this.refs.container).width() * this.value) /
                        this.max;
                    $(this.refs.prg)
                        .css("width", w + "px")
                        .css("height", $(this.refs.container).height() + "px");
                    //if (this.enable) {
                    const ow = w - ($(this.refs.point).outerWidth() / 2.0);
                    const top = Math.floor(($(this.refs.prg).height() +
                        $(this.refs.point).height()) /
                        2 + 3);
                    $(this.refs.point)
                        .css("left", ow + "px")
                        .css("bottom", top + "px");
                    //}
                }
                /**
                 * enable dragging on the slider indicator
                 *
                 * @private
                 * @memberof SliderTag
                 */
                enable_dragging() {
                    $(this.refs.point)
                        .css("user-select", "none")
                        .css("cursor", "default");
                    $(this).on("pointerdown", (e) => {
                        e.preventDefault();
                        const offset = $(this.refs.container).offset();
                        $(window).on("pointermove", (e) => {
                            let left = e.clientX - offset.left;
                            left = left < 0 ? 0 : left;
                            const maxw = $(this.refs.container).width();
                            left = left > maxw ? maxw : left;
                            this.value = (left * this.max) / maxw;
                            this.calibrate();
                            return this._onchanging({
                                id: this.aid,
                                data: this.value,
                            });
                        });
                        $(window).on("pointerup", (e) => {
                            this._onchange({
                                id: this.aid,
                                data: this.value,
                            });
                            $(window).off("pointermove", null);
                            return $(window).off("pointerup", null);
                        });
                    });
                }
                /**
                 * Layout definition
                 *
                 * @protected
                 * @returns {TagLayoutType[]}
                 * @memberof SliderTag
                 */
                layout() {
                    return [
                        {
                            el: "div",
                            class: "container",
                            ref: "container",
                            children: [
                                { el: "div", class: "progress", ref: "prg" },
                                { el: "div", class: "dragpoint", ref: "point" },
                            ],
                        },
                    ];
                }
            }
            tag.SliderTag = SliderTag;
            tag.define("afx-slider", SliderTag);
        })(tag = GUI.tag || (GUI.tag = {}));
    })(GUI = OS.GUI || (OS.GUI = {}));
})(OS || (OS = {}));

var OS;
(function (OS) {
    let GUI;
    (function (GUI) {
        let tag;
        (function (tag) {
            /**
             * A float list is a list of items in which each
             * item can be moved (drag and drop) freely
             *
             * @export
             * @class FloatListTag
             * @extends {ListViewTag}
             */
            class FloatListTag extends tag.ListViewTag {
                /**
                 *Creates an instance of FloatListTag.
                 * @memberof FloatListTag
                 */
                constructor() {
                    super();
                }
                /**
                 * Update the current tag, do nothing
                 *
                 * @protected
                 * @param {*} [d]
                 * @memberof FloatListTag
                 */
                reload(d) { }
                /**
                 * set the onready callback function to the tag.
                 * This callback will be called after
                 * the tag is mounted
                 *
                 * @memberof FloatListTag
                 */
                set onready(v) {
                    this._onready = v;
                }
                /**
                 * Disable the dropdown option in this list
                 *
                 * @memberof FloatListTag
                 */
                set dropdown(v) { }
                /**
                 * Disable the list buttons configuration in this
                 * list
                 *
                 * @memberof FloatListTag
                 */
                set buttons(v) { }
                /**
                 * Disable the `showlist` behavior in this list
                 *
                 * @protected
                 * @param {*} e
                 * @memberof FloatListTag
                 */
                showlist(e) { }
                /**
                 * Disable the `dropoff` behavior in this list
                 *
                 * @protected
                 * @param {*} e
                 * @memberof FloatListTag
                 */
                dropoff(e) { }
                /**
                 * Function called when the data of the list
                 * is changed
                 *
                 * @protected
                 * @memberof FloatListTag
                 */
                ondatachange() {
                    this.calibrate();
                }
                /**
                 * Mount the list to the DOM tree
                 *
                 * @protected
                 * @returns {void}
                 * @memberof FloatListTag
                 */
                mount() {
                    $(this.refs.container)
                        .css("width", "100%")
                        .css("height", "100%");
                    $(this.refs.mlist)
                        .css("position", "absolute")
                        .css("display", "block")
                        .css("width", "100%");
                    this.observable.on("resize", (e) => this.calibrate());
                    if (this._onready) {
                        return this._onready(this);
                    }
                }
                /**
                 * Push an element to the list
                 *
                 * @param {GenericObject<any>} v an element data
                 * @returns
                 * @memberof FloatListTag
                 */
                push(v) {
                    const el = super.push(v);
                    this.enable_drag(el);
                    return el;
                }
                /**
                 * Enable drag and drop on the list
                 *
                 * @private
                 * @param {ListViewItemTag} el the list item DOM element
                 * @memberof FloatListTag
                 */
                enable_drag(el) {
                    $(el)
                        .css("user-select", "none")
                        .css("cursor", "default")
                        .css("display", "block")
                        .css("position", "absolute")
                        .on("pointerdown", (evt) => {
                        const globalof = $(this.refs.mlist).offset();
                        //evt.preventDefault();
                        const offset = $(el).offset();
                        offset.top = evt.clientY - offset.top;
                        offset.left = evt.clientX - offset.left;
                        const mouse_move = function (e) {
                            let top = e.clientY - offset.top - globalof.top;
                            let left = e.clientX - globalof.left - offset.left;
                            left = left < 0 ? 0 : left;
                            top = top < 0 ? 0 : top;
                            return $(el)
                                .css("top", `${top}px`)
                                .css("left", `${left}px`);
                        };
                        var mouse_up = function (e) {
                            $(window).off("pointermove", mouse_move);
                            return $(window).off("pointerup", mouse_up);
                        };
                        $(window).on("pointermove", mouse_move);
                        return $(window).on("pointerup", mouse_up);
                    });
                }
                /**
                 * Calibrate the view of the list
                 *
                 * @memberof FloatListTag
                 */
                calibrate() {
                    let ctop = 20;
                    let cleft = 20;
                    $(this.refs.mlist).css("height", `${$(this.refs.container).height()}px`);
                    const gw = $(this.refs.mlist).width();
                    const gh = $(this.refs.mlist).height();
                    $(this.refs.mlist)
                        .children()
                        .each((i, e) => {
                        $(e)
                            .css("top", `${ctop}px`)
                            .css("left", `${cleft}px`);
                        const w = $(e).width();
                        const h = $(e).height();
                        if (this.dir === "vertical") {
                            ctop += h + 20;
                            if (ctop + h > gh) {
                                ctop = 20;
                                cleft += w + 20;
                            }
                        }
                        else {
                            cleft += w + 20;
                            if (cleft + w > gw) {
                                cleft = 20;
                                ctop += h + 20;
                            }
                        }
                    });
                }
            }
            tag.FloatListTag = FloatListTag;
            tag.define("afx-float-list", FloatListTag);
        })(tag = GUI.tag || (GUI.tag = {}));
    })(GUI = OS.GUI || (OS.GUI = {}));
})(OS || (OS = {}));

var OS;
(function (OS) {
    let GUI;
    (function (GUI) {
        let tag;
        (function (tag) {
            /**
             * Tag that define system calendar widget
             *
             * @export
             * @class CalendarTag
             * @extends {AFXTag}
             */
            class CalendarTag extends GUI.AFXTag {
                /**
                 *Creates an instance of CalendarTag.
                 * @memberof CalendarTag
                 */
                constructor() {
                    super();
                    this._day = 0;
                    this._month = 0;
                    this._year = 0;
                    this._ondateselect = (e) => { };
                }
                /**
                 * Init the tag before mounting
                 *
                 * @protected
                 * @memberof CalendarTag
                 */
                init() {
                    $(this).css("height", "100%");
                    $(this.refs.grid).css("width", "100%");
                }
                /**
                 * Update the current tag, doing nothing in this tag
                 *
                 * @protected
                 * @param {*} [d] any data object
                 * @memberof CalendarTag
                 */
                reload(d) { }
                /**
                 * Get the current selected date in the widget
                 *
                 * @readonly
                 * @type {Date}
                 * @memberof CalendarTag
                 */
                get selectedDate() {
                    return this._selectedDate;
                }
                /**
                 * Set the date select event callback handle for the widget
                 *
                 * @memberof CalendarTag
                 */
                set ondateselect(v) {
                    this._ondateselect = v;
                }
                /**
                 * Mount the current widget to the DOM tree
                 *
                 * @protected
                 * @memberof CalendarTag
                 */
                mount() {
                    this.refs.prev.iconclass = "fa fa-angle-left";
                    this.refs.next.iconclass = "fa fa-angle-right";
                    this.refs.prev.onbtclick = (e) => this.prevmonth();
                    this.refs.next.onbtclick = (e) => this.nextmonth();
                    const grid = this.refs.grid;
                    grid.header = [
                        { text: "__(Sun)" },
                        { text: "__(Mon)" },
                        { text: "__(Tue)" },
                        { text: "__(Wed)" },
                        { text: "__(Thu)" },
                        { text: "__(Fri)" },
                        { text: "__(Sat)" },
                    ];
                    grid.oncellselect = (e) => {
                        this.dateselect(e);
                    };
                    this.observable.on("resize", (e) => this.calibrate());
                    this.calibrate();
                    this.calendar(null);
                }
                /**
                 * This function triggers the date select event
                 *
                 * @private
                 * @param {TagEventType} e AFX tag event data [[TagEventType]]
                 * @returns {void}
                 * @memberof CalendarTag
                 */
                dateselect(e) {
                    if (!e.data.item) {
                        return;
                    }
                    const value = e.data.item.data.text;
                    if (value === "") {
                        return;
                    }
                    const evt = {
                        id: this.aid,
                        data: new Date(this._year, this._month, parseInt(value)),
                    };
                    this._ondateselect(evt);
                    this._selectedDate = evt.data;
                    return this.observable.trigger("dateselect", evt);
                }
                /**
                 * Calibrate the layout of the tag
                 *
                 * @protected
                 * @memberof CalendarTag
                 */
                calibrate() {
                    $(this.refs.grid).css("height", `${$(this).height() - $(this.refs.ctrl).height()}px`);
                }
                /**
                 * Display the previous month of the current month
                 *
                 * @private
                 * @memberof CalendarTag
                 */
                prevmonth() {
                    this._selectedDate = undefined;
                    this._month--;
                    if (this._month < 0) {
                        this._month = 11;
                        this._year--;
                    }
                    this.calendar(new Date(this._year, this._month, 1));
                }
                /**
                 * Display the next month of the current month
                 *
                 * @private
                 * @returns
                 * @memberof CalendarTag
                 */
                nextmonth() {
                    this._selectedDate = undefined;
                    this._month++;
                    if (this._month > 11) {
                        this._month = 0;
                        this._year++;
                    }
                    return this.calendar(new Date(this._year, this._month, 1));
                }
                /**
                 * Visualize the calendar base on input date
                 *
                 * @private
                 * @param {Date} date
                 * @memberof CalendarTag
                 */
                calendar(date) {
                    let week_day;
                    let asc, end;
                    if (!date) {
                        date = new Date();
                    }
                    this._day = date.getDate();
                    this._month = date.getMonth();
                    this._year = date.getFullYear();
                    const now = {
                        d: new Date().getDate(),
                        m: new Date().getMonth(),
                        y: new Date().getFullYear(),
                    };
                    const months = [
                        __("January"),
                        __("February"),
                        __("March"),
                        __("April"),
                        __("May"),
                        __("June"),
                        __("July"),
                        __("August"),
                        __("September"),
                        __("October"),
                        __("November"),
                        __("December"),
                    ];
                    const this_month = new Date(this._year, this._month, 1);
                    const next_month = new Date(this._year, this._month + 1, 1);
                    // Find out when this month starts and ends.
                    const first_week_day = this_month.getDay();
                    const days_in_this_month = Math.round((next_month.getTime() - this_month.getTime()) /
                        (1000 * 60 * 60 * 24));
                    //self.mtext = months[self.month]
                    const rows = [];
                    let row = [];
                    // Fill the first week of the month with the appropriate number of blanks.
                    for (week_day = 0, end = first_week_day - 1, asc = 0 <= end; asc ? week_day <= end : week_day >= end; asc ? week_day++ : week_day--) {
                        row.push({ text: "" });
                    }
                    week_day = first_week_day;
                    for (let day_counter = 1, end1 = days_in_this_month, asc1 = 1 <= end1; asc1 ? day_counter <= end1 : day_counter >= end1; asc1 ? day_counter++ : day_counter--) {
                        week_day %= 7;
                        if (week_day === 0) {
                            rows.push(row);
                            row = [];
                        }
                        // Do something different for the current day.
                        if (now.d === day_counter &&
                            this._month === now.m &&
                            this._year === now.y) {
                            row.push({ text: day_counter, selected: true });
                        }
                        else {
                            row.push({ text: day_counter });
                        }
                        week_day++;
                    }
                    for (let i = 0, end2 = 7 - row.length, asc2 = 0 <= end2; asc2 ? i <= end2 : i >= end2; asc2 ? i++ : i--) {
                        row.push({ text: "" });
                    }
                    rows.push(row);
                    const grid = this.refs.grid;
                    grid.rows = rows;
                    this.refs.mlbl.text = `${months[this._month]} ${this._year}`;
                }
                /**
                 * Layout definition of the widget
                 *
                 * @protected
                 * @returns {TagLayoutType[]}
                 * @memberof CalendarTag
                 */
                layout() {
                    return [
                        {
                            el: "div",
                            ref: "ctrl",
                            children: [
                                { el: "afx-button", class: "prevmonth", ref: "prev" },
                                { el: "afx-label", ref: "mlbl" },
                                { el: "afx-button", class: "nextmonth", ref: "next" },
                            ],
                        },
                        { el: "afx-grid-view", ref: "grid" },
                    ];
                }
            }
            tag.CalendarTag = CalendarTag;
            tag.define("afx-calendar-view", CalendarTag);
        })(tag = GUI.tag || (GUI.tag = {}));
    })(GUI = OS.GUI || (OS.GUI = {}));
})(OS || (OS = {}));

var OS;
(function (OS) {
    let GUI;
    (function (GUI) {
        let tag;
        (function (tag) {
            /**
             * Class definition of Color picker widget
             *
             * @export
             * @class ColorPickerTag
             * @extends {AFXTag}
             */
            class ColorPickerTag extends GUI.AFXTag {
                /**
                 * Creates an instance of ColorPickerTag.
                 * @memberof ColorPickerTag
                 */
                constructor() {
                    super();
                    this._oncolorselect = (e) => { };
                }
                /**
                 * Init tag before mounting, do nothing
                 *
                 * @protected
                 * @memberof ColorPickerTag
                 */
                init() { }
                /**
                 * Reload tag, do nothing
                 *
                 * @protected
                 * @param {*} [d]
                 * @memberof ColorPickerTag
                 */
                reload(d) { }
                /**
                 * Get selected color value
                 *
                 * @readonly
                 * @type {ColorType}
                 * @memberof ColorPickerTag
                 */
                get selectedColor() {
                    return this._selectedColor;
                }
                /**
                 * Set the color select event handle
                 *
                 * @memberof ColorPickerTag
                 */
                set oncolorselect(v) {
                    this._oncolorselect = v;
                }
                /**
                 * Mount the widget to DOM tree
                 *
                 * @protected
                 * @memberof ColorPickerTag
                 */
                mount() {
                    $(this.refs.wrapper)
                        .css("width", "310px")
                        .css("height", "190px")
                        .css("display", "block")
                        .css("padding", "3px");
                    $(this.refs.palette)
                        .css("width", "284px")
                        .css("height", "155px")
                        .css("float", "left");
                    $(this.refs.colorval)
                        .css("width", "15px")
                        .css("height", "155px")
                        .css("text-align", "center")
                        .css("margin-left", "3px")
                        .css("display", "block")
                        .css("float", "left");
                    $(this.refs.inputwrp).css("margin-top", "3px");
                    $(this.refs.hextext)
                        .css("width", "70px")
                        .css("margin-left", "3px")
                        .css("margin-right", "5px");
                    this.build_palette();
                }
                /**
                 * Build the color palette
                 *
                 * @private
                 * @memberof ColorPickerTag
                 */
                build_palette() {
                    const colorctx = $(this.refs.palette).get(0).getContext("2d");
                    let gradient = colorctx.createLinearGradient(0, 0, $(this.refs.palette).width(), 0);
                    // fill color
                    gradient.addColorStop(0, "rgb(255,   0,   0)");
                    gradient.addColorStop(0.15, "rgb(255,   0, 255)");
                    gradient.addColorStop(0.33, "rgb(0,     0, 255)");
                    gradient.addColorStop(0.49, "rgb(0,   255, 255)");
                    gradient.addColorStop(0.67, "rgb(0,   255,   0)");
                    gradient.addColorStop(0.84, "rgb(255, 255,   0)");
                    gradient.addColorStop(1, "rgb(255,   0,   0)");
                    gradient.addColorStop(0, "rgb(0,   0,   0)");
                    // Apply gradient to canvas
                    colorctx.fillStyle = gradient;
                    colorctx.fillRect(0, 0, colorctx.canvas.width, colorctx.canvas.height);
                    // Create semi transparent gradient (white -> trans. -> black)
                    gradient = colorctx.createLinearGradient(0, 0, 0, $(this.refs.palette).width());
                    gradient.addColorStop(0, "rgba(255, 255, 255, 1)");
                    gradient.addColorStop(0.5, "rgba(255, 255, 255, 0)");
                    gradient.addColorStop(0.5, "rgba(0,     0,   0, 0)");
                    gradient.addColorStop(1, "rgba(0,     0,   0, 1)");
                    // Apply gradient to canvas
                    colorctx.fillStyle = gradient;
                    colorctx.fillRect(0, 0, colorctx.canvas.width, colorctx.canvas.height);
                    // now add mouse move event
                    const getHex = function (c) {
                        let s = c.toString(16);
                        if (s.length === 1) {
                            s = "0" + s;
                        }
                        return s;
                    };
                    const pick_color = (e) => {
                        $(this.refs.palette).css("cursor", "crosshair");
                        const offset = $(this.refs.palette).offset();
                        const x = e.pageX - offset.left;
                        const y = e.pageY - offset.top;
                        const color = colorctx.getImageData(x, y, 1, 1);
                        const data = {
                            r: color.data[0],
                            g: color.data[1],
                            b: color.data[2],
                            text: "rgb(" +
                                color.data[0] +
                                ", " +
                                color.data[1] +
                                ", " +
                                color.data[2] +
                                ")",
                            hex: "#" +
                                getHex(color.data[0]) +
                                getHex(color.data[1]) +
                                getHex(color.data[2]),
                        };
                        return data;
                    };
                    const mouse_move_h = (e) => {
                        const data = pick_color(e);
                        return $(this.refs.colorval).css("background-color", data.text);
                    };
                    $(this.refs.palette).on("mouseenter", (e) => {
                        return $(this.refs.palette).on("mousemove", mouse_move_h);
                    });
                    $(this.refs.palette).on("mouseout", (e) => {
                        $(this.refs.palette).off("mousemove", mouse_move_h);
                        if (this.selectedColor) {
                            return $(this.refs.colorval).css("background-color", this.selectedColor.text);
                        }
                    });
                    $(this.refs.palette).on("click", (e) => {
                        const data = pick_color(e);
                        $(this.refs.rgbtext).html(data.text);
                        $(this.refs.hextext).val(data.hex);
                        this._selectedColor = data;
                        const evt = { id: this.aid, data };
                        this._oncolorselect(evt);
                        return this.observable.trigger("colorselect", data);
                    });
                }
                /**
                 * layout definition of the widget
                 *
                 * @protected
                 * @returns {TagLayoutType[]}
                 * @memberof ColorPickerTag
                 */
                layout() {
                    return [
                        {
                            el: "div",
                            ref: "wrapper",
                            children: [
                                {
                                    el: "canvas",
                                    class: "color-palette",
                                    ref: "palette",
                                },
                                { el: "color-sample", ref: "colorval" },
                                { el: "div", class: "afx-clear" },
                                {
                                    el: "div",
                                    ref: "inputwrp",
                                    children: [
                                        { el: "input", ref: "hextext" },
                                        { el: "span", ref: "rgbtext" },
                                    ],
                                },
                            ],
                        },
                    ];
                }
            }
            tag.ColorPickerTag = ColorPickerTag;
            tag.define("afx-color-picker", ColorPickerTag);
        })(tag = GUI.tag || (GUI.tag = {}));
    })(GUI = OS.GUI || (OS.GUI = {}));
})(OS || (OS = {}));

var OS;
(function (OS) {
    let GUI;
    (function (GUI) {
        let tag;
        (function (tag) {
            /**
             * Definition of system file view widget
             *
             * @export
             * @class FileViewTag
             * @extends {AFXTag}
             */
            class FileViewTag extends GUI.AFXTag {
                /**
                 *Creates an instance of FileViewTag.
                 * @memberof FileViewTag
                 */
                constructor() {
                    super();
                }
                /**
                 * Init the widget before mounting
                 *
                 * @protected
                 * @memberof FileViewTag
                 */
                init() {
                    this.data = [];
                    this.status = true;
                    this.showhidden = false;
                    this.chdir = true;
                    this.view = "list";
                    this._onfileopen = this._onfileselect = (e) => { };
                    this._ondirchanged = (e) => { };
                    this._selectedFiles = [];
                    const fn = function (r1, r2, i) {
                        let t1 = r1[i].text;
                        let t2 = r2[i].text;
                        if (!t1 || !t2)
                            return 0;
                        if (i == 1) {
                            // sort by date
                            t1 = new Date(t1);
                            t2 = new Date(t2);
                        }
                        else if (i == 2) {
                            // sort by size
                            t1 = parseInt(t1);
                            t2 = parseInt(t2);
                        }
                        else {
                            // sort by name
                            t1 = t1.toString().toLowerCase();
                            t2 = t2.toString().toLowerCase();
                        }
                        if (this.desc) {
                            if (t1 < t2) {
                                return -1;
                            }
                            if (t1 > t2) {
                                return 1;
                            }
                        }
                        else {
                            if (t1 > t2) {
                                return -1;
                            }
                            if (t1 < t2) {
                                return 1;
                            }
                            ;
                        }
                        return 0;
                    };
                    this._header = [
                        {
                            text: "__(File name)",
                            sort: fn
                        },
                        {
                            text: "__(Modified)",
                            sort: fn
                        },
                        {
                            text: "__(Size)",
                            sort: fn
                        },
                    ];
                }
                /**
                 * Update the current widget, do nothing
                 *
                 * @protected
                 * @param {*} [d]
                 * @memberof FileViewTag
                 */
                reload(d) { }
                /**
                 * set the function that allows to fetch file entries.
                 * This handle function should return a promise on
                 * an arry of [[API.FileInfoType]]
                 *
                 * @memberof FileViewTag
                 */
                set fetch(v) {
                    this._fetch = v;
                }
                /**
                 * set the callback handle for the file select event.
                 * The parameter of the callback should  be an object
                 * of type [[TagEventType]]<T> with the data type `T` is [[API.FileInfoType]]
                 *
                 * @memberof FileViewTag
                 */
                set onfileselect(e) {
                    this._onfileselect = e;
                }
                /**
                 * set the callback handle for the directory changed event.
                 * The parameter of the callback should  be an object
                 * of type [[TagEventType]]<T> with the data type `T` is [[API.VFS.BaseFileHandle]]
                 *
                 * @memberof FileViewTag
                 */
                set onchdir(e) {
                    this._ondirchanged = e;
                }
                /**
                 set the callback handle for the file open event.
                 * The parameter of the callback should  be an object
                 * of type [[TagEventType]]<T> with the data type `T` is [[API.FileInfoType]]
                 *
                 * @memberof FileViewTag
                 */
                set onfileopen(e) {
                    this._onfileopen = e;
                }
                /**
                 * Setter:
                 *
                 * chang the view of the widget, there are three different views
                 * - `icon`
                 * - `list`
                 * - `tree`
                 *
                 * Getter:
                 *
                 * Get the current view setting of the widget
                 *
                 * @memberof FileViewTag
                 */
                set view(v) {
                    $(this).attr("view", v);
                    this.switchView();
                }
                get view() {
                    return $(this).attr("view");
                }
                /**
                 * Setter:
                 *
                 * Turn on/off the changing current working directory feature
                 * of the widget when a directory is double clicked. If enabled,
                 * the widget will use the configured [[fetch]] function to query
                 * the content of the selected directory
                 *
                 * Getter:
                 *
                 * check whether changing current working directory feature
                 * is enabled
                 *
                 * @memberof FileViewTag
                 */
                set chdir(v) {
                    this.attsw(v, "chdir");
                }
                get chdir() {
                    return this.hasattr("chdir");
                }
                /**
                 * Setter : Enable or disable the status bar of the widget
                 *
                 * Getter: Check whether the status bar is enabled
                 *
                 * @memberof FileViewTag
                 */
                set status(v) {
                    this.attsw(v, "status");
                    if (v) {
                        $(this.refs.status).show();
                        return;
                    }
                    $(this.refs.status).hide();
                }
                get status() {
                    return this.hasattr("status");
                }
                /**
                 * Setter:
                 *
                 * Allow the widget to show or hide hidden file
                 *
                 * Getter:
                 *
                 * Check whether the hidden file should be shown in
                 * the widget
                 *
                 * @memberof FileViewTag
                 */
                set showhidden(v) {
                    this.attsw(v, "showhidden");
                    if (!this.data) {
                        return;
                    }
                    this.switchView();
                }
                get showhidden() {
                    return this.hasattr("showhidden");
                }
                /**
                 * Setter:
                 *
                 * Allow multiple selection on file view
                 *
                 * Getter:
                 *
                 * Check whether the  multiselection is actived
                 *
                 * @memberof FileViewTag
                 */
                set multiselect(v) {
                    this.attsw(v, "multiselect");
                    this.refs.listview.multiselect = v;
                    this.refs.gridview.multiselect = v;
                }
                get multiselect() {
                    return this.hasattr("multiselect");
                }
                /**
                 * Get the current selected file
                 *
                 * @readonly
                 * @type {API.FileInfoType}
                 * @memberof FileViewTag
                 */
                get selectedFile() {
                    if (this._selectedFiles.length == 0)
                        return undefined;
                    return this._selectedFiles[this._selectedFiles.length - 1];
                }
                /**
                 * Get all selected files
                 *
                 * @readonly
                 * @type {API.FileInfoType[]}
                 * @memberof FileViewTag
                 */
                get selectedFiles() {
                    return this._selectedFiles;
                }
                /**
                 * Setter:
                 *
                 * Set the path of the current working directory.
                 * When called the widget will refresh the current
                 * working directory using the configured [[fetch]]
                 * function
                 *
                 * Getter:
                 *
                 * Get the path of the current working directory
                 *
                 * @memberof FileViewTag
                 */
                set path(v) {
                    if (!v) {
                        return;
                    }
                    this._path = v;
                    if (!this._fetch) {
                        return;
                    }
                    this._fetch(v)
                        .then((data) => {
                        if (!data) {
                            return;
                        }
                        this.data = data.sort(this.sortByName).sort(this.sortByType);
                        if (this.status) {
                            this.refs.status.text = " ";
                        }
                        const evt = { id: this.aid, data: v.asFileHandle() };
                        this._ondirchanged(evt);
                        this.observable.trigger("chdir", evt);
                    })
                        .catch((e) => OS.announcer.oserror(e.toString(), e));
                }
                get path() {
                    return this._path;
                }
                /**
                 * Setter: Set the data of the current working directory
                 *
                 * Getter: Get the data of the current working directory
                 *
                 * @memberof FileViewTag
                 */
                set data(v) {
                    if (!v) {
                        return;
                    }
                    this._data = v;
                    this.refreshData();
                }
                get data() {
                    return this._data;
                }
                /**
                 * Set the file drag and drop event handle. This allows application
                 * to define custom behavior of the event
                 *
                 * @memberof FileViewTag
                 */
                set ondragndrop(v) {
                    this.refs.treeview.ondragndrop = v;
                    this.refs.listview.ondragndrop = v;
                    this.refs.gridview.ondragndrop = (e) => {
                        const evt = {
                            id: this.aid,
                            data: {
                                from: e.data.from.map(x => x.data[0].domel),
                                to: e.data.to.data[0].domel
                            }
                        };
                        v(evt);
                    };
                }
                /**
                 * Sort file by its type
                 *
                 * @private
                 * @param {API.FileInfoType} a
                 * @param {API.FileInfoType} b
                 * @return {*}  {number}
                 * @memberof FileViewTag
                 */
                sortByType(a, b) {
                    if (!a.type) {
                        a.type = "none";
                    }
                    if (!b.type) {
                        b.type = "none";
                    }
                    return a.type.toLowerCase().localeCompare(b.type.toLowerCase());
                }
                /**
                 * sort file by its name
                 *
                 * @private
                 * @param {API.FileInfoType} a first file meta-data
                 * @param {API.FileInfoType} b second file meta-data
                 * @returns {number}
                 * @memberof FileViewTag
                 */
                sortByName(a, b) {
                    // sort file by type, then by name
                    if (a.filename) {
                        a.name = a.filename;
                    }
                    if (b.filename) {
                        b.name = b.filename;
                    }
                    return a.name.toLowerCase().localeCompare(b.name.toLowerCase());
                }
                /**
                 * calibrate the widget layout
                 *
                 * @memberof FileViewTag
                 */
                calibrate() {
                    let h = $(this).outerHeight();
                    const w = $(this).width();
                    if (this.status) {
                        h -= $(this.refs.status).height();
                    }
                    $(this.refs.listview).css("height", h + "px");
                    $(this.refs.gridview).css("height", h + "px");
                    $(this.refs.treecontainer).css("height", h + "px");
                    $(this.refs.listview).css("width", w + "px");
                    $(this.refs.gridview).css("width", w + "px");
                    $(this.refs.treecontainer).css("width", w + "px");
                }
                /**
                 * Refresh the list view of the widget. This function
                 * is called when the view of the widget changed to `icon`
                 *
                 * @private
                 * @memberof FileViewTag
                 */
                refreshList() {
                    const items = [];
                    $.each(this.data, (i, v) => {
                        if (v.filename[0] === "." && !this.showhidden) {
                            return;
                        }
                        if (!v.text)
                            v.text = v.filename;
                        /*
                        if (v.text.length > 10) {
                            v.text = v.text.substring(0, 9) + "...";
                        }*/
                        v.iconclass = v.iconclass ? v.iconclass : v.type;
                        if (v.icon)
                            v.iconclass = undefined;
                        items.push(v);
                    });
                    this.refs.listview.data = items;
                }
                /**
                 * Refresh the grid view of the widget, this function is called
                 * when the view of the widget set to `list`
                 *
                 * @private
                 * @memberof FileViewTag
                 */
                refreshGrid() {
                    const rows = [];
                    $.each(this.data, (i, v) => {
                        if (v.filename[0] === "." && !this.showhidden) {
                            return;
                        }
                        v.iconclass = v.iconclass ? v.iconclass : v.type;
                        if (v.icon)
                            v.iconclass = undefined;
                        const row = [
                            {
                                text: v.filename,
                                icon: v.icon,
                                iconclass: v.iconclass,
                                path: v.path,
                                data: v
                            },
                            {
                                text: v.mtime,
                                data: v,
                            },
                            {
                                text: v.size,
                                data: v,
                            },
                        ];
                        return rows.push(row);
                    });
                    this.refs.gridview.rows = rows;
                }
                /**
                 * Refresh the Treeview of the widget, this function is called
                 * when the view of the widget set to `tree`
                 *
                 * @private
                 * @memberof FileViewTag
                 */
                refreshTree() {
                    //@treeview.root.set("selectedItem", null)
                    const tdata = {
                        text: this.path,
                        path: this.path,
                        open: true,
                        nodes: this.getTreeData(this.data),
                    };
                    this.refs.treeview.data = tdata;
                    // (this.refs.treeview as TreeViewTag).expandAll();
                }
                /**
                 * Create the tree data from the list of input
                 * file meta-data
                 *
                 * @private
                 * @param {API.FileInfoType[]} data list of file meta-data
                 * @returns {TreeViewDataType[]}
                 * @memberof FileViewTag
                 */
                getTreeData(data) {
                    const nodes = [];
                    const me = this;
                    $.each(data, (i, v) => {
                        if (v.filename[0] === "." && !this.showhidden) {
                            return undefined;
                        }
                        if (!v.text)
                            v.text = v.filename;
                        if (v.type === "dir") {
                            v.nodes = [];
                            v.open = false;
                        }
                        v.iconclass = v.iconclass ? v.iconclass : v.type;
                        if (v.icon)
                            v.iconclass = undefined;
                        return nodes.push(v);
                    });
                    return nodes;
                }
                /**
                 * Refresh data of the current widget view
                 *
                 * @private
                 * @returns {void}
                 * @memberof FileViewTag
                 */
                refreshData() {
                    if (!this.data) {
                        return;
                    }
                    this.data.sort(this.sortByName).sort(this.sortByType);
                    switch (this.view) {
                        case "icon":
                            return this.refreshList();
                        case "list":
                            return this.refreshGrid();
                        default:
                            return this.refreshTree();
                    }
                }
                /**
                 * Switch between three view options
                 *
                 * @private
                 * @memberof FileViewTag
                 */
                switchView() {
                    $(this.refs.listview).hide();
                    $(this.refs.gridview).hide();
                    $(this.refs.treecontainer).hide();
                    this._selectedFiles = [];
                    switch (this.view) {
                        case "icon":
                            $(this.refs.listview).show();
                            break;
                        case "list":
                            $(this.refs.gridview).show();
                            break;
                        default:
                            $(this.refs.treecontainer).show();
                    }
                    this.refreshData();
                    this.calibrate();
                    if (this.status) {
                        this.refs.status.text = " ";
                    }
                }
                /**
                 * This function triggers the file select event
                 *
                 * @private
                 * @param {API.FileInfoType} e selected file meta-data
                 * @memberof FileViewTag
                 */
                fileselect(e) {
                    if (e.path === this.path) {
                        e.type = "dir";
                        e.mime = "dir";
                    }
                    if (this.status) {
                        this.refs.status.text = __("{0} ({1} bytes)", e.filename, e.size ? e.size : "0");
                    }
                    const evt = { id: this.aid, data: e };
                    this._onfileselect(evt);
                    this.observable.trigger("fileselect", evt);
                }
                /**
                 * This function triggers the file open event
                 *
                 * @private
                 * @param {API.FileInfoType} e selected file meta-data
                 * @memberof FileViewTag
                 */
                filedbclick(e) {
                    if (e.path === this.path) {
                        e.type = "dir";
                        e.mime = "dir";
                    }
                    const evt = { id: this.aid, data: e };
                    if (e.type === "dir" && this.chdir) {
                        this.path = e.path;
                    }
                    else {
                        this._onfileopen(evt);
                        this.observable.trigger("fileopen", evt);
                    }
                }
                /**
                 * Mount the widget in the DOM tree
                 *
                 * @protected
                 * @memberof FileViewTag
                 */
                mount() {
                    this.observable.on("resize", (e) => this.calibrate());
                    const tree = this.refs.treeview;
                    tree.fetch = (v) => {
                        return new Promise((resolve, reject) => {
                            if (!this._fetch) {
                                return resolve(undefined);
                            }
                            if (!v.data.path) {
                                return resolve(undefined);
                            }
                            return this._fetch(v.data.path)
                                .then((d) => resolve(this.getTreeData(d.sort(this.sortByName).sort(this.sortByType))))
                                .catch((e) => reject(__e(e)));
                        });
                    };
                    const grid = this.refs.gridview;
                    const list = this.refs.listview;
                    grid.resizable = true;
                    grid.header = this._header;
                    tree.dragndrop = true;
                    list.dragndrop = true;
                    grid.dragndrop = true;
                    // even handles
                    list.onlistselect = (e) => {
                        this.fileselect(e.data.item.data);
                        this._selectedFiles = e.data.items.map(x => x.data);
                    };
                    grid.onrowselect = (e) => {
                        this.fileselect($(e.data.item).children()[0]
                            .data.data);
                        this._selectedFiles = e.data.items.map(x => $(x).children()[0].data.data);
                    };
                    tree.ontreeselect = (e) => {
                        this.fileselect(e.data.item.data);
                        this._selectedFiles = [e.data.item.data];
                    };
                    // dblclick
                    list.onlistdbclick = (e) => {
                        this.filedbclick(e.data.item.data);
                    };
                    grid.oncelldbclick = (e) => {
                        this.filedbclick(e.data.item.data.data);
                    };
                    tree.ontreedbclick = (e) => {
                        this.filedbclick(e.data.item.data);
                    };
                    this.switchView();
                }
                /**
                 * Layout definition of the widget
                 *
                 * @protected
                 * @returns {TagLayoutType[]}
                 * @memberof FileViewTag
                 */
                layout() {
                    return [
                        { el: "afx-list-view", ref: "listview" },
                        {
                            el: "div",
                            class: "treecontainer",
                            ref: "treecontainer",
                            children: [
                                { el: "afx-tree-view", ref: "treeview" },
                            ],
                        },
                        { el: "afx-grid-view", ref: "gridview" },
                        { el: "afx-label", class: "status", ref: "status" },
                    ];
                }
            }
            tag.FileViewTag = FileViewTag;
            tag.define("afx-file-view", FileViewTag);
        })(tag = GUI.tag || (GUI.tag = {}));
    })(GUI = OS.GUI || (OS.GUI = {}));
})(OS || (OS = {}));

var OS;
(function (OS) {
    let GUI;
    (function (GUI) {
        let tag;
        (function (tag) {
            /**
             * An overlay tag is a layout tag that alway stay on top of
             * the virtual desktop environment. Tile layout elements ([[VBoxTag]], [[HboxTag]])
             * can be used inside this tag to compose elements
             *
             * @export
             * @class OverlayTag
             * @extends {AFXTag}
             */
            class OverlayTag extends GUI.AFXTag {
                /**
                 *Creates an instance of OverlayTag.
                 * @memberof OverlayTag
                 */
                constructor() {
                    super();
                }
                //.css "display", "flex"
                //.css "flex-direction", "column"
                //$(@refs.yield).css "flex", "1"
                /**
                 * Put the tag on top of the virtual desktop environment
                 *
                 * @protected
                 * @memberof OverlayTag
                 */
                init() {
                    $(this.refs.yield)
                        .css("position", "relative")
                        .css("width", "100%")
                        .css("height", "100%");
                    $(this).css("position", "absolute").css("z-index", 1000000);
                }
                /**
                 * Do nothing
                 *
                 * @protected
                 * @param {*} [d]
                 * @memberof OverlayTag
                 */
                reload(d) { }
                /**
                 * Setter:
                 *
                 * Set the width of the tag, the tag width should be in form of:
                 * `100px` of `80%`
                 *
                 * Getter:
                 *
                 * Get the tag width
                 *
                 * @memberof OverlayTag
                 */
                set width(v) {
                    if (!v) {
                        return;
                    }
                    this._width = v;
                    this.calibrate();
                }
                get width() {
                    return this._width;
                }
                /**
                 * Setter:
                 *
                 * Set the tag height, the tag height should be in form of:
                 * `100px` of `80%`
                 *
                 * Getter:
                 *
                 * Get the tag height
                 *
                 * @memberof OverlayTag
                 */
                set height(v) {
                    if (!v) {
                        return;
                    }
                    this._height = v;
                    this.calibrate();
                }
                get height() {
                    return this._height;
                }
                /**
                 * Calibrate the element when mounting
                 *
                 * @protected
                 * @returns {void}
                 * @memberof OverlayTag
                 */
                mount() {
                    return this.calibrate();
                }
                /**
                 * Calibrate the width and height of the tag
                 *
                 * @returns {void}
                 * @memberof OverlayTag
                 */
                calibrate() {
                    $(this)
                        .css("width", this.width)
                        .css("height", this.height);
                    return this.observable.trigger("resize", {
                        id: this.aid,
                        data: {
                            w: this.width,
                            h: this.height,
                        },
                    });
                }
                /**
                 * Layout definition of the tag
                 *
                 * @protected
                 * @returns {TagLayoutType[]}
                 * @memberof OverlayTag
                 */
                layout() {
                    return [
                        {
                            el: "afx-vbox",
                            ref: "yield",
                        },
                    ];
                }
            }
            tag.OverlayTag = OverlayTag;
            tag.define("afx-overlay", OverlayTag);
        })(tag = GUI.tag || (GUI.tag = {}));
    })(GUI = OS.GUI || (OS.GUI = {}));
})(OS || (OS = {}));

var OS;
(function (OS) {
    let GUI;
    (function (GUI) {
        let tag;
        (function (tag) {
            /**
             * This class define the AntOS system application dock tag
             *
             * @export
             * @class AppDockTag
             * @extends {AFXTag}
             */
            class AppDockTag extends GUI.AFXTag {
                /**
                 *Creates an instance of AppDockTag.
                 * @memberof AppDockTag
                 */
                constructor() {
                    super();
                }
                /**
                 * Implementation of the abstract function: Update the current tag.
                 * It do nothing for this tag
                 *
                 * @protected
                 * @param {*} [d]
                 * @memberof AppDockTag
                 */
                reload(d) {
                    let app = d;
                    if (!app) {
                        return;
                    }
                    let i = -1;
                    const iterable = this.items;
                    for (let k = 0; k < iterable.length; k++) {
                        const v = iterable[k];
                        if (v.app.pid === app.pid) {
                            i = k;
                            break;
                        }
                    }
                }
                /**
                 * Init the tag before mounting
                 *
                 * @protected
                 * @memberof AppDockTag
                 */
                init() {
                    this._items = [];
                    this._previous_touch = { x: 0, y: 0 };
                }
                /**
                 * The tag layout, it is empty on creation but elements will
                 * be added automatically to it in operation
                 *
                 * @protected
                 * @returns {TagLayoutType[]}
                 * @memberof AppDockTag
                 */
                layout() {
                    return [];
                }
                /**
                 * getter to get the dock items
                 *
                 * @readonly
                 * @type {AppDockItemType[]}
                 * @memberof AppDockTag
                 */
                get items() {
                    return this._items;
                }
                /**
                 * Setter:
                 *
                 * set the selected application in the dock
                 * this will trigger two event:
                 * - `focus`: on the selected application
                 * - `blur`: on all other applications on the dock
                 *
                 * Getter:
                 *
                 *  Get the current selected application
                 * on the dock
                 *
                 * @memberof AppDockTag
                 */
                set selectedApp(v) {
                    let el = undefined;
                    for (let it of this.items) {
                        it.app.blur();
                        $(it.domel).removeClass("selected");
                        if (v && v === it.app) {
                            el = it;
                        }
                    }
                    this._selectedItem = el;
                    if (!el) {
                        OS.PM.pidactive = 0;
                        return;
                    }
                    $(el.domel).addClass("selected");
                    $(Ant.OS.GUI.workspace)[0].unselect();
                }
                get selectedApp() {
                    if (!this._selectedItem)
                        return undefined;
                    return this._selectedItem.app;
                }
                /**
                 * Get selected item of the dock
                 *
                 * @readonly
                 * @type {AppDockItemType}
                 * @memberof AppDockTag
                 */
                get selectedItem() {
                    return this._selectedItem;
                }
                /**
                 * Add a button to the dock
                 *
                 * @private
                 * @param {string} [name] associated application name
                 * @param {AppDockItemType} [item] dock item
                 * @param {boolean} [pinned] the button is pinned to the dock ?
                 * @memberof AppDockTag
                 */
                add_button(name, item, pinned = false) {
                    const collection = $(this).children().filter((i, e) => {
                        return e.data.name == name;
                    });
                    if (collection.length > 0) {
                        collection[0].data.pinned = true;
                        item.domel = collection[0];
                        return;
                    }
                    const el = $("<afx-button>");
                    const bt = el[0];
                    el.appendTo(this);
                    el[0].uify(this.observable);
                    bt.set(item);
                    bt.data = {
                        name: name,
                        pinned: pinned
                    };
                    item.domel = bt;
                    bt.onbtclick = (e) => {
                        e.data.stopPropagation();
                        this.handleAppSelect(bt);
                    };
                }
                update_button(el) {
                    const collection = this.items.filter(it => it.app.name == el.data.name);
                    if (collection.length == 1) {
                        $(el).removeClass("plural");
                    }
                    if (collection.length == 0) {
                        if (el.data.pinned) {
                            $(el).removeClass();
                        }
                        else {
                            $(el).remove();
                        }
                    }
                }
                /**
                 * When a new application process is created, this function
                 * will be called to add new application entry to the dock.
                 * The added application will becomes the current selected
                 * application
                 *
                 * @param {AppDockItemType} item an application dock item entry
                 * @memberof AppDockTag
                 */
                addapp(item) {
                    const collection = this.items.filter(it => it.app.name == item.app.name);
                    let bt = undefined;
                    if (collection.length == 0) {
                        this.add_button(item.app.name, item);
                    }
                    else {
                        bt = collection[0].domel;
                        item.domel = bt;
                        $(bt).addClass("plural");
                    }
                    this.items.push(item);
                    this.selectedApp = item.app;
                }
                /**
                 * Handle the application selection action
                 *
                 * @private
                 * @memberof AppDockTag
                 */
                handleAppSelect(bt) {
                    const name = bt.data.name;
                    const collection = this.items.filter(it => it.app.name == name);
                    const ctxmenu = $("#contextmenu")[0];
                    ctxmenu.hide();
                    if (collection.length == 0) {
                        GUI.launch(name, []);
                        return;
                    }
                    if (collection.length == 1) {
                        collection[0].app.trigger("focus");
                        return;
                    }
                    // show the context menu containning a list of application to select
                    const menu_data = collection.map(e => {
                        return {
                            text: e.app.scheme.apptitle,
                            icon: e.icon,
                            iconclass: e.iconclass,
                            app: e.app
                        };
                    });
                    const offset = $(bt).offset();
                    ctxmenu.nodes = menu_data;
                    $(ctxmenu)
                        .css("left", offset.left)
                        .css("bottom", $(this).height());
                    ctxmenu.onmenuselect = (e) => {
                        e.data.item.data.app.show();
                    };
                    ctxmenu.show();
                }
                /**
                 * Delete and application entry from the dock.
                 * This function will be called when an application
                 * is exit
                 *
                 * @param {BaseApplication} a the application to be removed from the dock
                 * @memberof AppDockTag
                 */
                removeapp(a) {
                    let i = -1;
                    const iterable = this.items;
                    for (let k = 0; k < iterable.length; k++) {
                        const v = iterable[k];
                        if (v.app.pid === a.pid) {
                            i = k;
                            break;
                        }
                    }
                    if (i !== -1) {
                        const appName = this.items[i].app.name;
                        const el = this.items[i].domel;
                        delete this.items[i].app;
                        this.items.splice(i, 1);
                        this.update_button(el);
                    }
                }
                /**
                 * Mount the current dock tag
                 *
                 * @protected
                 * @memberof AppDockTag
                 */
                mount() {
                    this.contextmenuHandle = (e, m) => {
                        if (e.target === this) {
                            return;
                        }
                        m.hide();
                        const bt = $(e.target).closest("afx-button")[0];
                        const name = bt.data.name;
                        const collection = this.items.filter(it => it.app.name == name);
                        m.nodes = [
                            { text: "__(New window)", dataid: "new" },
                            { text: "__(Hide all)", dataid: "hide" },
                            { text: "__(Close all)", dataid: "quit" },
                        ];
                        m.onmenuselect = function (evt) {
                            switch (evt.data.item.data.dataid) {
                                case "new":
                                    GUI.launch(bt.data.name, []);
                                    break;
                                case "hide":
                                    collection.forEach((el, _) => el.app.hide());
                                    break;
                                case "quit":
                                    collection.forEach((el, _) => el.app.quit());
                                    break;
                                default:
                                    break;
                            }
                        };
                        const offset = $(bt).offset();
                        $(m)
                            .css("left", offset.left)
                            .css("bottom", $(this).height());
                        return m.show();
                    };
                    OS.announcer.trigger("sysdockloaded", undefined);
                    GUI.bindKey("CTRL-ALT-2", (e) => {
                        if (!this.items || this.items.length === 0) {
                            return;
                        }
                        let index = this.items.indexOf(this.selectedItem);
                        if (index < 0) {
                            index = 0;
                        }
                        else {
                            index++;
                        }
                        if (index >= this.items.length)
                            index = 0;
                        this.items[index].app.trigger("focus");
                    });
                    GUI.bindKey("CTRL-ALT-1", (e) => {
                        if (!this.items || this.items.length === 0) {
                            return;
                        }
                        let index = this.items.indexOf(this.selectedItem);
                        index--;
                        if (index < 0) {
                            index = this.items.length - 1;
                        }
                        if (index < 0) {
                            return;
                        }
                        this.items[index].app.trigger("focus");
                    });
                    this.addEventListener("touchstart", e => {
                        this._previous_touch.x = e.touches[0].pageX;
                        this._previous_touch.y = e.touches[0].pageY;
                    }, { passive: true });
                    this.addEventListener("touchmove", e => {
                        const offset = { x: 0, y: 0 };
                        offset.x = this._previous_touch.x - e.touches[0].pageX;
                        offset.y = this._previous_touch.y - e.touches[0].pageY;
                        this.scrollLeft += offset.x;
                        this._previous_touch.x = e.touches[0].pageX;
                        this._previous_touch.y = e.touches[0].pageY;
                    }, { passive: true });
                    this.addEventListener("wheel", (evt) => {
                        this.scrollLeft += evt.deltaY;
                    }, { passive: true });
                    OS.announcer.on("app-pinned", (_) => {
                        this.refresh_pinned_app();
                    });
                    this.refresh_pinned_app();
                }
                /**
                 * refresh the pinned application list
                 *
                 * @private
                 * @memberof AppDockTag
                 */
                refresh_pinned_app() {
                    if (!OS.setting.system.startup.pinned)
                        return;
                    // unpin all application on the dock
                    $(this).children().each((i, e) => {
                        e.data.pinned = false;
                    });
                    // pin all setting application on the dock
                    OS.setting.system.startup.pinned
                        .filter((el) => {
                        const app = OS.setting.system.packages[el];
                        return app && app.app;
                    })
                        .forEach((name) => {
                        const app = OS.setting.system.packages[name];
                        const item = {
                            icon: app.icon,
                            iconclass: app.iconclass,
                            app: undefined
                        };
                        this.add_button(name, item, true);
                    });
                    // update to remove the button
                    $(this).children().each((i, e) => {
                        this.update_button(e);
                    });
                }
            }
            tag.AppDockTag = AppDockTag;
            tag.define("afx-apps-dock", AppDockTag);
        })(tag = GUI.tag || (GUI.tag = {}));
    })(GUI = OS.GUI || (OS.GUI = {}));
})(OS || (OS = {}));

var OS;
(function (OS) {
    let GUI;
    (function (GUI) {
        let tag;
        (function (tag) {
            /**
             * A system panel contains the following elements:
             * - Spotlight to access to applications menu
             * - Current focused application menu
             * - System tray for all running services running in background
             *
             * @export
             * @class SystemPanelTag
             * @extends {AFXTag}
             */
            class SystemPanelTag extends GUI.AFXTag {
                /**
                 *Creates an instance of SystemPanelTag.
                 * @memberof SystemPanelTag
                 */
                constructor() {
                    super();
                    this._osmenu = {
                        text: __("Start"),
                        iconclass: "fa fa-circle",
                    };
                    this._view = false;
                    this._pending_task = [];
                    this._loading_toh = undefined;
                    this.app_list = [];
                    this._services = [];
                    this._prevent_open = false;
                }
                /**
                 * Do nothing
                 *
                 * @protected
                 * @memberof SystemPanelTag
                 */
                init() { }
                /**
                 * Do nothing
                 *
                 * @protected
                 * @param {*} [d]
                 * @memberof SystemPanelTag
                 */
                reload(d) { }
                /**
                 * Attach a service to the system tray on the pannel,
                 * this operation is performed when a service is started
                 *
                 * @param {BaseService} s
                 * @returns
                 * @memberof SystemPanelTag
                 */
                attachservice(s) {
                    this._services.unshift(s);
                }
                /**
                 * Launch the selected application from the spotlight
                 * applications list
                 *
                 * @private
                 * @returns {void}
                 * @memberof SystemPanelTag
                 */
                open() {
                    if (this._prevent_open) {
                        this._prevent_open = false;
                        return;
                    }
                    const applist = this.refs.applist;
                    const el = applist.selectedItem;
                    if (!el) {
                        return;
                    }
                    this.toggle(false);
                    // launch the app or open the file
                    Ant.OS.GUI.openWith(el.data);
                    applist.unselect();
                }
                /**
                 * Perform spotlight search operation on keyboard event
                 *
                 * @private
                 * @param {JQuery.KeyboardEventBase} e
                 * @returns {void}
                 * @memberof SystemPanelTag
                 */
                search(e) {
                    const applist = this.refs.applist;
                    const catlist = this.refs.catlist;
                    switch (e.which) {
                        case 27:
                            // escape key
                            return this.toggle(false);
                        case 37:
                            this._prevent_open = true;
                            applist.selectPrev();
                            return e.preventDefault();
                        case 38:
                            return e.preventDefault();
                        case 39:
                            this._prevent_open = true;
                            applist.selectNext();
                            return e.preventDefault();
                        case 40:
                            return e.preventDefault();
                        case 13:
                            e.preventDefault();
                            return this.open();
                        default:
                            catlist.selected = 0;
                            var text = this.refs.search
                                .value;
                            if (!(text.length >= 3)) {
                                this.refs.applist.data = this.app_list;
                                this.refs.applist.selected = -1;
                                return;
                            }
                            var result = Ant.OS.API.search(text);
                            if (result.length === 0) {
                                return;
                            }
                            applist.data = result;
                    }
                }
                /**
                 * detach a service from the system tray of the panel.
                 * This function is called when the corresponding running
                 * service is killed
                 *
                 * @param {BaseService} s
                 * @memberof SystemPanelTag
                 */
                detachservice(s) {
                    const index = this._services.indexOf(s);
                    this._services.splice(index, 1);
                }
                /**
                 * Layout definition of the panel
                 *
                 * @protected
                 * @returns {TagLayoutType[]}
                 * @memberof SystemPanelTag
                 */
                layout() {
                    return [
                        {
                            el: "div",
                            ref: "panel",
                            children: [
                                {
                                    el: "afx-button",
                                    ref: "osmenu",
                                    class: "afx-panel-os-menu",
                                },
                                {
                                    el: "afx-apps-dock",
                                    ref: "sysdock",
                                    id: "sysdock"
                                },
                                {
                                    el: "afx-button",
                                    id: "systray",
                                    ref: "systray",
                                    class: "afx-panel-os-stray",
                                },
                            ],
                        },
                        {
                            el: "afx-overlay",
                            id: "start-panel",
                            ref: "overlay",
                            children: [
                                {
                                    el: "afx-hbox",
                                    height: 30,
                                    children: [
                                        {
                                            el: "div",
                                            width: 30,
                                            id: "searchicon",
                                        },
                                        { el: "input", ref: "search" },
                                    ],
                                },
                                {
                                    el: "afx-vbox",
                                    children: [
                                        {
                                            el: "afx-tab-bar",
                                            id: "catlist",
                                            ref: "catlist",
                                            height: 45
                                        },
                                        {
                                            el: "afx-list-view",
                                            id: "applist",
                                            ref: "applist",
                                        }
                                    ]
                                },
                                {
                                    el: "afx-hbox",
                                    id: "btlist",
                                    height: 40,
                                    children: [
                                        {
                                            el: "afx-button",
                                            ref: "btscreen",
                                            tooltip: __("ct:Toggle fullscreen"),
                                        },
                                        {
                                            el: "afx-button",
                                            ref: "btuser",
                                            tooltip: __("ct:User: {0}", Ant.OS.setting.user.username),
                                        },
                                        {
                                            el: "afx-button",
                                            ref: "btlogout",
                                            tooltip: __("ct:Logout"),
                                        },
                                    ],
                                },
                            ],
                        },
                    ];
                }
                /**
                 * Refresh applications list on the spotlight widget
                 * from system packages meta-data
                 *
                 * @private
                 * @memberof SystemPanelTag
                 */
                refreshAppList() {
                    let catlist_el = this.refs.catlist;
                    let k, v;
                    const catlist = new Set();
                    this.app_list = [];
                    for (k in Ant.OS.setting.system.packages) {
                        v = Ant.OS.setting.system.packages[k];
                        if (v && v.app) {
                            this.app_list.push(v);
                            catlist.add(v.category.__());
                        }
                    }
                    for (k in Ant.OS.setting.system.menu) {
                        v = Ant.OS.setting.system.menu[k];
                        this.app_list.push(v);
                    }
                    this.app_list.sort(function (a, b) {
                        if (a.text < b.text) {
                            return -1;
                        }
                        else if (a.text > b.text) {
                            return 1;
                        }
                        else {
                            return 0;
                        }
                    });
                    // build up the category menu
                    const cat_list_data = [];
                    cat_list_data.push({
                        text: "__(All)",
                        iconclass: "bi bi-gear-wide"
                    });
                    OS.setting.applications.categories
                        .forEach((v) => {
                        if (catlist.has(v.text.__())) {
                            cat_list_data.push(v);
                            catlist.delete(v.text.__());
                        }
                    });
                    // put the remainder to the data
                    catlist.forEach((c) => {
                        cat_list_data.push({
                            text: c,
                            iconclass: "bi bi-gear-wide"
                        });
                    });
                    catlist_el.items = cat_list_data;
                    catlist_el.selected = 0;
                }
                /**
                 * Show/hide the spotlight
                 *
                 * @private
                 * @param {boolean} flag
                 * @memberof SystemPanelTag
                 */
                toggle(flag) {
                    this._view = flag;
                    if (flag) {
                        $(this.refs.overlay).show();
                        this.refreshAppList();
                        this.calibrate();
                        $(document).on("click", this._cb);
                        this.refs.search.value = "";
                        $(this.refs.search).focus();
                    }
                    else {
                        $(this.refs.overlay).hide();
                        $(document).off("click", this._cb);
                    }
                }
                /**
                 * Calibrate the spotlight widget
                 *
                 * @memberof SystemPanelTag
                 */
                calibrate() {
                    this.refs.overlay.height = `${$(window).height() - $(this.refs.panel).height()}px`;
                }
                /**
                 * Check if the loading tasks ended,
                 * if it the case, stop the animation
                 *
                 * @private
                 * @memberof SystemPanelTag
                 */
                animation_check() {
                    if (this._pending_task.length === 0) {
                        $(this.refs.panel).removeClass("loading");
                        $(GUI.workspace).css("cursor", "auto");
                    }
                    if (this._loading_toh)
                        clearTimeout(this._loading_toh);
                    this._loading_toh = undefined;
                }
                show_systray() {
                    const ctxmenu = $("#contextmenu")[0];
                    ctxmenu.hide();
                    ctxmenu.nodes = this._services;
                    $(ctxmenu)
                        .css("right", 0)
                        .css("bottom", $(this).height());
                    ctxmenu.show();
                }
                /**
                 * Mount the tag bind some basic event
                 *
                 * @protected
                 * @memberof SystemPanelTag
                 */
                mount() {
                    const systray = this.refs.systray;
                    this.refs.osmenu.set(this._osmenu);
                    this._cb = (e) => {
                        if (!$(e.target).closest($(this.refs.overlay)).length &&
                            !$(e.target).closest(this.refs.osmenu).length) {
                            return this.toggle(false);
                        }
                    };
                    this.refs.btscreen.set({
                        iconclass: "fa fa-tv",
                        onbtclick: (e) => {
                            this.toggle(false);
                            return Ant.OS.GUI.toggleFullscreen();
                        },
                    });
                    this.refs.btuser.set({
                        iconclass: "fa fa-user-circle-o",
                        onbtclick: (e) => {
                            this.toggle(false);
                            return Ant.OS.GUI.openDialog("InfoDialog", Ant.OS.setting.user);
                        },
                    });
                    this.refs.btlogout.set({
                        iconclass: "fa fa-power-off",
                        onbtclick: (e) => {
                            this.toggle(false);
                            return Ant.OS.exit();
                        },
                    });
                    this.refs.osmenu.onbtclick = (e) => {
                        if ($(this.refs.overlay).is(":hidden")) {
                            this.toggle(true);
                        }
                        else {
                            this.toggle(false);
                        }
                    };
                    $(this.refs.search).on("keyup", (e) => {
                        return this.search(e);
                    });
                    this.refs.applist.onlistselect = (_) => {
                        return this.open();
                    };
                    Ant.OS.GUI.bindKey("CTRL- ", (e) => {
                        if (this._view === false) {
                            return this.toggle(true);
                        }
                        else {
                            return this.toggle(false);
                        }
                    });
                    const catlist = this.refs.catlist;
                    catlist.ontabselect = (e) => {
                        const applist = this.refs.applist;
                        if (catlist.selected === 0) {
                            applist.data = this.app_list;
                        }
                        else {
                            // filter app by data
                            applist.data = this.app_list.filter((el) => {
                                return el.category.__() === e.data.item.data.text.__();
                            });
                        }
                        applist.selected = -1;
                    };
                    $(this.refs.overlay)
                        .hide();
                    this.refs.osmenu.contextmenuHandle = (e, m) => { };
                    systray.contextmenuHandle = (e, m) => { };
                    this.refs.panel.contextmenuHandle = (e, m) => { };
                    OS.announcer.on("loading", (o) => {
                        if (o.u_data != 0) {
                            return;
                        }
                        if (this._pending_task.length == 0) {
                            $(this.refs.panel).addClass("loading");
                            systray.iconclass = "fa-spin fa fa-cog";
                        }
                        this._pending_task.push(o.id);
                        $(GUI.workspace).css("cursor", "wait");
                    });
                    systray.iconclass = "bi bi-sliders";
                    systray.onbtclick = (e) => {
                        e.data.stopPropagation();
                        this.show_systray();
                    };
                    OS.announcer.on("loaded", (o) => {
                        const i = this._pending_task.indexOf(o.id);
                        if (i >= 0) {
                            this._pending_task.splice(i, 1);
                        }
                        if (this._pending_task.length === 0) {
                            // set time out
                            systray.iconclass = "bi bi-sliders";
                            if (!this._loading_toh)
                                this._loading_toh = setTimeout(() => this.animation_check(), 1000);
                        }
                    });
                    OS.announcer.on("desktopresize", (e) => {
                        this.calibrate();
                    });
                    Ant.OS.announcer.trigger("syspanelloaded", undefined);
                }
            }
            tag.SystemPanelTag = SystemPanelTag;
            tag.define("afx-sys-panel", SystemPanelTag);
        })(tag = GUI.tag || (GUI.tag = {}));
    })(GUI = OS.GUI || (OS.GUI = {}));
})(OS || (OS = {}));

var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var OS;
(function (OS) {
    let GUI;
    (function (GUI) {
        let tag;
        (function (tag) {
            /**
             * Meta tag that represents the  virtual desktop environment.
             * In near future, we may have multiple virtual desktop environments.
             * Each desktop environment has a simple file manager and a window
             * manager that render the window in a specific order.
             *
             * @export
             * @class DesktopTag
             * @extends {FloatListTag}
             */
            class DesktopTag extends tag.FloatListTag {
                /**
                 * Creates an instance of DesktopTag.
                 * @memberof DesktopTag
                 */
                constructor() {
                    super();
                    this.observer = undefined;
                    this.window_list = new Set();
                }
                /**
                 * Mount the virtual desktop to the DOM tree
                 *
                 * @protected
                 * @memberof DesktopTag
                 */
                mount() {
                    if (this.observer) {
                        this.observer.disconnect();
                        this.observer = undefined;
                    }
                    this.observer = new MutationObserver((mutations_list) => {
                        mutations_list.forEach((mutation) => {
                            mutation.removedNodes.forEach((removed_node) => {
                                if (removed_node.tagName === "AFX-APP-WINDOW") {
                                    this.window_list.delete(removed_node);
                                }
                            });
                            mutation.addedNodes.forEach((added_node) => {
                                if (added_node.tagName === "AFX-APP-WINDOW") {
                                    this.selectWindow(added_node);
                                }
                            });
                        });
                    });
                    this.observer.observe(this, { subtree: false, childList: true });
                    this.onready = (_) => {
                        this.observable = OS.announcer.observable;
                        window.onresize = () => {
                            const evt = {
                                id: this.aid,
                                data: {
                                    width: $(this).width(),
                                    height: $(this).height()
                                }
                            };
                            OS.announcer.trigger("desktopresize", evt);
                            this.calibrate();
                        };
                        this.onlistselect = (d) => {
                            GUI.systemDock().selectedApp = null;
                        };
                        this.onlistdbclick = (d) => {
                            GUI.systemDock().selectedApp = null;
                            const it = this.selectedItem;
                            return GUI.openWith(it.data);
                        };
                        //($ "#workingenv").on "click", (e) ->
                        //     desktop[0].set "selected", -1
                        $(this).on("click", (e) => {
                            let el = $(e.target).closest("afx-app-window")[0];
                            if (el) {
                                return;
                            }
                            el = $(e.target).parent();
                            if (!(el.length > 0)) {
                                return;
                            }
                            el = el.parent();
                            if (!(el.length > 0)) {
                                return;
                            }
                            if (el[0] !== this) {
                                return;
                            }
                            this.unselect();
                            GUI.systemDock().selectedApp = null;
                        });
                        this.contextmenuHandle = (e, m) => {
                            if (e.target.tagName.toUpperCase() === "UL") {
                                this.unselect();
                            }
                            GUI.systemDock().selectedApp = null;
                            let menu = [
                                { text: __("Open"), dataid: "desktop-open" },
                                { text: __("Refresh"), dataid: "desktop-refresh" },
                            ];
                            menu = menu.concat(OS.setting.desktop.menu.map(e => e));
                            m.nodes = menu;
                            m.onmenuselect = (evt) => {
                                if (!evt.data || !evt.data.item)
                                    return;
                                const item = evt.data.item.data;
                                switch (item.dataid) {
                                    case "desktop-open":
                                        var it = this.selectedItem;
                                        if (it) {
                                            return GUI.openWith(it.data);
                                        }
                                        let arg = OS.setting.desktop.path.asFileHandle();
                                        arg.mime = "dir";
                                        arg.type = "dir";
                                        return GUI.openWith(arg);
                                    case "desktop-refresh":
                                        return this.refresh();
                                    default:
                                        if (item.app) {
                                            return GUI.launch(item.app, item.args);
                                        }
                                }
                            };
                            return m.show(e);
                        };
                        this.refresh();
                        OS.announcer.on("VFS", (d) => {
                            if (["read", "publish", "download"].includes(d.message)) {
                                return;
                            }
                            if (d.u_data.hash() === this.file.hash() || d.u_data.parent().hash() === this.file.hash()) {
                                return this.refresh();
                            }
                        });
                        return OS.announcer.ostrigger("desktoploaded", undefined);
                    };
                    super.mount();
                }
                /**
                 * Display all files and folders in the specific desktop location
                 *
                 * @return {*}  {Promise<any>}
                 * @memberof DesktopTag
                 */
                refresh() {
                    return new Promise((resolve, reject) => __awaiter(this, void 0, void 0, function* () {
                        try {
                            this.file = OS.setting.desktop.path.asFileHandle();
                            yield this.file.onready();
                            const d = yield this.file.read();
                            if (d.error) {
                                throw new Error(d.error);
                            }
                            const items = [];
                            $.each(d.result, function (i, v) {
                                if (v.filename[0] === "." && !OS.setting.desktop.showhidden) {
                                    return;
                                }
                                v.text = v.filename;
                                //v.text = v.text.substring(0,9) + "..." ifv.text.length > 10
                                v.iconclass = v.type;
                                return items.push(v);
                            });
                            this.data = items;
                            this.calibrate();
                        }
                        catch (err) {
                            OS.announcer.osfail(err.toString(), err);
                            reject(__e(err));
                        }
                    }));
                }
                /**
                 * Remove this element from its parent
                 *
                 * @memberof DesktopTag
                 */
                remove() {
                    if (this.observer) {
                        this.observer.disconnect();
                    }
                    super.remove();
                }
                /**
                 * Active a window above all other windows
                 *
                 * @private
                 * @param {WindowTag} win
                 * @memberof DesktopTag
                 */
                selectWindow(win) {
                    if (this.window_list.has(win)) {
                        this.window_list.delete(win);
                    }
                    else {
                        win.observable.on("focused", (_) => {
                            this.selectWindow(win);
                        });
                    }
                    this.window_list.add(win);
                    this.render();
                }
                /**
                 * Render all windows in order from bottom to top
                 *
                 * @private
                 * @memberof DesktopTag
                 */
                render() {
                    let zindex = 10;
                    for (let win of this.window_list) {
                        $(win).css("z-index", zindex++);
                    }
                }
            }
            tag.DesktopTag = DesktopTag;
            tag.define("afx-desktop", DesktopTag);
        })(tag = GUI.tag || (GUI.tag = {}));
    })(GUI = OS.GUI || (OS.GUI = {}));
})(OS || (OS = {}));

var OS;
(function (OS) {
    let GUI;
    (function (GUI) {
        let tag;
        (function (tag) {
            /**
             * The layout of a simple stack menu item
             *
             * @export
             * @class SimpleStackMenuItemTag
             * @extends {ListViewItemTag}
             */
            class SimpleStackMenuItemTag extends tag.ListViewItemTag {
                /**
                 *Creates an instance of SimpleStackMenuItemTag.
                 * @memberof SimpleStackMenuItemTag
                 */
                constructor() {
                    super();
                }
                /**
                 * Reset some property to default
                 *
                 * @protected
                 * @memberof SimpleStackMenuItemTag
                 */
                init() {
                    this.closable = false;
                    this.data = {};
                    this.switch = false;
                    this.radio = false;
                    this.checked = false;
                }
                /**
                 * Mount the current tag
                 *
                 * @protected
                 * @memberof SimpleStackMenuItemTag
                 */
                mount() {
                    super.mount();
                    this.refs.switch.enable = false;
                }
                /**
                 * Setter: Turn on/off the checker feature of the menu entry
                 *
                 * Getter: Check whether the checker feature is enabled on this menu entry
                 *
                 * @memberof SimpleStackMenuItemTag
                 */
                set switch(v) {
                    this.attsw(v, "switch");
                    if (this.radio || v) {
                        $(this.refs.switch).show();
                    }
                    else {
                        $(this.refs.switch).hide();
                    }
                }
                get switch() {
                    return this.hasattr("switch");
                }
                /**
                 * Setter: select/unselect the current item
                 *
                 * Getter: Check whether the current item is selected
                 *
                 * @memberof SimpleStackMenuItemTag
                 */
                set selected(v) {
                    if (v) {
                        if (this.switch) {
                            this.checked = !this.checked;
                        }
                        else if (this.radio) {
                            // reset radio
                            const p = this.parentElement;
                            if (p) {
                                for (let item of Array.from(p.children)) {
                                    const el = item;
                                    if (el.radio) {
                                        el.checked = false;
                                    }
                                }
                            }
                            this.checked = !this.checked;
                        }
                    }
                    super.selected = v;
                }
                get selected() {
                    return this.hasattr("selected");
                }
                /**
                 * Setter: Turn on/off the radio feature of the menu entry
                 *
                 * Getter: Check whether the radio feature is enabled
                 *
                 * @memberof SimpleStackMenuItemTag
                 */
                set radio(v) {
                    this.attsw(v, "radio");
                    if (this.switch || v) {
                        $(this.refs.switch).show();
                    }
                    else {
                        $(this.refs.switch).hide();
                    }
                }
                get radio() {
                    return this.hasattr("radio");
                }
                /**
                 * Setter:
                 *
                 * Toggle the switch on the menu entry, this setter
                 * only works when the `checker` or `radio` feature is
                 * enabled
                 *
                 * Getter:
                 *
                 * Check whether the switch is turned on
                 *
                 * @memberof SimpleStackMenuItemTag
                 */
                set checked(v) {
                    this.attsw(v, "checked");
                    if (this.data)
                        this.data.checked = v;
                    if (!this.radio && !this.switch) {
                        return;
                    }
                    this.refs.switch.swon = v;
                }
                get checked() {
                    return this.hasattr("checked");
                }
                /**
                 * Set the keyboard shortcut text
                 *
                 * @memberof SimpleStackMenuItemTag
                 */
                set shortcut(v) {
                    $(this.refs.shortcut).hide();
                    if (!v) {
                        return;
                    }
                    $(this.refs.shortcut).show();
                    $(this.refs.shortcut).text(v);
                }
                /**
                 * Do nothing
                 *
                 * @protected
                 * @memberof SimpleStackMenuItemTag
                 */
                calibrate() {
                }
                /**
                 * Refresh the inner label when the item data
                 * is changed
                 *
                 * @protected
                 * @returns {void}
                 * @memberof SimpleStackMenuItemTag
                 */
                ondatachange() {
                    const v = this.data;
                    if (!v) {
                        return;
                    }
                    if (v.nodes && v.nodes.length > 0) {
                        $(this.refs.submenu).show();
                    }
                    else {
                        $(this.refs.submenu).hide();
                    }
                    const label = this.refs.label;
                    this.set(v);
                    label.set(v);
                    if (v.selected) {
                        this.selected = v.selected;
                    }
                }
                /**
                 * Re-render the list item
                 *
                 * @protected
                 * @memberof SimpleStackMenuItemTag
                 */
                reload() {
                    this.data = this.data;
                }
                /**
                 * List item custom layout definition
                 *
                 * @protected
                 * @returns {TagLayoutType}
                 * @memberof SimpleStackMenuItemTag
                 */
                itemlayout() {
                    return {
                        el: "div",
                        children: [
                            { el: "afx-switch", ref: "switch" },
                            { el: "afx-label", ref: "label" },
                            { el: "span", class: "shortcut", ref: "shortcut" },
                            { el: "span", class: "afx-submenu", ref: "submenu" },
                        ]
                    };
                }
            }
            tag.SimpleStackMenuItemTag = SimpleStackMenuItemTag;
            /**
             * A stack menu is a multilevel menu that
             * uses a single list view to navigate all menu levels
             * instead of using a traditional cascade style menu
             *
             * @export
             * @class StackMenuTag
             * @extends {AFXTag}
             */
            class StackMenuTag extends GUI.AFXTag {
                /**
                 * Stack menu constructor
                 *
                 * @memberof StackMenuTag
                 */
                constructor() {
                    super();
                }
                /**
                 * Update the current tag, do nothing
                 *
                 * @protected
                 * @param {*} [d]
                 * @memberof StackMenuTag
                 */
                reload(d) { }
                /**
                 * Reset to default some property value
                 *
                 * @protected
                 * @memberof StackMenuTag
                 */
                init() {
                    this.stack = [];
                    this._onmenuselect = (_) => { };
                    this.context = false;
                }
                /**
                 * Recalcutate the menu coordinate in case of
                 * context menu
                 *
                 * @protected
                 * @memberof StackMenuTag
                 */
                calibrate() {
                    if (this.context) {
                        const offset = $(this).position();
                        let left = offset.left;
                        let top = offset.top;
                        const ph = $(this).parent().height();
                        const pw = $(this).parent().width();
                        const dy = top + $(this).height() - ph;
                        const dx = left + $(this).width() - pw;
                        if (dx < 0 && dy < 0) {
                            return;
                        }
                        top -= dy > 0 ? dy : 0;
                        left -= dx > 0 ? dx : 0;
                        $(this)
                            .css("top", top + "px")
                            .css("left", left + "px");
                    }
                }
                /**
                 * Reset the menu to its initial state
                 *
                 * @memberof StackMenuTag
                 */
                reset() {
                    const btn = this.refs.title;
                    const list = this.refs.list;
                    list.selected = -1;
                    btn.data = undefined;
                    if (this.stack.length > 0) {
                        let arr = this.stack[0];
                        this.stack = [];
                        list.data = arr[1];
                        $(btn).hide();
                    }
                }
                /**
                 * Mount the tab bar and bind some basic events
                 *
                 * @protected
                 * @memberof StackMenuTag
                 */
                mount() {
                    const btn = this.refs.title;
                    const list = this.refs.list;
                    list.itemtag = "afx-stack-menu-item";
                    btn.onbtclick = (_) => {
                        let arr = this.stack.pop();
                        if (this.stack.length == 0) {
                            $(btn).hide();
                            btn.data = undefined;
                        }
                        else {
                            btn.data = arr[0];
                            btn.iconclass = "bi bi-backspace";
                        }
                        list.data = arr[1];
                    };
                    list.onlistselect = (e) => {
                        let data = e.data.item.data;
                        e.id = this.aid;
                        if (btn.data && btn.data.onchildselect) {
                            btn.data.onchildselect(e);
                        }
                        if (data.onmenuselect) {
                            data.onmenuselect(e);
                        }
                        this._onmenuselect(e);
                        this.observable.trigger("menuselect", e);
                        if (data.nodes && data.nodes.length > 0) {
                            this.stack.push([btn.data, list.data]);
                            btn.data = data;
                            btn.iconclass = "bi bi-backspace";
                            $(btn).show();
                            list.selected = -1;
                            list.data = data.nodes;
                            if (this.context) {
                                this.calibrate();
                            }
                        }
                        else if (this.context) {
                            $(this).hide();
                        }
                    };
                }
                /**
                 * Setter: set current selected item index
                 *
                 * Getter: Get current selected item index
                 *
                 * @memberof StackMenuTag
                 */
                set selected(i) {
                    const list = this.refs.list;
                    list.selected = i;
                }
                get selected() {
                    const list = this.refs.list;
                    return list.selected;
                }
                /**
                 * Setter: Set whether the current menu is a context menu
                 *
                 * Getter: Check whether the current menu is a context menu
                 *
                 * @memberof StackMenuTag
                 */
                set context(v) {
                    this.attsw(v, "context");
                    $(this).removeClass("context");
                    if (!v) {
                        return;
                    }
                    $(this).addClass("context");
                    $(this).hide();
                }
                get context() {
                    return this.hasattr("context");
                }
                /**
                 * Get the latest selected item
                 *
                 * @readonly
                 * @type {ListViewItemTag}
                 * @memberof StackMenuTag
                 */
                get selectedItem() {
                    const list = this.refs.list;
                    return list.selectedItem;
                }
                /**
                 * Get all the selected items
                 *
                 * @readonly
                 * @type {ListViewItemTag[]}
                 * @memberof StackMenuTag
                 */
                get selectedItems() {
                    const list = this.refs.list;
                    return list.selectedItems;
                }
                /**
                 * The following setter/getter are keep for backward compatible
                 * with the MenuTag interface
                 *
                 * Setter: Set the menu data
                 *
                 * Getter: Get the menu data
                 *
                 * @deprecated
                 * @memberof StackMenuTag
                 */
                set items(v) {
                    this.nodes = v;
                }
                get items() {
                    return this.nodes;
                }
                /**
                 * Setter: Set the menu data
                 *
                 * Getter: Get the menu data
                 *
                 * @memberof StackMenuTag
                 */
                set nodes(v) {
                    this.stack = [];
                    this.reset();
                    this.refs.list.data = v;
                    $(this.refs.title).hide();
                }
                get nodes() {
                    return this.refs.list.data;
                }
                /**
                 * Set the `menu entry select` event handle
                 *
                 * @memberof StackMenuTag
                 */
                set onmenuselect(v) {
                    this._onmenuselect = v;
                }
                /**
                 * Hide the current menu. This function is called
                 * only if the current menu is context menu
                 *
                 * @memberof StackMenuTag
                 */
                hide() {
                    if (!this.context) {
                        return;
                    }
                    $(this)
                        .css("bottom", "unset")
                        .css("top", "unset")
                        .css("left", "unset")
                        .css("right", "unset")
                        .hide();
                }
                /**
                 * Show the current menu. This function is called
                 * only if the current menu is a context menu
                 *
                 * @param {JQuery.MouseEventBase} e JQuery mouse event
                 * @returns {void}
                 * @memberof StackMenuTag
                 */
                show(e) {
                    const list = this.refs.list;
                    const btn = this.refs.title;
                    if (!this.context) {
                        return;
                    }
                    if (e) {
                        const offset = $(this).parent().offset();
                        let top = e.clientY - offset.top - 15;
                        let left = e.clientX - offset.left - 5;
                        $(this)
                            .css("top", top + "px")
                            .css("left", left + "px")
                            .css("bottom", "unset")
                            .css("right", "unset");
                    }
                    const dropoff = (e) => {
                        if ($(e.target).closest(`[list-id="${list.aid}"]`).length > 0) {
                            return;
                        }
                        if ($(e.target).closest(btn).length > 0) {
                            return;
                        }
                        this.hide();
                        $(document).off("click", dropoff);
                    };
                    $(document).on("click", dropoff);
                    $(this).show();
                    this.calibrate();
                }
                /**
                 * TabBar layout definition
                 *
                 * @protected
                 * @returns {TagLayoutType[]}
                 * @memberof StackMenuTag
                 */
                layout() {
                    return [
                        {
                            el: "afx-button",
                            ref: "title"
                        },
                        {
                            el: "afx-list-view",
                            ref: "list",
                        }
                    ];
                }
            }
            tag.StackMenuTag = StackMenuTag;
            tag.define("afx-stack-menu", StackMenuTag);
            tag.define("afx-stack-menu-item", SimpleStackMenuItemTag);
        })(tag = GUI.tag || (GUI.tag = {}));
    })(GUI = OS.GUI || (OS.GUI = {}));
})(OS || (OS = {}));

var OS;
(function (OS) {
    let GUI;
    (function (GUI) {
        let tag;
        (function (tag) {
            /**
             * A stack pannel allows to navigate back and forth between pannels
             * (container widget). Each container widget  in the stack should be
             * composed inside a [[HBoxTag]]
             *
             *
             * @export
             * @class StackPanelTag
             * @extends {AFXTag}
             */
            class StackPanelTag extends tag.TabContainerTag {
                /**
                 * Mount the tag and bind basic events
                 *
                 * @protected
                 * @memberof StackPanelTag
                 */
                mount() {
                    this._current_pannel_index = -1;
                    super.mount();
                    this.observable.one("mounted", (id) => {
                        this.tabbarheight = 0;
                        $(this.refs.bar).hide();
                        this.navigateNext();
                    });
                }
                /**
                 * Set the tab select event handle
                 *
                 * @memberof StackPanelTag
                 */
                set ontabselect(f) {
                }
                /**
                 * Navigate to the next panel
                 *
                 * @memberof StackPanelTag
                 */
                navigateNext() {
                    if (this._current_pannel_index >= this.tabs.length)
                        return;
                    this._current_pannel_index++;
                    this.navigate();
                }
                /**
                * Navigate back to the previous panel
                *
                * @memberof StackPanelTag
                */
                navigateBack() {
                    if (this._current_pannel_index <= 0)
                        return;
                    this._current_pannel_index--;
                    this.navigate();
                }
                /**
                 * Navigate to a custom tab
                 *
                 * @memberof StackPanelTag
                 */
                navigate() {
                    this.selectedIndex = this._current_pannel_index;
                }
            }
            tag.StackPanelTag = StackPanelTag;
            tag.define("afx-stack-panel", StackPanelTag);
        })(tag = GUI.tag || (GUI.tag = {}));
    })(GUI = OS.GUI || (OS.GUI = {}));
})(OS || (OS = {}));

var OS;
(function (OS) {
    let GUI;
    (function (GUI) {
        let tag;
        (function (tag) {
            /**
             * This tag define a basic text input and its behavior
             *
             * @export
             * @class InputTag
             * @extends {AFXTag}
             */
            class InputTag extends GUI.AFXTag {
                /**
                 *Creates an instance of InputTag.
                 * @memberof InputTag
                 */
                constructor() {
                    super();
                }
                /**
                 * Set the path to the header icon, the path should be
                 * a VFS file path
                 *
                 * @memberof InputTag
                 */
                set icon(v) {
                    $(this).attr("icon", v);
                    this.refs.label.icon = v;
                }
                /**
                 * Set the icon class to the header
                 *
                 * @memberof InputTag
                 */
                set iconclass(v) {
                    $(this).attr("iconclass", v);
                    this.refs.label.iconclass = v;
                }
                /**
                 * Alias to header setter/getter
                 *
                 * @memberof InputTag
                 */
                set text(v) {
                    this.label = v;
                }
                get text() {
                    return this.label;
                }
                /**
                 * Setter: Set the text of the label
                 *
                 * Getter: Get the current label test
                 *
                 * @memberof InputTag
                 */
                set label(v) {
                    this.refs.label.text = v;
                }
                get label() {
                    return this.refs.label.text;
                }
                /**
                 * Setter: Enable or disable the input
                 *
                 * Getter: Get the `enable` property of the input
                 *
                 * @memberof InputTag
                 */
                set disable(v) {
                    $(this.refs.area).prop("disabled", v);
                    $(this.refs.input).prop("disabled", v);
                }
                get disable() {
                    return !$(this.input).prop("disabled");
                }
                /**
                 * Setter: set verbosity of the input
                 *
                 * Getter: Get the  current input verbosity
                 *
                 * @memberof InputTag
                 */
                set verbose(v) {
                    this.attsw(v, "verbose");
                    this.calibrate();
                }
                get verbose() {
                    return this.hasattr("verbose");
                }
                /**
                 * JQuery style generic event handling on the input element
                 *
                 * @param {string} enname: JQuery event name
                 * @param {JQuery.TypeEventHandler<HTMLInputElement | HTMLTextAreaElement, unknown, any, any, string>} handle: JQuery handle
                 * @memberof InputTag
                 */
                on(ename, handle) {
                    $(this.input).on(ename, handle);
                }
                /**
                 * Manually trigger an event
                 *
                 * @param {string} evt: JQuery event name
                 * @memberof InputTag
                 */
                trigger(evt) {
                    $(this.input).trigger(evt);
                }
                /**
                 * Mount the tag
                 *
                 * @protected
                 * @memberof InputTag
                 */
                mount() {
                    // Do nothing
                }
                /**
                 * Get the current active input element
                 *
                 * @memberof InputTag
                 */
                get input() {
                    if (this.verbose) {
                        return this.refs.area;
                    }
                    return this.refs.input;
                }
                /**
                 * Get/set the current active input value
                 *
                 * @memberof InputTag
                 */
                get value() {
                    return this.input.value;
                }
                set value(v) {
                    this.input.value = v;
                }
                /**
                 * Get/set input type
                 * This only affects the inline input element
                 *
                 * @memberof InputTag
                 */
                get type() {
                    if (this.verbose)
                        return undefined;
                    return this.input.type;
                }
                set type(v) {
                    if (!this.verbose) {
                        this.input.type = v;
                    }
                }
                /**
                 * Get/set input name
                 *
                 * @memberof InputTag
                 */
                get name() {
                    return this.input.name;
                }
                set name(v) {
                    this.input.name = v;
                }
                /**
                 *  Init the tag before mounting
                 *
                 * @protected
                 * @memberof InputTag
                 */
                init() {
                    this.disable = false;
                    this.verbose = false;
                    this.type = "text";
                }
                /**
                 * Re-calibrate, do nothing in this tag
                 *
                 * @protected
                 * @memberof InputTag
                 */
                calibrate() {
                    /*$(this.refs.area)
                        .css("width", "100%");
                    $(this.refs.input)
                        .css("width", "100%");*/
                    if (this.verbose) {
                        $(this.refs.area).show();
                        $(this.refs.input).hide();
                        this.refs.input.value = "";
                    }
                    else {
                        $(this.refs.area).hide();
                        $(this.refs.input).show();
                        this.refs.area.value = "";
                    }
                }
                /**
                 * Update the current tag, do nothing in this tag
                 *
                 * @param {*} [d]
                 * @memberof InputTag
                 */
                reload(d) { }
                /**
                 * Input layout definition
                 *
                 * @protected
                 * @returns {TagLayoutType[]}
                 * @memberof InputTag
                 */
                layout() {
                    return [
                        {
                            el: "afx-label",
                            ref: "label"
                        },
                        {
                            el: "input",
                            ref: "input"
                        },
                        {
                            el: "textarea",
                            ref: "area"
                        },
                        {
                            el: "div"
                        }
                    ];
                }
            }
            tag.InputTag = InputTag;
            tag.define("afx-input", InputTag);
        })(tag = GUI.tag || (GUI.tag = {}));
    })(GUI = OS.GUI || (OS.GUI = {}));
})(OS || (OS = {}));

// Copyright 2017-2018 Xuan Sang LE <xsang.le AT gmail DOT com>
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
// AnTOS Web desktop is is licensed under the GNU General Public
// License v3.0, see the LICENCE file for more information
// This program is free software: you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation, either version 3 of
// the License, or (at your option) any later version.
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// General Public License for more details.
// You should have received a copy of the GNU General Public License
// along with this program. If not, see https://www.gnu.org/licenses/.
var OS;
(function (OS) {
    /**
     * This namespace is dedicated to all APIs related to AntOS UI system,
     * these API are called AFX APIs which handle:
     * - The mouse and keyboard interaction with the UI system
     * - UI rendering
     * - Custom tags definition
     * - Load/unload system, applications and services UI
     * - System dialogs definition
     */
    let GUI;
    (function (GUI) {
        /**
         * Element id of the virtual desktop, used by JQuery
         */
        GUI.workspace = "#desktop";
        /**
         * Indicate whether the system is in fullscreen mode
         */
        GUI.fullscreen = false;
        /**
         * Placeholder for system shortcuts
         */
        var shortcut = {};
        /**
         * Convert an application html scheme to
         * UI elements, then insert this UI scheme to the DOM tree.
         *
         * This function renders the UI of the application before calling the
         * application's [[main]] function
         *
         * @export
         * @param {string} html html scheme string
         * @param {BaseModel} app reference to the target application
         * @param {(Element | string)} parent
         * The parent HTML element where the application is rendered.
         * This is usually the reference to the virtual desktop element.
         */
        function htmlToScheme(html, app, parent) {
            const scheme = $.parseHTML(html)[0];
            if (app.scheme) {
                $(app.scheme).remove();
            }
            parent.append(scheme);
            app.scheme = scheme;
            app.scheme.uify(app.observable, true);
            app.main();
            app.show();
            app.observable.trigger("launched", undefined);
        }
        GUI.htmlToScheme = htmlToScheme;
        /**
         * Load an application scheme file then render
         * it with [[htmlToScheme]]
         *
         * @export
         * @param {string} path VFS path to the scheme file
         * @param {BaseModel} app the target application
         * @param {(HTMLElement | string)} parent The parent HTML element where the application is rendered.
         */
        function loadScheme(path, app, parent) {
            path.asFileHandle()
                .read()
                .then(function (x) {
                if (!x) {
                    return;
                }
                htmlToScheme(x, app, parent);
            })
                .catch((e) => {
                OS.announcer.oserror(__("Cannot load scheme: {0}", path), e);
            });
        }
        GUI.loadScheme = loadScheme;
        /**
         * Clear the current system theme
         *
         * @export
         */
        function clearTheme() {
            $("head link#ostheme").attr("href", "");
            $("body").attr("theme", "");
        }
        GUI.clearTheme = clearTheme;
        /**
         * Load a theme based on its name, then refresh the
         * system UI theme
         *
         * @export
         * @param {string} name name of the theme e.g. `antos_dark`
         * @param {boolean} force force to clear the system theme before applying the new one
         */
        function loadTheme(name, force) {
            if (force) {
                clearTheme();
            }
            const path = `resources/themes/${name}/${name}.css`;
            $("head link#ostheme").attr("href", path);
            $("body").attr("theme", name);
        }
        GUI.loadTheme = loadTheme;
        /**
         * Get the system dock tag
         *
         * @export
         * @return {*}  {GUI.tag.AppDockTag}
         */
        function systemDock() {
            return $("[data-id='sysdock']")[0];
        }
        GUI.systemDock = systemDock;
        /**
         * Get the current virtual desktop
         *
         * @export
         * @return {*}  {GUI.tag.DesktopTag}
         */
        function desktop() {
            return $(GUI.workspace)[0];
        }
        GUI.desktop = desktop;
        /**
         * Open a system dialog.
         *
         * @export
         * @param {(BaseDialog | string)} d a dialog object or a dialog class name
         * @param {GenericObject<any>} [data] input data of the dialog, refer to each
         * dialog definition for the format of the input data
         * @returns {Promise<any>} A promise on the callback data of the dialog, refer
         * to each dialog definition for the format of the callback data
         */
        function openDialog(d, data) {
            return new Promise(function (resolve, reject) {
                if (GUI.dialog) {
                    GUI.dialog.show();
                    return resolve(undefined);
                }
                if (typeof d === "string") {
                    if (!GUI.dialogs[d]) {
                        const ex = OS.API.throwe("Dialog");
                        return reject(ex);
                    }
                    GUI.dialog = new GUI.dialogs[d]();
                }
                else {
                    GUI.dialog = d;
                }
                GUI.dialog.parent = GUI;
                GUI.dialog.handle = resolve;
                GUI.dialog.pid = -1;
                GUI.dialog.data = data;
                return GUI.dialog.init();
            });
        }
        GUI.openDialog = openDialog;
        /**
         * Find a list of applications that support a specific mime
         * type in the system packages meta-data
         *
         * @export
         * @param {string} mime the mime type
         * @returns {API.PackageMetaType[]}
         */
        function appsByMime(mime) {
            const metas = [];
            for (let k in OS.setting.system.packages) {
                const v = OS.setting.system.packages[k];
                if (v && v.app) {
                    metas.push(v);
                }
            }
            let m;
            const mimes = [];
            for (m of metas) {
                if (m) {
                    mimes.push(m.mimes);
                }
            }
            const apps = [];
            // search app by mimes
            const f = function (arr, idx) {
                try {
                    return arr.filter(function (m, i) {
                        if (mime.match(new RegExp(m, "g"))) {
                            if (apps.indexOf(metas[idx]) >= 0) {
                                return false;
                            }
                            apps.push(metas[idx]);
                            return false;
                        }
                        return false;
                    });
                }
                catch (e) {
                    return false;
                }
            };
            let arr;
            for (let i = 0; i < mimes.length; i++) {
                arr = mimes[i];
                if (arr) {
                    f(arr, i);
                }
            }
            return apps;
        }
        GUI.appsByMime = appsByMime;
        /**
         * Find all applications that have services attached to it.
         * This function allows to collect all the services available
         * on the system. These services may or may not be running.
         *
         * @export
         * @returns {GenericObject<API.PackageMetaType>} result in forme of:
         * `service_name:service-meta-data` key-value pairs
         */
        function appsWithServices() {
            const o = {};
            for (let k in OS.setting.system.packages) {
                const v = OS.setting.system.packages[k];
                if (v && v.services && v.services.length > 0) {
                    o[k] = v;
                }
            }
            return o;
        }
        GUI.appsWithServices = appsWithServices;
        /**
         * Find an launch an application using input application argument
         * such as VFS file meta-data.
         *
         * Based on the input application argument, the function will try
         * to find all applications that is compatible with that argument.
         * Three cases possible:
         * - There is no application that can handle the argument, a message will
         * be notified to user.
         * - There is one application that can handle the argument, the application
         * will be launched with the argument
         * - There are many applications that can handle the arguments, a selection
         * dialog will be popped up and allows user to select an application to launch.
         *
         * @export
         * @param {AppArgumentsType} it application argument
         * @returns {void}
         */
        function openWith(it) {
            if (!it) {
                return;
            }
            if (it.type === "app" && it.app) {
                launch(it.app, []);
                return;
            }
            if (it.type === "app") {
                return OS.announcer.osinfo(__("Application {0} is not executable", it.text));
            }
            const apps = appsByMime(it.type === "dir" ? "dir" : it.mime);
            if (apps.length === 0) {
                return OS.announcer.osinfo(__("No application available to open {0}", it.filename));
            }
            if (apps.length === 1) {
                launch(apps[0].app, [it]);
                return;
            }
            const list = apps.map((e) => ({
                text: e.name,
                app: e.app,
                icon: e.icon,
                iconclass: e.iconclass,
            }));
            openDialog("SelectionDialog", {
                title: __("Open with"),
                data: list,
            }).then((d) => launch(d.app, [it]));
        }
        GUI.openWith = openWith;
        /**
         * Kil all processes related to an application, reload the application
         * prototype definition and launch a new process of this application.
         *
         * This function is used only for debug purpose or used by
         * AntOSDK during in-browser application development
         *
         * @export
         * @param {string} app the application class name
         * @param {AppArgumentsType[]} args application arguments
         * @returns {void}
         */
        function forceLaunch(app, args) {
            console.warn("This method is used for developing only, please use the launch method instead");
            unloadApp(app);
            launch(app, args);
        }
        GUI.forceLaunch = forceLaunch;
        /**
         * Kill an running processes of an application, then
         * unregister the application prototype definition
         * from the [[application]] namespace.
         *
         * This process is similar to uninstall the application
         * from the current system state
         *
         * @export
         * @param {string} app
         */
        function unloadApp(app, save) {
            OS.PM.killAll(app, true);
            if (OS.application[app] && OS.application[app].style) {
                $(OS.application[app].style).remove();
            }
            if (save) {
                // remove pinned application if any
                if (OS.setting.system.startup.pinned)
                    OS.setting.system.startup.pinned = OS.setting.system.startup.pinned.filter((e) => e != app);
                // remove service if it is the service
                if (OS.setting.system.startup.services)
                    OS.setting.system.startup.services = OS.setting.system.startup.services.filter((e) => e != app);
                // remove startup app if any
                if (OS.setting.system.startup.apps)
                    OS.setting.system.startup.apps = OS.setting.system.startup.apps.filter((e) => e != app);
                // refresh pinned list
                OS.announcer.ostrigger("app-pinned", "app-pinned", undefined);
                // remove application setting
                if (OS.setting.applications[app])
                    delete OS.setting.applications[app];
                OS.API.setting()
                    .then((d) => {
                    if (d.error) {
                        OS.announcer.oserror(__("Error when save system setting {0}:{1}", app, d.error), undefined);
                    }
                })
                    .catch((e) => {
                    OS.announcer.oserror(__("Error when save system setting {0}: {1}", app, e.toString()), e);
                });
            }
            delete OS.application[app];
        }
        GUI.unloadApp = unloadApp;
        /**
         * Load an application if the application is not registered yet
         * in the system.
         *
         * This function fist loads and registers the application prototype
         * definition in the [[application]] namespace, then update
         * the system packages meta-data
         *
         * First it tries to load the package with the app name is also the
         * pkgname, if its fail, it will search the app name by pkg name and load
         * it
         *
         * @param {string} app application class name
         * @returns {Promise<string>}
         */
        function loadApp(app) {
            return new Promise(function (resolve, reject) {
                return __awaiter(this, void 0, void 0, function* () {
                    let path = undefined;
                    try {
                        if (!OS.setting.system.packages[app]) {
                            for (const key in OS.setting.system.packages) {
                                const pkg = OS.setting.system.packages[key];
                                if (pkg.app == app && pkg.path) {
                                    path = pkg.path;
                                }
                            }
                        }
                        else if (OS.setting.system.packages[app].path) {
                            path = OS.setting.system.packages[app].path;
                        }
                        if (!path) {
                            throw __("Unable to locate package of {0}", app).__();
                        }
                        const js = path + "/main.js";
                        const d = yield js.asFileHandle().read("script");
                        const data = yield `${path}/package.json`
                            .asFileHandle()
                            .read("json");
                        data.path = path;
                        if (OS.application[app]) {
                            OS.application[app].meta = data;
                        }
                        if (data.services) {
                            for (let v of data.services) {
                                OS.application[v].meta = data;
                            }
                        }
                        //load css file
                        try {
                            const css = `${path}/main.css`;
                            yield css.asFileHandle().onready();
                            const stamp = new Date().timestamp();
                            const el = $("<link>", {
                                rel: "stylesheet",
                                type: "text/css",
                                href: `${OS.API.handle.get}/${css}?stamp=${stamp}`,
                            }).appendTo("head");
                            if (OS.application[app]) {
                                OS.application[app].style = el[0];
                            }
                        }
                        catch (e_1) { }
                        return resolve(app);
                    }
                    catch (e) {
                        return reject(__e(e));
                    }
                });
            });
        }
        /**
         * Create a service process.
         *
         * Services are singleton processes, there is only
         * one process of a service at a time
         *
         * @export
         * @param {string} ph
         * @returns {Promise<PM.ProcessType>}
         */
        function pushService(ph) {
            return new Promise(function (resolve, reject) {
                return __awaiter(this, void 0, void 0, function* () {
                    const arr = ph.split("/");
                    const srv = arr[1];
                    const app = arr[0];
                    try {
                        if (!OS.application[srv]) {
                            yield loadApp(app);
                            if (!OS.application[srv]) {
                                return reject(OS.API.throwe(__("Service not found: {0}", ph)));
                            }
                        }
                        const d = yield OS.PM.createProcess(srv, OS.application[srv]);
                        return resolve(d);
                    }
                    catch (e) {
                        return reject(__e(e));
                    }
                });
            });
        }
        GUI.pushService = pushService;
        /**
         * Synchronously start a list of services
         *
         * @export
         * @param {string[]} srvs list of service class names
         * @returns {Promise<void>}
         */
        function pushServices(srvs) {
            return new Promise(function (resolve, reject) {
                if (!(srvs.length > 0)) {
                    return resolve();
                }
                const srv = srvs.splice(0, 1)[0];
                return pushService(srv)
                    .then((d) => pushServices(srvs)
                    .then(() => resolve())
                    .catch((e) => reject(__e(e))))
                    .catch(function (e) {
                    OS.announcer.osfail(__("Unable to load: {0}", srv), e);
                    return pushServices(srvs)
                        .then(() => resolve())
                        .catch((e) => reject(__e(e)));
                });
            });
        }
        GUI.pushServices = pushServices;
        /**
         * Launch an application with arguments
         *
         * @export
         * @param {string} app application class name
         * @param {AppArgumentsType[]} args application arguments
         */
        function launch(app, args) {
            return new Promise((resolve, reject) => __awaiter(this, void 0, void 0, function* () {
                const pidactive = OS.PM.pidactive;
                try {
                    OS.PM.pidactive = 0;
                    if (!OS.application[app]) {
                        // first load it
                        yield loadApp(app);
                        if (!OS.application[app]) {
                            const e = OS.API.throwe(__("Application not found"));
                            OS.announcer.oserror(__("{0} is not an application", app), e);
                            return reject(e);
                        }
                        const p = yield OS.PM.createProcess(app, OS.application[app], args);
                        resolve(p);
                    }
                    else {
                        // now launch it
                        const p = yield OS.PM.createProcess(app, OS.application[app], args);
                        resolve(p);
                    }
                }
                catch (e) {
                    OS.announcer.osfail(__("Unable to launch: {0}", app), e);
                    OS.PM.pidactive = pidactive;
                    return reject(__e(e));
                }
            }));
        }
        GUI.launch = launch;
        /**
         * Dock an application to the system application dock
         *
         * @export
         * @param {BaseApplication} app reference to the application process
         * @param {API.PackageMetaType} meta Application meta-data
         * @returns {void}
         */
        function dock(app, meta) {
            // dock an application to a dock
            // create a data object
            const data = {
                icon: null,
                iconclass: meta.iconclass || "",
                app
            };
            // TODO: this path is not good, need to create a blob of it
            if (meta.icon) {
                data.icon = `${meta.path}/${meta.icon}`;
            }
            // TODO: add default app icon class in system setting
            // so that it can be themed
            if (!meta.icon && !meta.iconclass) {
                data.iconclass = "fa fa-cogs";
            }
            const dock = systemDock();
            app.sysdock = dock;
            app.init();
            app.observable.one("rendered", function () {
                dock.addapp(data);
            });
        }
        GUI.dock = dock;
        /**
         * Toggle system fullscreen
         *
         * @export
         */
        function toggleFullscreen() {
            const el = document.documentElement;
            if (GUI.fullscreen) {
                if (document.exitFullscreen) {
                    document.exitFullscreen();
                }
                if (document.mozCancelFullScreen) {
                    document.mozCancelFullScreen();
                }
                if (document.webkitExitFullscreen) {
                    document.webkitExitFullscreen();
                }
                if (document.cancelFullScreen) {
                    document.cancelFullScreen();
                }
            }
            else {
                if (el.requestFullscreen) {
                    el.requestFullscreen();
                }
                if (el.mozRequestFullScreen) {
                    el.mozRequestFullScreen();
                }
                if (el.webkitRequestFullscreen) {
                    el.webkitRequestFullscreen();
                }
                if (el.msRequestFullscreen) {
                    el.msRequestFullscreen();
                }
            }
        }
        GUI.toggleFullscreen = toggleFullscreen;
        /**
         * Remove an application process from the system application
         * dock. This action will also exit the process
         *
         * @export
         * @param {BaseApplication} app
         * @returns
         */
        function undock(app) {
            return systemDock().removeapp(app);
        }
        GUI.undock = undock;
        /**
         * Attach a running service process to the system tray
         *
         * @export
         * @param {BaseService} srv reference to the running service process
         * @returns {void}
         */
        function attachservice(srv) {
            $("#syspanel")[0].attachservice(srv);
            srv.init();
        }
        GUI.attachservice = attachservice;
        /**
         * Detach a running process from the system tray
         *
         * @export
         * @param {BaseService} srv reference to the running service process
         * @returns {void}
         */
        function detachservice(srv) {
            return $("#syspanel")[0].detachservice(srv);
        }
        GUI.detachservice = detachservice;
        /**
         * Bind a context menu event to an AntOS element.
         *
         * This will find the fist element which defines a handle
         * named [[contextMenuHandle]] and bind the context menu
         * event to it.
         *
         * @param {JQuery.MouseEventBase} event mouse event
         * @returns {void}
         */
        function bindContextMenu(event) {
            var handle = function (e) {
                if (e.contextmenuHandle) {
                    const m = $("#contextmenu")[0];
                    m.onmenuselect = () => { };
                    return e.contextmenuHandle(event, m);
                }
                else {
                    const p = $(e).parent().get(0);
                    if (p !== $("#workspace").get(0)) {
                        return handle(p);
                    }
                }
            };
            handle(event.target);
            return event.preventDefault();
        }
        /**
         * Register a hot key and its handle in the
         * system  shortcut
         *
         * @export
         * @param {string} k the hotkey e.g. `ALT-C`
         * @param {(e: JQuery.KeyPressEvent) => void} f handle function
         * @param {boolean} force force to rebind the hotkey
         * @returns {void}
         */
        function bindKey(k, f, force = true) {
            const arr = k.toUpperCase().split("-");
            const c = arr.pop();
            let fnk = "";
            if (arr.includes("META")) {
                fnk += "META";
            }
            if (arr.includes("CTRL")) {
                fnk += "CTRL";
            }
            if (arr.includes("ALT")) {
                fnk += "ALT";
            }
            if (arr.includes("SHIFT")) {
                fnk += "SHIFT";
            }
            if (fnk == "") {
                return;
            }
            fnk = `fn_${fnk.hash()}`;
            if (!shortcut[fnk]) {
                shortcut[fnk] = {};
            }
            if (shortcut[fnk][c] && !force)
                return;
            shortcut[fnk][c] = f;
        }
        GUI.bindKey = bindKey;
        /**
         * Load and apply system wallpaper from the setting object
         *
         * @export
         * @param {setting.WPSettingType} obj wallpaper setting object
         */
        function wallpaper(obj) {
            if (obj) {
                OS.setting.appearance.wp = obj;
            }
            const wp = OS.setting.appearance.wp;
            $("body")
                .css("background-image", `url(${OS.API.handle.get}/${wp.url})`)
                .css("background-size", wp.size)
                .css("background-repeat", wp.repeat);
        }
        GUI.wallpaper = wallpaper;
        /**
         * Show tooltip at the current mouse position
         *
         * @param {JQuery<HTMLElement>} el The target element that has the tooltip attribute
         * @param {string} text The text to be displayed
         * @param {JQuery.MouseEventBase} e mouse event
         * @returns {void}
         */
        function showTooltip(el, text, e) {
            let left, top;
            const label = $("#systooltip")[0];
            var cb = function (ev) {
                if ($(ev.target).closest(el).length === 0) {
                    $(label).hide();
                    return $(document).off("mousemove", cb);
                }
            };
            $(document).on("mousemove", cb);
            const arr = text.split(/:(.+)/);
            let tip = text;
            if (arr.length > 1) {
                tip = arr[1];
            }
            const offset = $(el).offset();
            const w = $(el).width();
            const h = $(el).height();
            label.text = tip;
            $(label).show();
            switch (arr[0]) {
                case "cr": // center right of the element
                    left = offset.left + w + 5;
                    top = offset.top + h / 2 - $(label).height() / 2;
                    break;
                case "ct": //ceter top
                    left = offset.left + w / 2 - $(label).width() / 2;
                    top = offset.top - $(label).height() - 5;
                    break;
                case "cb": // center bottom
                    left = offset.left + w / 2 - $(label).width() / 2;
                    top = offset.top + $(label).height() + 10;
                    break;
                default:
                    if (!e) {
                        return;
                    }
                    top = e.clientY + 5;
                    left = e.clientX + 5;
            }
            $(label)
                .css("top", top + "px")
                .css("left", left + "px");
        }
        /**
         * Init the virtual desktop on boot:
         *
         * - Register listener for system hotkey
         * - Bind the system context menu handle
         * - Init and load the content of the virtual desktop
         * - Init the system tooltip event handle
         */
        function initDM() {
            const scheme = $.parseHTML(GUI.schemes.ws);
            $("#wrapper").append(scheme);
            OS.announcer.one("sysdockloaded", () => {
                $(window).on("keydown", function (event) {
                    const dock = systemDock();
                    if (!dock) {
                        return;
                    }
                    const app = dock.selectedApp;
                    //return true unless app
                    const c = String.fromCharCode(event.which).toUpperCase();
                    let fnk = "";
                    if (event.metaKey) {
                        fnk += "META";
                    }
                    if (event.ctrlKey) {
                        fnk += "CTRL";
                    }
                    if (event.altKey) {
                        fnk += "ALT";
                    }
                    if (event.shiftKey) {
                        fnk += "SHIFT";
                    }
                    //console.log(fnk, c);
                    if (fnk == "") {
                        return;
                    }
                    fnk = `fn_${fnk.hash()}`;
                    const r = app ? app.shortcut(fnk, c, event) : true;
                    if (!r) {
                        return event.preventDefault();
                    }
                    if (!shortcut[fnk]) {
                        return;
                    }
                    if (!shortcut[fnk][c]) {
                        return;
                    }
                    shortcut[fnk][c](event);
                    return event.preventDefault();
                });
            });
            // system menu and dock
            $("#syspanel")[0].uify(undefined);
            $("#systooltip")[0].uify(undefined);
            const ctxmenu = $("#contextmenu")[0];
            ctxmenu.uify(undefined);
            $("#wrapper").on("contextmenu", (e) => bindContextMenu(e));
            // tooltip
            $(document).on("mouseover", function (e) {
                const el = $(e.target).closest("[tooltip]");
                if (!(el.length > 0)) {
                    return;
                }
                return showTooltip(el, $(el).attr("tooltip"), e);
            });
            // mount it
            desktop().uify(undefined);
        }
        /**
         * Refresh the virtual desktop
         *
         * @export
         */
        function refreshDesktop() {
            desktop().refresh();
        }
        GUI.refreshDesktop = refreshDesktop;
        /**
         * Show the login screen and perform the login operation.
         *
         * Once login successfully, the [[startAntOS]] will be called
         *
         * @export
         */
        function login() {
            const scheme = $.parseHTML(GUI.schemes.login
                .replace("[ANTOS_BUILD_ID]", OS.VERSION.build_id)
                .replace("[ANTOS_VERSION]", OS.VERSION.version_string));
            $("#wrapper").append(scheme);
            $("#login_form")[0].uify(undefined);
            $("#btlogin")[0].onbtclick = function () {
                return __awaiter(this, void 0, void 0, function* () {
                    const data = {
                        username: $("#txtuser").val(),
                        password: $("#txtpass").val(),
                    };
                    const err_label = $("#login_error")[0];
                    try {
                        const d = yield OS.API.handle.login(data);
                        if (d.error) {
                            err_label.iconclass = "bi bi-exclamation-diamond-fill";
                            return err_label.text = d.error;
                        }
                        return startAntOS(d.result);
                    }
                    catch (e) {
                        err_label.iconclass = "bi bi-bug-fill";
                        return err_label.text = __("Login: server error");
                    }
                });
            };
            $("#txtpass")[0].on("keyup", function (e) {
                if (e.which === 13) {
                    return $("#btlogin button").trigger("click");
                }
            });
            $("#txtuser")[0].on("keyup", function (e) {
                if (e.which === 13) {
                    return $("#btlogin button").trigger("click");
                }
            });
        }
        GUI.login = login;
        /**
         * Start AntOS after a successful login.
         *
         * This function performs the following operations:
         *
         * - System cleanup
         * - Apply system setting
         * - Load desktop wallpaper and the current theme from the system setting
         * - Load system package meta-data
         * - Load and apply system locale and language
         *
         *
         * @export
         * @param {*} conf
         */
        function startAntOS(conf) {
            // clean up things
            OS.cleanup();
            // get setting from conf
            OS.systemSetting(conf);
            // load theme
            loadTheme(OS.setting.appearance.theme, true);
            wallpaper(undefined);
            OS.announcer.one("syspanelloaded", function () {
                return __awaiter(this, void 0, void 0, function* () {
                    OS.announcer.on("systemlocalechange", (_) => $("#syspanel")[0].update());
                    const ret = yield OS.API.packages.cache();
                    if (ret.result) {
                        return OS.API.packages.fetch().then(function (r) {
                            let v;
                            if (r.result) {
                                const result = r.result;
                                for (let k in result) {
                                    v = result[k];
                                    v.text = v.name;
                                    v.filename = k;
                                    v.type = "app";
                                    v.mime = "antos/app";
                                    if (v.icon) {
                                        v.icon = `${v.path}/${v.icon}`;
                                    }
                                    if (!v.iconclass && !v.icon) {
                                        v.iconclass = "fa fa-adn";
                                    }
                                }
                                OS.setting.system.packages = result
                                    ? result
                                    : undefined;
                            }
                            // load services + VFSX
                            Promise.all([
                                OS.API.VFS.loadVFSX(true),
                                pushServices((() => {
                                    const result = [];
                                    for (let v of OS.setting.system.startup.services) {
                                        result.push(v);
                                    }
                                    return result;
                                })())
                            ])
                                .then(function () {
                                OS.setting.system.startup.apps.map((a) => {
                                    launch(a, []);
                                });
                            });
                        });
                    }
                });
            });
            // initDM
            OS.API.setLocale(OS.setting.system.locale).then(() => initDM());
            Ant.OS.announcer.on("error", function (d) {
                console.log(d.u_data);
            });
            Ant.OS.announcer.on("fail", function (d) {
                console.log(d.u_data);
            });
        }
        GUI.startAntOS = startAntOS;
        /**
         * HTML schemes used by the system:
         * - The login screen scheme
         * - The workspace including:
         *  - System panel
         *  - Virtual desktop
         *  - Context menu
         *  - System tooltip
         */
        GUI.schemes = {};
        GUI.schemes.ws = `\
<afx-sys-panel id = "syspanel"></afx-sys-panel>
<div id = "workspace">
    <afx-desktop id = "desktop" dir="vertical" ></afx-desktop>
</div>
<afx-stack-menu id="contextmenu" data-id="contextmenu" context="true" style="display:none;"></afx-stack-menu>
<afx-label id="systooltip" data-id="systooltip" style="display:none;position:absolute;"></afx-label>
<textarea id="clipboard"></textarea>\
`;
        GUI.schemes.login = `\
<afx-vbox id = "login_form">
    <afx-label data-height="35" text="Welcome to AntOS, please login"></afx-label>
    <afx-vbox padding = "10">
        <afx-input data-height="52" id = "txtuser" type = "text" value = "demo" label="User name"></afx-input>
        <div data-height="10"></div>
        <afx-input data-height="52" id = "txtpass" type = "password" value = "demo" label="Password"></afx-input>
        <div data-height="10"></div>
        <afx-hbox>
            <afx-label id = "login_error"></afx-label>
            <afx-button id = "btlogin" text="Login" iconclass = "bi bi-box-arrow-in-right" data-width="content"></afx-button>
        </afx-hbox>
    </afx-vbox>
</afx-vbox>
<div id = "antos_build_id"><a href="${OS.REPOSITORY}/tree/[ANTOS_BUILD_ID]">AntOS v[ANTOS_VERSION]</div>\
`;
    })(GUI = OS.GUI || (OS.GUI = {}));
})(OS || (OS = {}));

var OS;
(function (OS) {
    /**
     * This namespace dedicated to all operations related to system
     * process management
     */
    let PM;
    (function (PM) {
        /**
         * Process id allocator, when a new process is created, the value of
         * this variable is increased
         */
        PM.pidalloc = 0;
        /**
         * All running processes is stored in this variables
         */
        /**
         * Current active process ID
         */
        PM.pidactive = 0;
        PM.processes = {};
        /**
         * Create a new process of application or service
         *
         * @export
         * @param {string} app class name string
         * @param {ProcessTypeClass} cls prototype class
         * @param {GUI.AppArgumentsType[]} [args] process arguments
         * @returns {Promise<ProcessType>} a promise on the created process
         */
        function createProcess(app, cls, args) {
            return new Promise(function (resolve, reject) {
                let metaclass = cls;
                const f = function () {
                    //if it is single ton
                    // and a process is existing
                    // just return it
                    let obj;
                    if (metaclass.singleton &&
                        PM.processes[app] &&
                        PM.processes[app].length === 1) {
                        obj = PM.processes[app][0];
                        obj.show();
                    }
                    else {
                        if (!PM.processes[app]) {
                            PM.processes[app] = [];
                        }
                        obj = new cls(args);
                        obj.birth = new Date().getTime();
                        PM.pidalloc++;
                        obj.pid = PM.pidalloc;
                        obj.subscribe("systemlocalechange", (d) => {
                            obj.updateLocale(d.message);
                            return obj.update();
                        });
                        PM.processes[app].push(obj);
                        if (metaclass.type === OS.ModelType.Application) {
                            OS.GUI.dock(obj, metaclass.meta);
                        }
                        else {
                            OS.GUI.attachservice(obj);
                        }
                    }
                    return obj;
                };
                if (metaclass.dependencies) {
                    const libs = metaclass.dependencies;
                    return OS.API.require(libs)
                        .then(() => resolve(f()))
                        .catch((e) => reject(__e(e)));
                }
                else {
                    return resolve(f());
                }
            });
        }
        PM.createProcess = createProcess;
        /**
         * Get the reference to a process using its id
         *
         * @export
         * @param {number} pid
         * @returns {BaseModel}
         */
        function appByPid(pid) {
            let app = undefined;
            const find = function (l) {
                for (let a of l) {
                    if (a.pid === pid) {
                        return a;
                    }
                }
            };
            for (let k in PM.processes) {
                const v = PM.processes[k];
                app = find(v);
                if (app) {
                    break;
                }
            }
            return app;
        }
        PM.appByPid = appByPid;
        /**
         * Kill a process
         *
         * @export
         * @param {OS.GUI.BaseModel} app reference to the process
         * @returns {void}
         */
        function kill(app) {
            if (!app.name || !PM.processes[app.name]) {
                return;
            }
            const i = PM.processes[app.name].indexOf(app);
            if (i >= 0) {
                if (OS.application[app.name].type === OS.ModelType.Application) {
                    OS.GUI.undock(app);
                }
                else {
                    OS.GUI.detachservice(app);
                }
                // announcer.unregister(app);
                delete PM.processes[app.name][i];
                PM.processes[app.name].splice(i, 1);
            }
        }
        PM.kill = kill;
        /**
         * Kill all process of an application or service
         *
         * @export
         * @param {string} app process class name
         * @param {boolean} force force exit all process
         * @returns {void}
         */
        function killAll(app, force) {
            if (!PM.processes[app]) {
                return;
            }
            const arr = PM.processes[app].map(e => e);
            for (const p of arr) {
                p.quit(force);
            }
        }
        PM.killAll = killAll;
        /**
         * Get the current active application
         *  @export
         * @returns {BaseModel}
         */
        function getActiveApp() {
            if (PM.pidactive === 0) {
                return undefined;
            }
            return PM.appByPid(PM.pidactive);
        }
        PM.getActiveApp = getActiveApp;
    })(PM = OS.PM || (OS.PM = {}));
})(OS || (OS = {}));

// Copyright 2017-2018 Xuan Sang LE <xsang.le AT gmail DOT com>
// AnTOS Web desktop is is licensed under the GNU General Public
// License v3.0, see the LICENCE file for more information
// This program is free software: you can redistribute it and/or
// modify it under the terms of the GNU General Public License as
// published by the Free Software Foundation, either version 3 of
// the License, or (at your option) any later version.
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// General Public License for more details.
// You should have received a copy of the GNU General Public License
//along with this program. If not, see https://www.gnu.org/licenses/.
Ant.onload = function () {
    $(document).on("webkitfullscreenchange mozfullscreenchange fullscreenchange MSFullscreenChange", () => (Ant.OS.GUI.fullscreen = !Ant.OS.GUI.fullscreen));
    const agent = navigator.userAgent || navigator.vendor || window.opera;
    Ant.OS.mobile = false;
    if (/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino/i.test(agent)
        ||
            /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(agent.substr(0, 4))) {
        Ant.OS.mobile = true;
    }
    return Ant.OS.boot();
};

OS.VERSION.version_string = "2.0.0-a-64359df";
