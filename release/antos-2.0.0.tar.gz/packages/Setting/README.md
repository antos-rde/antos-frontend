# Setting: AntOS system setting and configuration

GUI based system setting application for AntOS.

In-depth system settings can be found and modified in .settings.json file stored in HOME directory
of current user.

CAUTION:without using the Setting application, users can modify .settings.json with their own risk.
In case of system anormaly after the modification, the system settings can be reset to default
by simply removing the setting file

## Change logs
-v0.1.2-b: minor bug fix on UI
-v0.1.2-b: add README
