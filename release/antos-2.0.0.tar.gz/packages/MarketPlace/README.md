# Market Place

AntOS original application store.
This application is icluded in the AntOS delivery
and cannot be removed/uinstalled by regular user

## Change logs
- 0.2.7-b: only launch application
- 0.2.6-b: improve install process
- v0.2.5-b: add README.md