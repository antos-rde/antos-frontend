# Syslog: System notification management and service

Provide system wise notification service (Push Notification)

## Change logs
-v0.1.2-b: add README
