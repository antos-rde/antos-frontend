# NotePad: A very simple text editor

Defaut text editor which is included in each AntOS release.
It has very barebone features: open/edit/save text file.

Text/Code editor with fancy features can be optionally installed via the Market Place
