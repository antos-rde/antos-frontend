# Market Place

AntOS original application store.
This application is icluded in the AntOS delivery
and cannot be removed/uinstalled by regular user

## Change logs
- v0.2.5-b: add README.md