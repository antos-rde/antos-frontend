# Files

Base AntOS file explorer application.

This application is included in the AntOS delivery as system application and
cannot be removed/uinstalled by regular user

## Change logs
- v0.1.7-b: fix - file grid view double click event hanling on diffent cells of a row